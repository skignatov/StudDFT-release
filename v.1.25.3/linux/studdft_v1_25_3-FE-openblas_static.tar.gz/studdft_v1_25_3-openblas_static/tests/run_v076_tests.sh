#!/bin/bash
# =============================================================================
# StudDFT v0.76.0 regression and acceptance test driver
#
# Tests the four-part SCF-robustness improvement:
#   Task 1  -- robust convergence criterion (3 sub-criteria + min_iter + 2x)
#   Task 2  -- Aufbau-continuity check + AUTO/STRICT/MOM/MIX
#   Task 3  -- SAD (Superposition of Atomic Densities) initial guess
#   Task 4a -- DIIS condition-number-based subspace pruning
#
# Each test prints a one-line PASS / FAIL line.  PASS means the run
# completed AND produced the expected qualitative behaviour (a
# specific converged energy, or a clean "NOT converged" with the
# right diagnostic).  No silent false-positive convergence anywhere.
# =============================================================================

set -e
THIS_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$THIS_DIR/.." && pwd)"
STUDDFT="$ROOT/studdft"
RUNDIR="$ROOT/run_v076"
mkdir -p "$RUNDIR"
cd "$RUNDIR"
ln -sf "$ROOT/basis_data" basis_data
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-2}

NPASS=0; NFAIL=0; NTOTAL=0

run_test () {
    local label="$1"
    local input="$2"
    local check="$3"      # an extended-regex grep pattern that must MATCH
    local antimatch="$4"  # an extended-regex grep pattern that must NOT match

    NTOTAL=$((NTOTAL+1))
    cp "$THIS_DIR/$input" "$RUNDIR/$input"
    local out="${input%.inp}.out"
    if timeout 240 "$STUDDFT" "$input" > "$out" 2>&1 ; then
        :
    else
        :
    fi
    local ok=1
    if [ -n "$check" ]; then
        if ! grep -E -q "$check" "$out" ; then
            ok=0
        fi
    fi
    if [ -n "$antimatch" ]; then
        if grep -E -q "$antimatch" "$out" ; then
            ok=0
        fi
    fi
    if [ $ok -eq 1 ]; then
        printf "  PASS  %-50s  (%s)\n" "$label" "$input"
        NPASS=$((NPASS+1))
    else
        printf "  FAIL  %-50s  (%s)\n" "$label" "$input"
        NFAIL=$((NFAIL+1))
    fi
}

echo "============================================================"
echo " StudDFT v0.76.0 regression + acceptance tests"
echo "============================================================"

# -----------------------------------------------------------------
# Regression: closed-shell RHF.  v0.75.1 energy to better than 1e-6.
# -----------------------------------------------------------------
run_test \
    "H2O RHF STO-3G closed-shell regression" \
    "test_v076_h2o_rhf_regression.inp" \
    "Total energy:.* -74\.96311054[0-9]+" \
    "NOT converged"

# -----------------------------------------------------------------
# Regression: open-shell SVWN (the alpha_c-fixed v0.75.1+1 baseline).
# -----------------------------------------------------------------
run_test \
    "CH3 SVWN cc-pVDZ open-shell regression"          \
    "test_v076_ch3_uks_regression.inp"                \
    "Total energy:.* -39\.82822581520[0-9]"           \
    "NOT converged"

# -----------------------------------------------------------------
# Acceptance: easy open-shell -- must converge cleanly with SAD.
# -----------------------------------------------------------------
run_test \
    "OH BPW91 cc-pVDZ"                                \
    "test_v076_oh_uks_bpw91.inp"                      \
    "SCF converged"                                   \
    "NOT converged"

run_test \
    "O2 triplet BPW91 cc-pVDZ"                        \
    "test_v076_o2t_uks_bpw91.inp"                     \
    "SCF converged"                                   \
    "NOT converged"

run_test \
    "Li BPW91 cc-pVDZ"                                \
    "test_v076_li_uks_bpw91.inp"                      \
    "SCF converged"                                   \
    "NOT converged"

# -----------------------------------------------------------------
# Acceptance: NO BPW91 without help.  Either converges or LOUDLY
# fails -- no silent false-positive convergence.
# -----------------------------------------------------------------
run_test \
    "NO BPW91 cc-pVDZ (default; expect loud non-conv)" \
    "test_v076_no_uks_bpw91.inp"                       \
    "\\*\\*\\* SCF NOT converged after"                \
    ""

# -----------------------------------------------------------------
# Acceptance: NO BPW91 with level shift -- must converge to a
# sensible energy.
# -----------------------------------------------------------------
run_test \
    "NO BPW91 cc-pVDZ + level_shift=0.20"              \
    "test_v076_no_uks_bpw91_ls.inp"                    \
    "Total energy:.* -129\.89"                         \
    "NOT converged"

# -----------------------------------------------------------------
# Acceptance: CH3O BP86 -- v0.75.1 oscillates with false convergence.
# v0.76.0 must either converge cleanly or report Suspicious-dE.
# -----------------------------------------------------------------
run_test \
    "CH3O BP86 cc-pVDZ (Suspicious-dE diagnostic)"     \
    "test_v076_ch3o_uks_bp86.inp"                      \
    "(Suspicious|NOT converged|SCF converged)"        \
    "Total energy:.* +0\.[0-9]"

# -----------------------------------------------------------------
# Acceptance: %initial_guess core fallback works.
# -----------------------------------------------------------------
run_test \
    "%initial_guess core fallback (CH3 SVWN)"          \
    "test_v076_initial_guess_core.inp"                 \
    "Initial guess: core Hamiltonian"                  \
    "NOT converged"

# -----------------------------------------------------------------
# v0.76.1: NO frequency analysis after opt.  Verifies the FD-XC
# kernel NaN fix.  Must produce a finite Hessian, dsyev info=0,
# and a single vibration in the 1850-2000 cm^-1 range.
# -----------------------------------------------------------------
run_test \
    "NO BPW91 freq Hessian (FD-XC kernel NaN fix)"     \
    "test_v076_no_freq_hessian.inp"                    \
    "^     6\\s+19[0-9][0-9]\\."                       \
    "(ERROR dsyev|NaN)"

echo "============================================================"
echo "  Total:  $NTOTAL   PASS: $NPASS   FAIL: $NFAIL"
echo "============================================================"
if [ "$NFAIL" -eq 0 ]; then
    exit 0
else
    exit 1
fi
