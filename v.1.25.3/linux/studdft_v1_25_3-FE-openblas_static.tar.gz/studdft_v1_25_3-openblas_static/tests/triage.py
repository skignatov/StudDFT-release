#!/usr/bin/env python3
# =====================================================================
# StudDFT orphan triage (v1.18.1)
#
# tests/ accumulated 265 input files while the manifest reached only a
# few dozen.  An input nobody runs proves nothing and costs
# maintenance, so every orphan has to end up in one of two states:
# entered in the manifest, or deleted.  This tool does the mechanical
# part of that decision.
#
# It runs each orphan once and classifies the outcome:
#
#   COMPLETES  exit 0 and a final energy in the output.  A draft
#              manifest entry is emitted with an `exit zero` assertion
#              and the energy as a RECORDED value.
#   REFUSES    non-zero exit with a diagnostic.  Draft entry asserts
#              the refusal and the diagnostic text -- these are the
#              most valuable orphans, because negative tests are what
#              the suite is thinnest on.
#   TIMEOUT    exceeded the limit.  Needs a human: either raise the
#              timeout and tag it `release`, or drop it.
#   BROKEN     non-zero exit with no recognisable diagnostic, or empty
#              output.  Usually a test for a feature that has since
#              been removed.  Needs a human.
#
# HONEST WARNING ABOUT WHAT THIS PRODUCES.  Draft entries carry
# src=recorded: they pin the CURRENT behaviour, whatever it is.  That
# turns an orphan into a tripwire, which is a real gain -- a change
# will now be noticed -- but it is not validation, and mass-migrating
# this way pushes the suite's recorded fraction up.  The runner prints
# that fraction on every run for exactly this reason.  Drafts should
# be read before being committed, and any entry whose value can be
# checked against theory, another program or an internal cross-check
# should have its src= upgraded by hand.
#
# Usage:
#   python3 tests/triage.py --limit 50            # dry run, report only
#   python3 tests/triage.py --emit tests/manifest/90_migrated.mf
#
# RESUMABLE.  265 inputs at up to a minute each is longer than most
# sessions, so every classification is appended to a state file as it
# happens (--state, default tests/.triage_state.tsv) and already
# classified inputs are skipped on the next run.  Work in chunks with
# --limit; the draft manifest is rebuilt from the full state each
# time, so it is always complete for whatever has been done so far.
# =====================================================================

import argparse
import os
import re
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

ENERGY_RX = re.compile(r"^ +Total energy: +(-?\d+\.\d+)", re.M)
DIAG_RX = re.compile(r"^ \*\*\* ERROR:?\s*(.+?)\s*$", re.M)


def manifest_inputs(mdir):
    used = set()
    for mf in sorted(Path(mdir).glob("*.mf")):
        for line in mf.read_text(encoding="utf-8").split("\n"):
            line = line.split("#", 1)[0]
            m = re.match(r"\s*input\s*=\s*(\S+)", line)
            if m:
                used.add(m.group(1).strip())
    return used


def slug(path):
    s = Path(path).stem.lower()
    s = re.sub(r"[^a-z0-9]+", "_", s).strip("_")
    return "mig_" + s


def classify(exe, inp, timeout):
    env = dict(os.environ)
    env["OMP_NUM_THREADS"] = "1"
    # See the working-directory note in runner.py: StudDFT looks for
    # data under $STUDDFT/basis_data first and only falls back to the
    # CWD, so each run gets its own scratch directory and artefacts
    # cannot collide.
    env.setdefault("STUDDFT", str(ROOT))  # respect the user setting
    work = ROOT / "test_work" / "_triage"
    work.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    try:
        p = subprocess.run([str(exe), str(ROOT / inp)], cwd=str(work), env=env,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           timeout=timeout)
        out = p.stdout.decode("utf-8", errors="replace")
        rc = p.returncode
    except subprocess.TimeoutExpired:
        return "TIMEOUT", None, None, timeout
    wall = time.time() - t0

    energies = ENERGY_RX.findall(out)
    diags = DIAG_RX.findall(out)

    if rc == 0 and energies:
        return "COMPLETES", energies[-1], None, wall
    if rc != 0 and diags:
        return "REFUSES", None, diags[0], wall
    if rc == 0:
        # finished without an energy: a utility run (export, analysis)
        return "COMPLETES", None, None, wall
    return "BROKEN", None, (diags[0] if diags else None), wall


def draft(kind, tid, inp, energy, diag, wall):
    to = max(60, int(wall * 6))
    L = ["[test]",
         "id      = %s" % tid,
         "input   = %s" % inp,
         "tags    = migrated, %s" % ("negative" if kind == "REFUSES" else "regression"),
         "timeout = %d" % to]
    if kind == "REFUSES":
        L.append("assert  = exit nonzero")
        if diag:
            # re.escape() escapes the space character on some Python
            # builds, and "a\ b" then matches nothing.  Escape only
            # what is actually special here and keep spaces literal.
            lit = re.sub(r'([.^$*+?()\[\]{}|\\])', r'\\\1', diag[:48])
            L.append('assert  = contains "%s"' % lit)
    else:
        L.append("assert  = exit zero")
        if energy:
            # occurrence=last, because classify() records energies[-1].
            # Emitting an assertion that reads the FIRST match while
            # recording the LAST produced 17 false failures the first
            # time the full suite ran on another compiler: for MP2 the
            # first "Total energy:" is the HF reference, for a scan it
            # is the first grid point, for BSSE the dimer.
            #
            # tol=1e-6, not 1e-8.  These values are recorded on one
            # compiler and checked on another; the observed spread
            # across gfortran and Intel Fortran reaches 1e-6 Ha on a
            # frequency run.  1e-6 is still a tripwire worth having --
            # it is 0.0006 kcal/mol -- and it does not cry wolf.
            L.append('assert  = value "^ +Total energy:" occurrence=last '
                     'field=3 eq=%s tol=1e-6 src=recorded' % energy)
    return "\n".join(L) + "\n"


def read_state(path):
    st = {}
    if Path(path).exists():
        for line in Path(path).read_text(encoding="utf-8").split("\n"):
            if not line.strip():
                continue
            f = line.split("\t")
            if len(f) >= 5:
                st[f[0]] = (f[1], f[2] or None, f[3] or None, float(f[4]))
    return st


def append_state(path, inp, kind, energy, diag, wall):
    with open(path, "a", encoding="utf-8") as fh:
        fh.write("%s\t%s\t%s\t%s\t%.3f\n"
                 % (inp, kind, energy or "", (diag or "").replace("\t", " "), wall))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exe", default=str(ROOT / "studdft"))
    ap.add_argument("--state", default=str(HERE / ".triage_state.tsv"))
    ap.add_argument("--manifest-dir", default=str(HERE / "manifest"))
    ap.add_argument("--timeout", type=int, default=45)
    ap.add_argument("--limit", type=int, default=0, help="0 = all")
    ap.add_argument("--emit", default=None, help="write draft manifest here")
    ap.add_argument("--skip", default="", help="regex of inputs to leave alone")
    args = ap.parse_args()

    exe = Path(args.exe)
    if os.name == "nt" and not exe.suffix:
        exe = exe.with_suffix(".exe")
    if not exe.exists():
        sys.exit("executable not found: %s" % exe)

    used = manifest_inputs(args.manifest_dir)
    skip_rx = re.compile(args.skip) if args.skip else None
    orphans = [str(p.relative_to(ROOT)) for p in sorted((ROOT / "tests").glob("*.inp"))
               if str(p.relative_to(ROOT)) not in used
               and not (skip_rx and skip_rx.search(p.name))]

    # NOTE: --limit caps the work done in THIS run, and is applied to
    # the not-yet-classified list below.  Applying it to `orphans`
    # here as well (as the pre-resume version did) silently truncates
    # the universe, so the tool reports itself finished after --limit
    # files no matter how many remain.
    state = read_state(args.state)
    todo = [o for o in orphans if o not in state]
    if args.limit:
        todo = todo[:args.limit]

    print("orphans %d, already classified %d, running %d now (timeout %d s)\n"
          % (len(orphans), len(orphans) - len([o for o in orphans if o not in state]),
             len(todo), args.timeout))
    for i, inp in enumerate(todo, 1):
        kind, energy, diag, wall = classify(exe, inp, args.timeout)
        append_state(args.state, inp, kind, energy, diag, wall)
        state[inp] = (kind, energy, diag, wall)
        tag = {"COMPLETES": "ok  ", "REFUSES": "refu", "TIMEOUT": "TIME",
               "BROKEN": "BRK "}[kind]
        print("  [%3d/%3d] %s %-56s %5.1fs %s"
              % (i, len(todo), tag, Path(inp).name, wall,
                 (energy or (diag[:32] if diag else ""))), flush=True)

    buckets = {"COMPLETES": [], "REFUSES": [], "TIMEOUT": [], "BROKEN": []}
    drafts = []
    for inp in orphans:
        if inp not in state:
            continue
        kind, energy, diag, wall = state[inp]
        buckets[kind].append(inp)
        if kind in ("COMPLETES", "REFUSES"):
            drafts.append(draft(kind, slug(inp), inp, energy, diag, wall))

    print("\n" + "=" * 66)
    for k in ("COMPLETES", "REFUSES", "TIMEOUT", "BROKEN"):
        print("  %-10s %d" % (k, len(buckets[k])))
    print("=" * 66)
    for k in ("TIMEOUT", "BROKEN"):
        if buckets[k]:
            print("\n%s -- need a human decision:" % k)
            for f in buckets[k]:
                print("   %s" % f)

    if args.emit and drafts:
        head = ("# Migrated orphans, generated by tests/triage.py.\n"
                "#\n"
                "# Every assertion here is src=recorded: it pins the behaviour\n"
                "# observed at migration time, not a validated result. That is\n"
                "# enough to notice a CHANGE and never enough to prove\n"
                "# correctness. Upgrade src= by hand wherever a value can be\n"
                "# checked against theory, another program, or an internal\n"
                "# cross-check, and move the entry into a topic manifest.\n"
                "#\n"
                "# Entries are tagged `migrated` so this batch can be excluded\n"
                "# (--tags smoke) until it has been reviewed.\n\n")
        Path(args.emit).write_text(head + "\n".join(drafts), encoding="utf-8")
        print("\nwrote %d draft entries to %s" % (len(drafts), args.emit))
    return 0


if __name__ == "__main__":
    sys.exit(main())
