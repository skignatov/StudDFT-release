#!/bin/bash
# =============================================================
# StudDFT v0.69.0 -- Rigid PES Scan Regression Test Suite
# =============================================================
#
# Runs every test_v069_*.inp under tests/ and verifies:
#   * the binary exits with status 0 for valid inputs;
#   * the binary exits with non-zero status and prints a clean
#     diagnostic for invalid inputs (test_v069_*_no_*.inp,
#     test_v069_*_bad_*.inp, test_v069_*_too_*.inp);
#   * the special cross-check test_v069_scan_vs_singlepoints.sh
#     reproduces every grid-point energy from a stand-alone
#     single-point at the same geometry, to <1e-9 Ha.
#
# Usage: ./run_v069_tests.sh [path_to_studdft]
# =============================================================

set -u
EXE=${1:-./studdft}
cd "$(dirname "$0")/.."
export STUDDFT="$PWD"

PASS=0
FAIL=0

# ----- Positive tests: must exit 0 and produce a "summary" block -----
for inp in tests/test_v069_h2_scan.inp \
           tests/test_v069_hooh_dihedral_scan.inp \
           tests/test_v069_h2o_2d_scan.inp \
           tests/test_v069_h2o_b3lyp_scan.inp \
           tests/test_v069_h2_ref_at_0p70.inp; do
    name=$(basename "$inp" .inp)
    if "$EXE" "$inp" > /tmp/${name}.out 2>&1; then
        if grep -q "Rigid PES scan -- summary\|Total energy" /tmp/${name}.out; then
            printf "  PASS  %s\n" "$name"
            PASS=$((PASS+1))
        else
            printf "  FAIL  %s  (no summary in output)\n" "$name"
            FAIL=$((FAIL+1))
        fi
    else
        printf "  FAIL  %s  (exit code != 0)\n" "$name"
        FAIL=$((FAIL+1))
    fi
done

# ----- Negative tests: must exit non-zero with a clear ERROR line -----
for inp in tests/test_v069_scan_no_zmat.inp \
           tests/test_v069_scan_no_block.inp \
           tests/test_v069_scan_bad_kind.inp \
           tests/test_v069_scan_bad_row.inp \
           tests/test_v069_scan_angle_too_early.inp; do
    name=$(basename "$inp" .inp)
    "$EXE" "$inp" > /tmp/${name}.out 2>&1
    rc=$?
    if [ $rc -ne 0 ] && grep -q "ERROR" /tmp/${name}.out; then
        printf "  PASS  %s  (clean diagnostic, rc=%d)\n" "$name" "$rc"
        PASS=$((PASS+1))
    else
        printf "  FAIL  %s  (expected non-zero exit + ERROR; rc=%d)\n" \
            "$name" "$rc"
        FAIL=$((FAIL+1))
    fi
done

# ----- Cross-validation: scan points vs stand-alone single-points -----
if ./tests/test_v069_scan_vs_singlepoints.sh > /tmp/xcheck.out 2>&1; then
    printf "  PASS  test_v069_scan_vs_singlepoints  (9 pts to <1e-9 Ha)\n"
    PASS=$((PASS+1))
else
    printf "  FAIL  test_v069_scan_vs_singlepoints\n"
    cat /tmp/xcheck.out
    FAIL=$((FAIL+1))
fi

echo
echo "  Summary:  $PASS passed, $FAIL failed."
echo
[ $FAIL -eq 0 ] && exit 0 || exit 1
