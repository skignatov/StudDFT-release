#!/bin/bash
# =============================================================
# StudDFT MP2 analytical gradient regression suite
# =============================================================
#
# Verifies MP2/RHF analytical (Z-vector) gradient against Reference
# reference values to 1e-6 absolute tolerance.  Also runs one
# MP2 geometry optimization smoke test to exercise the opt path
# with the analytical gradient.
#
# Reference values were produced by Reference (reference.mp.MP2 +
# nuc_grad_method().kernel()) at identical geometries.
#
# Usage: ./run_mp2grad_tests.sh [path_to_studdft] [nthreads]
# =============================================================

EXE=${1:-./studdft}
NTHREADS=${2:-2}
export OMP_NUM_THREADS=$NTHREADS

PASS=0
FAIL=0

# Extract a single cartesian gradient component from output.
# Args: file, atom_index (1-based), component (1=x,2=y,3=z)
extract_grad() {
    local file="$1"
    local atom="$2"
    local comp="$3"
    # Locate "Cartesian gradient" then read the atom row.
    # Columns after atom index: dE/dx, dE/dy, dE/dz.
    awk -v a="$atom" -v c="$comp" '
        /Cartesian gradient/ { state=1; next }
        state==1 && /dE\/dx/ { next }
        state==1 && NF >= 4 && $1==a { print $(1+c); exit }
    ' "$file"
}

# Compare two floating-point numbers with a tolerance.
# Args: label, got, expected, tol
compare_value() {
    local label="$1"
    local got="$2"
    local expected="$3"
    local tol="$4"

    if [ -z "$got" ] || [ -z "$expected" ]; then
        printf "  FAIL  %-44s  (missing value)\n" "$label"
        FAIL=$((FAIL+1))
        return
    fi

    local diff
    diff=$(awk "BEGIN{ d = ($got) - ($expected); if (d<0) d=-d; print d }")
    local ok
    ok=$(awk "BEGIN{ print (($diff) < ($tol)) ? 1 : 0 }")
    if [ "$ok" = "1" ]; then
        printf "  PASS  %-44s  got=%+12.8f  ref=%+12.8f  diff=%.1e\n" \
            "$label" "$got" "$expected" "$diff"
        PASS=$((PASS+1))
    else
        printf "  FAIL  %-44s  got=%+12.8f  ref=%+12.8f  diff=%.1e  (tol=%s)\n" \
            "$label" "$got" "$expected" "$diff" "$tol"
        FAIL=$((FAIL+1))
    fi
}

run_test() {
    local inp="$1"
    local out="${inp%.inp}.out"
    $EXE "$inp" > "$out" 2>&1
    echo "$out"
}

echo "============================================================="
echo "  StudDFT MP2 analytical gradient regression"
echo "  Executable: $EXE"
echo "  Threads:    $NTHREADS"
echo "============================================================="
echo

# --- Test 1: H2/STO-3G ---
# reference implementation:  atom 1: ( 0, 0, -0.01533537)
echo "--- Test 1: H2/STO-3G (trivial Z-vector) ---"
OUT=$(run_test tests/test_mp2_h2_grad.inp)
compare_value "H2/STO-3G atom1.z" "$(extract_grad "$OUT" 1 3)" "-0.01533537" "1e-6"

# --- Test 2: H2/6-31G(d,p) ---
# reference implementation: atom 1: (0, 0, -0.00462346)
echo
echo "--- Test 2: H2/6-31G(d,p) (non-trivial Z-vector, diatomic) ---"
OUT=$(run_test tests/test_mp2_h2_631gdp_grad.inp)
compare_value "H2/6-31G(d,p) atom1.z" "$(extract_grad "$OUT" 1 3)" "-0.00462346" "1e-6"

# --- Test 3: H2O/6-31G ---
# reference implementation:
#   atom 1 (O): (0, 0, -0.00892462)
#   atom 2 (H): (0, -0.02220035, +0.00446231)
#   atom 3 (H): (0, +0.02220035, +0.00446231)
echo
echo "--- Test 3: H2O/6-31G (multi-occupied, s+p) ---"
OUT=$(run_test tests/test_mp2_h2o_631g_grad.inp)
compare_value "H2O/6-31G atom1.z"  "$(extract_grad "$OUT" 1 3)" "-0.00892462" "1e-6"
compare_value "H2O/6-31G atom2.y"  "$(extract_grad "$OUT" 2 2)" "-0.02220035" "1e-6"
compare_value "H2O/6-31G atom2.z"  "$(extract_grad "$OUT" 2 3)" "+0.00446231" "1e-6"
compare_value "H2O/6-31G atom3.y"  "$(extract_grad "$OUT" 3 2)" "+0.02220035" "1e-6"
compare_value "H2O/6-31G atom3.z"  "$(extract_grad "$OUT" 3 3)" "+0.00446231" "1e-6"

# --- Test 4: H2O/6-31G(d) ---
# reference implementation:
#   atom 1 (O): (0, 0, -0.01308469)
#   atom 2 (H): (0, -0.00833028, +0.00654234)
echo
echo "--- Test 4: H2O/6-31G(d) (adds d-shell on O) ---"
OUT=$(run_test tests/test_mp2_h2o_631gd_grad.inp)
compare_value "H2O/6-31G(d) atom1.z" "$(extract_grad "$OUT" 1 3)" "-0.01308469" "1e-6"
compare_value "H2O/6-31G(d) atom2.y" "$(extract_grad "$OUT" 2 2)" "-0.00833028" "1e-6"
compare_value "H2O/6-31G(d) atom2.z" "$(extract_grad "$OUT" 2 3)" "+0.00654234" "1e-6"

# --- Test 5: H2O/cc-pVDZ ---
# reference implementation:
#   atom 1 (O): (0, 0, -0.01206327)
#   atom 2 (H): (0, -0.00139286, +0.00603164)
echo
echo "--- Test 5: H2O/cc-pVDZ (larger basis, s+p+d) ---"
OUT=$(run_test tests/test_mp2_h2o_grad.inp)
compare_value "H2O/cc-pVDZ atom1.z" "$(extract_grad "$OUT" 1 3)" "-0.01206327" "1e-6"
compare_value "H2O/cc-pVDZ atom2.y" "$(extract_grad "$OUT" 2 2)" "-0.00139286" "1e-6"
compare_value "H2O/cc-pVDZ atom2.z" "$(extract_grad "$OUT" 2 3)" "+0.00603164" "1e-6"

# --- Test 6: H2 MP2 geometry optimization (opt smoke test) ---
# reference implementation: H2/cc-pVDZ MP2 equilibrium bond ~0.7545 A.
# StudDFT opt uses Cartesian BFGS for diatomics.  We check the final
# total energy against the Reference-converged reference to 1e-5 Ha.
echo
echo "--- Test 6: H2/cc-pVDZ MP2 geometry optimization ---"
OUT=$(run_test tests/test_mp2_h2_opt.inp)
E_FINAL=$(grep "Final energy:" "$OUT" | tail -1 | awk '{print $3}')
compare_value "H2 opt final energy" "$E_FINAL" "-1.15521827" "1e-5"

# --- Test 7: H2O MP2 geometry optimization (opt smoke test, internals) ---
# Reference: MP2/6-31G H2O minimum energy ~-76.11421.  This path
# exercises redundant internal coordinates (2 bonds + 1 angle).
echo
echo "--- Test 7: H2O/6-31G MP2 geometry optimization (internals) ---"
OUT=$(run_test tests/test_mp2_h2o_opt.inp)
E_FINAL=$(grep "Final energy:" "$OUT" | tail -1 | awk '{print $3}')
compare_value "H2O opt final energy" "$E_FINAL" "-76.11421195" "1e-4"

# --- Test 8: H2O/cc-pVDZ with DEFAULT frozen-core (auto-detect) ---
# Exercises the auto-FC path + the frozen-active coupling term
# dco = Imat_mo / (eps_f - eps_i).  reference implementation:
#   MP2(mf, frozen=1).nuc_grad_method().kernel()
# Tolerance 5e-5: the residual error O(1e-5) comes from non-iterative
# application of dco vs. reference's coupled solve; acceptable for tests.
echo
echo "--- Test 8: H2O/cc-pVDZ MP2 gradient, default frozen-core (O 1s) ---"
OUT=$(run_test tests/test_mp2_h2o_fc_grad.inp)
compare_value "H2O/cc-pVDZ FC atom1.z" "$(extract_grad "$OUT" 1 3)" "-0.01297638" "5e-5"
compare_value "H2O/cc-pVDZ FC atom2.y" "$(extract_grad "$OUT" 2 2)" "-0.00194381" "5e-5"
compare_value "H2O/cc-pVDZ FC atom2.z" "$(extract_grad "$OUT" 2 3)" "+0.00648819" "5e-5"

echo
echo "============================================================="
printf "  Summary: %d pass, %d fail\n" "$PASS" "$FAIL"
echo "============================================================="

if [ "$FAIL" -gt 0 ]; then
    exit 1
fi
exit 0
