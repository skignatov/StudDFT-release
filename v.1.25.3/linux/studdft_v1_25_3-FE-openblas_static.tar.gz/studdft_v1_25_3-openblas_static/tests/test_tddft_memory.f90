! ============================================================================
! StudDFT -- unit test for the TDDFT memory forecast (v1.16.2)
!
! Build:  make test_tddft_memory && ./test_tddft_memory
!
! WHAT THIS TEST IS FOR
! ---------------------
! v1.16.2 replaced the fixed dense-solver cap on nocc*nvir with a byte-based
! forecast.  The argument for that change is quantitative, so it is checked
! here rather than asserted in a comment:
!
!   Case A and Case B below have the SAME nocc*nvir = 1000 and therefore
!   the same dense (A+-B) matrices, but their peak working sets differ by
!   more than an order of magnitude because nbf differs.  Any cap expressed
!   in nov must be either uselessly loose for A or wrongly strict for B.
!
! The remaining cases pin the individual scaling terms so that a future
! refactor of the transform cannot silently change what is predicted
! without this test noticing.
!
! No SCF is run; the forecast depends only on nbf, nocc, nvir and the
! functional/environment flags.
! ============================================================================
program test_tddft_memory
    use constants, only: dp
    use tddft,     only: tddft_memory_forecast
    implicit none

    integer :: nfail
    real(dp) :: peak, solver

    nfail = 0

    write(*,'(A)') '=========================================='
    write(*,'(A)') ' TDDFT memory forecast -- unit test'
    write(*,'(A)') '=========================================='
    write(*,'(A)') ''

    ! ------------------------------------------------------------------
    ! Case A: compact basis, many occupied.  nbf = 100, nocc = 20,
    ! nvir = 50  ->  nov = 1000.
    !   phase 2 = nbf^2*nvir^2 + nov^2 + nocc^2*nvir^2
    !           = 1e4*2500 + 1e6 + 400*2500
    !           = 2.5e7 + 1.0e6 + 1.0e6 = 2.70e7 doubles = 205.99 MB
    !   (MB here and below is 2^20 bytes, matching the program output)
    ! ------------------------------------------------------------------
    call tddft_memory_forecast(100, 20, 50, 0.20_dp, .false., .false., &
                               peak, solver)
    call check('A: nbf=100 nocc=20 nvir=50 (hybrid)', peak, 205.99_dp, nfail)

    ! ------------------------------------------------------------------
    ! Case B: SAME nov = 1000, diffuse basis.  nbf = 400, nocc = 4,
    ! nvir = 250.
    !   phase 2 = 1.6e5*62500 + 1e6 + 16*62500
    !           = 1.0e10 + 1.0e6 + 1.0e6 = 1.00020e10 doubles
    !           = 76309.20 MB
    ! Same dense solver, 370x the peak.  This is the test's point.
    ! ------------------------------------------------------------------
    call tddft_memory_forecast(400, 4, 250, 0.20_dp, .false., .false., &
                               peak, solver)
    call check('B: nbf=400 nocc=4  nvir=250 (same nov!)', peak, &
               76309.20_dp, nfail)

    ! ------------------------------------------------------------------
    ! Case C: pure functional, no exact exchange -- OOVV is never built,
    ! so phase 2 does not exist and phase 1 sets the peak.
    !   phase 1 = nbf^2*nocc*nvir + nov^2
    !           = 1e4*1000 + 1e6 = 1.1e7 doubles = 83.92 MB
    !   phase 4 = OVOV + 3*nov^2 = 4e6 doubles = 30.52 MB
    ! ------------------------------------------------------------------
    call tddft_memory_forecast(100, 20, 50, 0.0_dp, .false., .false., &
                               peak, solver)
    call check('C: pure GGA, no OOVV (peak)  ', peak,   83.92_dp, nfail)
    call check('C: pure GGA, no OOVV (solver)', solver, 30.52_dp, nfail)

    ! ------------------------------------------------------------------
    ! Case D: range-separated hybrid -- the attenuated copies OVOV_X and
    ! OOVV_X plus the T4 scratch make phase 3 the peak.
    !   phase 3 = nbf^2*nvir^2 + 2*(nov^2 + nocc^2*nvir^2) + max(...)
    !           = 2.5e7 + 2*(1e6 + 1e6) + 1e6 = 3.00e7 doubles = 228.88 MB
    ! ------------------------------------------------------------------
    call tddft_memory_forecast(100, 20, 50, 0.20_dp, .true., .false., &
                               peak, solver)
    call check('D: range-separated hybrid    ', peak, 228.88_dp, nfail)

    ! ------------------------------------------------------------------
    ! Case E: PCM adds exactly one more nov x nov block (Kpcm) to the
    ! solver phase.  Peak is still phase 2 here, so only solver moves:
    !   phase 4 = OVOV + OOVV + 3*nov^2 + nov^2
    !           = 1e6 + 1e6 + 3e6 + 1e6 = 6.0e6 doubles = 45.78 MB
    ! ------------------------------------------------------------------
    call tddft_memory_forecast(100, 20, 50, 0.20_dp, .false., .true., &
                               peak, solver)
    call check('E: hybrid + PCM (solver)     ', solver, 45.78_dp, nfail)

    ! ------------------------------------------------------------------
    ! Case F: no 32-bit overflow.  nbf = 1200, nvir = 1000 gives
    ! nbf^2*nvir^2 = 1.44e12 doubles; a default INTEGER product would
    ! have wrapped long before.  Just require a sane positive result.
    ! ------------------------------------------------------------------
    call tddft_memory_forecast(1200, 100, 1000, 0.20_dp, .false., &
                               .false., peak, solver)
    if (peak > 1.0e13_dp .and. peak < 1.0e14_dp) then
        write(*,'(A,ES12.4,A)') ' PASS  F: no integer overflow    ', &
            peak / 1048576.0_dp, ' MB'
    else
        write(*,'(A,ES12.4)') ' FAIL  F: no integer overflow    ', peak
        nfail = nfail + 1
    end if

    write(*,'(A)') ''
    if (nfail == 0) then
        write(*,'(A)') ' ALL TESTS PASSED'
    else
        write(*,'(A,I0,A)') ' ', nfail, ' TEST(S) FAILED'
        error stop 1
    end if

contains

    ! Compare a forecast (bytes) against an expected value in MB.
    ! Tolerance 0.05 MB absolute or 1e-4 relative, whichever is looser:
    ! the expected values above are written to 1-2 decimals by hand.
    subroutine check(label, bytes, expect_mb, nfail)
        character(len=*), intent(in)    :: label
        real(dp),         intent(in)    :: bytes, expect_mb
        integer,          intent(inout) :: nfail

        real(dp) :: got_mb, tol

        got_mb = bytes / 1048576.0_dp
        tol    = max(0.05_dp, 1.0e-4_dp * expect_mb)

        if (abs(got_mb - expect_mb) <= tol) then
            write(*,'(A,A,A,F12.2,A)') ' PASS  ', label, '  ', &
                got_mb, ' MB'
        else
            write(*,'(A,A,A,F12.2,A,F12.2,A)') ' FAIL  ', label, &
                '  got ', got_mb, ' MB, expected ', expect_mb, ' MB'
            nfail = nfail + 1
        end if
    end subroutine check

end program test_tddft_memory
