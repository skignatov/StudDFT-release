! ============================================================================
! StudDFT -- D3(BJ) analytical-vs-numerical gradient regression test
!
! Builds a small test "molecule" (no basis, no SCF), calls
! compute_d3_energy and compute_d3_gradient directly, then verifies the
! analytical gradient against a central-difference numerical gradient.
!
! Passes if max |grad_analytic - grad_numeric| < 1.0e-8 Ha/Bohr.
!
! This isolates dispersion.f90 from the rest of StudDFT and is the most
! reliable way to catch sign errors in the CN back-propagation pass.
! ============================================================================
program test_d3_grad
    use constants, only: dp
    use types,     only: molecule_t, atom_t, atom_init
    use dispersion
    implicit none

    type(molecule_t)          :: mol
    type(dispersion_params_t) :: p
    real(dp), allocatable :: grad_an(:,:), grad_fd(:,:)
    real(dp) :: E0, Ep, Em, h, diff_max
    integer  :: i, k, ierr, nat
    real(dp) :: save_coord
    character(len=512) :: dpath

    ! --- 1. Build a small H/C/O test cluster: CH4 ... H2O dimer ---
    nat = 8
    mol%natom = nat
    allocate(mol%atoms(nat))
    do i = 1, nat
        call atom_init(mol%atoms(i))
    end do
    ! CH4 at origin
    mol%atoms(1)%atomic_number = 6
    mol%atoms(1)%coords = [0.0_dp, 0.0_dp, 0.0_dp]
    mol%atoms(2)%atomic_number = 1
    mol%atoms(2)%coords = [ 1.186_dp,  1.186_dp,  1.186_dp]
    mol%atoms(3)%atomic_number = 1
    mol%atoms(3)%coords = [-1.186_dp, -1.186_dp,  1.186_dp]
    mol%atoms(4)%atomic_number = 1
    mol%atoms(4)%coords = [-1.186_dp,  1.186_dp, -1.186_dp]
    mol%atoms(5)%atomic_number = 1
    mol%atoms(5)%coords = [ 1.186_dp, -1.186_dp, -1.186_dp]
    ! H2O shifted along +x
    mol%atoms(6)%atomic_number = 8
    mol%atoms(6)%coords = [ 7.0_dp,  0.0_dp,  0.0_dp]
    mol%atoms(7)%atomic_number = 1
    mol%atoms(7)%coords = [ 7.8_dp,  1.5_dp,  0.0_dp]
    mol%atoms(8)%atomic_number = 1
    mol%atoms(8)%coords = [ 7.8_dp, -1.5_dp,  0.0_dp]

    ! --- 2. Setup D3(BJ) parameters for BP86 ---
    call setup_dispersion('D3BJ', 'BP86', p, ierr)
    if (ierr /= 0) stop 'setup_dispersion failed'
    ! v1.20.3: resolve data files through $STUDDFT like the rest of
    ! the program.  These two paths were hardcoded relative to the
    ! current directory, which is the documented FALLBACK and not the
    ! rule (driver_jobs.f90:2193).  That made this the only test that
    ! could not run outside the repository root -- and to accommodate
    ! it every [program] entry was exempted from per-test working
    ! directories, so test_hessian_io scattered test_hio_*.hess into
    ! the root on every run.  One hardcoded path, two problems.
    call d3_data_path('d3_atomic.dat', dpath)
    call load_d3_atomic(trim(dpath), ierr)
    if (ierr /= 0) stop 'load_d3_atomic failed'
    call d3_data_path('d3_c6ref.dat', dpath)
    call load_d3_reference(trim(dpath), ierr)
    if (ierr /= 0) stop 'load_d3_reference failed'
    call print_dispersion_info(p)

    ! --- 3. Analytical gradient ---
    allocate(grad_an(3, nat), grad_fd(3, nat))
    grad_an = 0.0_dp
    call compute_d3_energy(mol, p, E0)
    call compute_d3_gradient(mol, p, grad_an)
    write(*,'(/,A,F20.12,A)') '  E_disp (analytical) = ', E0, '   Ha'

    ! --- 4. Numerical gradient via central differences ---
    h = 1.0e-5_dp
    grad_fd = 0.0_dp
    do i = 1, nat
        do k = 1, 3
            save_coord = mol%atoms(i)%coords(k)
            mol%atoms(i)%coords(k) = save_coord + h
            call compute_d3_energy(mol, p, Ep)
            mol%atoms(i)%coords(k) = save_coord - h
            call compute_d3_energy(mol, p, Em)
            mol%atoms(i)%coords(k) = save_coord
            grad_fd(k, i) = (Ep - Em) / (2.0_dp * h)
        end do
    end do

    ! --- 5. Compare ---
    write(*,'(/,A)')  '  Gradient comparison (analytical vs central-diff):'
    write(*,'(A)')    '  atom k      analytical         numerical         diff'
    diff_max = 0.0_dp
    do i = 1, nat
        do k = 1, 3
            write(*,'(2X,I3,1X,I2,3(2X,ES16.8))') &
                i, k, grad_an(k,i), grad_fd(k,i), grad_an(k,i)-grad_fd(k,i)
            diff_max = max(diff_max, abs(grad_an(k,i)-grad_fd(k,i)))
        end do
    end do

    write(*,'(/,A,ES12.4)') '  max |grad_an - grad_fd| = ', diff_max
    if (diff_max < 1.0e-8_dp) then
        write(*,'(A)') '  RESULT: PASSED   (analytical grad matches FD to 1e-8)'
    else if (diff_max < 1.0e-6_dp) then
        write(*,'(A)') '  RESULT: MARGINAL (1e-8 .. 1e-6 Ha/Bohr residual)'
    else
        write(*,'(A)') '  RESULT: FAILED   (> 1e-6 Ha/Bohr residual)'
    end if

    deallocate(grad_an, grad_fd, mol%atoms)

contains

    ! Same resolution order the program uses: $STUDDFT/basis_data/<name>
    ! when the variable is set, the relative path otherwise.
    subroutine d3_data_path(name, path)
        character(len=*), intent(in)  :: name
        character(len=*), intent(out) :: path
        character(len=480) :: root
        integer :: ilen
        call get_environment_variable('STUDDFT', root, ilen)
        if (ilen > 0) then
            if (root(ilen:ilen) /= '/' .and. root(ilen:ilen) /= '\\') then
                root(ilen+1:ilen+1) = '/'
                ilen = ilen + 1
            end if
            path = root(1:ilen) // 'basis_data/' // trim(name)
        else
            path = 'basis_data/' // trim(name)
        end if
    end subroutine d3_data_path

end program test_d3_grad
