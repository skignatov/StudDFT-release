! ============================================================================
! StudDFT v0.72.0-dev -- Standalone test for bofill_hessian_update
! (the sign-preserving Hessian update used by the P-RFO transition-state
! optimizer; cf. handoff document section "What is NOT YET done").
!
! Four checks:
!
!   (1) Secant equation.  After a single Bofill update with a
!       synthetic (s, y) pair, the updated Hessian must satisfy
!       H_new * s = y to machine precision.  This is the property
!       that any quasi-Newton update is supposed to enforce; we verify
!       it as a basic sanity test.
!
!   (2) No-update on |s| = 0.  Pass a zero step; H must come back
!       unchanged.  Guards against NaNs from a 0/0 in the formula.
!
!   (3) No-update on y = H*s exactly.  When the residual E = y - H*s
!       is zero, there is nothing to update; H must come back
!       unchanged.
!
!   (4) Negative-eigenvalue PRESERVATION.  The whole point of using
!       Bofill instead of BFGS for TS search.  Setup:
!         - H_true has eigenvalues (-2, +1, +3) (one negative mode).
!         - Initial H_iter = I (all eigenvalues +1, no negative mode yet).
!         - Apply a sequence of Bofill updates with synthetic (s_k, y_k)
!           pairs where y_k = H_true * s_k (i.e. an exact-quadratic
!           gradient-change history).
!         - After enough updates the iterated H must converge to H_true
!           and in particular acquire the negative eigenvalue.
!       BFGS with Powell damping would deliberately PREVENT this, which
!       is why we cannot use it for TS optimization.
!
! Build:
!   make test_bofill_update
! Run:
!   ./test_bofill_update
! ============================================================================
program test_bofill_update
    use constants, only: dp
    use optimizer_module, only: bofill_hessian_update
    implicit none

    integer :: nfail
    nfail = 0

    write(*,'(A)') 'test_bofill_update: secant equation, guards, sign preservation'
    write(*,'(A)') '----------------------------------------------------------------'

    call check1_secant(nfail)
    call check2_zero_step(nfail)
    call check3_zero_residual(nfail)
    call check4_neg_eig_preserved(nfail)

    write(*,'(A)') '----------------------------------------------------------------'
    if (nfail == 0) then
        write(*,'(A)') 'ALL CHECKS PASS.'
    else
        write(*,'(A,I0,A)') 'FAILED: ', nfail, ' check(s).'
        stop 1
    end if

contains

    ! --- Check 1: secant equation H_new * s = y -----------------------------
    subroutine check1_secant(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 3
        real(dp) :: H(n, n), s(n), y(n), Hs(n)
        real(dp) :: max_err
        integer :: i

        ! Start with H = identity
        H = 0.0_dp
        do i = 1, n
            H(i, i) = 1.0_dp
        end do

        ! Step in some direction
        s = [ 0.5_dp, -0.3_dp, 0.7_dp ]
        ! Synthetic gradient change (does not have to come from a true H;
        ! the secant condition is a definition of the update).
        y = [ 0.6_dp,  0.1_dp, 0.9_dp ]

        call bofill_hessian_update(H, s, y, n)

        ! Verify H_new * s = y
        call dgemv('N', n, n, 1.0_dp, H, n, s, 1, 0.0_dp, Hs, 1)
        max_err = maxval(abs(Hs - y))

        if (max_err < 1.0e-12_dp) then
            write(*,'(A,ES10.2)') '  (1) Secant equation H*s = y          PASS  max|Hs - y| = ', max_err
        else
            write(*,'(A,ES10.2)') '  (1) Secant equation H*s = y          FAIL  max|Hs - y| = ', max_err
            nfail = nfail + 1
        end if
    end subroutine check1_secant

    ! --- Check 2: |s| = 0 -> H unchanged ------------------------------------
    subroutine check2_zero_step(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 3
        real(dp) :: H(n, n), Href(n, n), s(n), y(n)
        real(dp) :: max_diff
        integer :: i, j

        H = reshape([ &
              2.0_dp, 0.5_dp, -0.3_dp, &
              0.5_dp, 1.0_dp,  0.7_dp, &
             -0.3_dp, 0.7_dp,  4.0_dp ], shape(H))
        Href = H

        s = 0.0_dp
        y = [ 0.6_dp,  0.1_dp, 0.9_dp ]

        call bofill_hessian_update(H, s, y, n)

        max_diff = 0.0_dp
        do j = 1, n
            do i = 1, n
                max_diff = max(max_diff, abs(H(i, j) - Href(i, j)))
            end do
        end do

        if (max_diff == 0.0_dp) then
            write(*,'(A,ES10.2)') '  (2) Zero-step guard                  PASS  max|dH| = ', max_diff
        else
            write(*,'(A,ES10.2)') '  (2) Zero-step guard                  FAIL  max|dH| = ', max_diff
            nfail = nfail + 1
        end if
    end subroutine check2_zero_step

    ! --- Check 3: y = H*s exactly -> H unchanged ----------------------------
    subroutine check3_zero_residual(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 3
        real(dp) :: H(n, n), Href(n, n), s(n), y(n)
        real(dp) :: max_diff
        integer :: i, j

        H = reshape([ &
              2.0_dp, 0.5_dp, -0.3_dp, &
              0.5_dp, 1.0_dp,  0.7_dp, &
             -0.3_dp, 0.7_dp,  4.0_dp ], shape(H))
        Href = H

        s = [ 0.5_dp, -0.3_dp, 0.7_dp ]
        ! y = H * s, so the residual E = y - H*s is identically zero.
        call dgemv('N', n, n, 1.0_dp, H, n, s, 1, 0.0_dp, y, 1)

        call bofill_hessian_update(H, s, y, n)

        max_diff = 0.0_dp
        do j = 1, n
            do i = 1, n
                max_diff = max(max_diff, abs(H(i, j) - Href(i, j)))
            end do
        end do

        if (max_diff < 1.0e-12_dp) then
            write(*,'(A,ES10.2)') '  (3) Zero-residual guard              PASS  max|dH| = ', max_diff
        else
            write(*,'(A,ES10.2)') '  (3) Zero-residual guard              FAIL  max|dH| = ', max_diff
            nfail = nfail + 1
        end if
    end subroutine check3_zero_residual

    ! --- Check 4: negative eigenvalue preservation --------------------------
    !
    ! Build H_true with eigenvalues (-2, +1, +3) and start with
    ! H_iter = I (all positive).  Run synthetic Bofill updates with
    ! y = H_true * s for a sequence of linearly-independent step
    ! vectors; once the update has seen 3 such (s, y) pairs the
    ! quadratic is fully determined and H_iter must equal H_true.
    ! In particular, the smallest eigenvalue must be < 0.
    !
    ! This is THE key reason Bofill is correct for TS search:  BFGS
    ! with Powell damping under the same input would refuse to lower
    ! its minimum eigenvalue below ~0.
    subroutine check4_neg_eig_preserved(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 3
        real(dp) :: H_true(n, n), H_iter(n, n)
        real(dp) :: V(n, n), e(n), wkA(4*n)
        real(dp) :: s(n), y(n)
        real(dp) :: max_diff, lam_min
        integer :: i, j, info
        ! Define H_true = V * diag(-2, 1, 3) * V^T for an orthonormal V.
        ! Pick a non-trivial V to exercise full off-diagonal coupling:
        !   V_1 = (1, 1, 1)/sqrt(3),  V_2 = (1, -1, 0)/sqrt(2),
        !   V_3 = (1, 1, -2)/sqrt(6)   (Gram-Schmidt of e_x, e_y, e_z
        !   on x+y+z direction)
        real(dp), parameter :: invsq2 = 1.0_dp / sqrt(2.0_dp)
        real(dp), parameter :: invsq3 = 1.0_dp / sqrt(3.0_dp)
        real(dp), parameter :: invsq6 = 1.0_dp / sqrt(6.0_dp)

        V(:, 1) = [ invsq3,  invsq3,  invsq3        ]
        V(:, 2) = [ invsq2, -invsq2,  0.0_dp        ]
        V(:, 3) = [ invsq6,  invsq6, -2.0_dp*invsq6 ]

        e = [ -2.0_dp, 1.0_dp, 3.0_dp ]

        ! H_true = V * diag(e) * V^T
        H_true = 0.0_dp
        do i = 1, n
            do j = 1, n
                H_true(i, j) = e(1)*V(i,1)*V(j,1) &
                              + e(2)*V(i,2)*V(j,2) &
                              + e(3)*V(i,3)*V(j,3)
            end do
        end do

        ! Start: H_iter = I (all eigenvalues +1)
        H_iter = 0.0_dp
        do i = 1, n
            H_iter(i, i) = 1.0_dp
        end do

        ! Three update steps with linearly-independent s vectors.
        ! Each y is obtained as H_true * s, exactly mimicking what an
        ! optimizer would observe along a true quadratic surface.
        block
            real(dp) :: s_list(n, 3)
            integer :: k
            s_list(:, 1) = [ 0.7_dp,  0.2_dp, -0.1_dp ]
            s_list(:, 2) = [ 0.1_dp, -0.5_dp,  0.4_dp ]
            s_list(:, 3) = [ 0.3_dp,  0.6_dp,  0.6_dp ]
            do k = 1, 3
                s = s_list(:, k)
                call dgemv('N', n, n, 1.0_dp, H_true, n, s, 1, 0.0_dp, y, 1)
                call bofill_hessian_update(H_iter, s, y, n)
            end do
        end block

        ! Compare H_iter vs H_true element-wise.
        max_diff = 0.0_dp
        do j = 1, n
            do i = 1, n
                max_diff = max(max_diff, abs(H_iter(i, j) - H_true(i, j)))
            end do
        end do

        ! Diagonalize H_iter and count the eigenvalue sign distribution.
        ! Bofill is a convex combination of SR1 (which has the n+1-step
        ! exact-quadratic property under specific conditions) and PSB
        ! (which does not).  Convergence to the exact H_true is not
        ! guaranteed in 3 steps, but two key qualitative properties must
        ! hold:
        !   - Sign signature: exactly one negative eigenvalue, two
        !     positive (matches H_true's (-2, +1, +3)).  This is THE
        !     property that makes Bofill correct for TS search.
        !   - Closeness: H_iter is in the ballpark of H_true (we use
        !     a generous element-wise tolerance because exact recovery
        !     is not guaranteed).
        block
            real(dp) :: A(n, n)
            integer  :: nneg, npos
            A = H_iter
            call dsyev('V', 'U', n, A, n, e, wkA, 4*n, info)
            lam_min = e(1)
            nneg = 0; npos = 0
            do i = 1, n
                if (e(i) < -0.1_dp) nneg = nneg + 1
                if (e(i) >  0.1_dp) npos = npos + 1
            end do
            if (nneg == 1 .and. npos == 2 .and. &
                abs(lam_min - (-2.0_dp)) < 0.1_dp .and. &
                max_diff < 0.1_dp) then
                write(*,'(A,F8.4,A,ES10.2)') &
                    '  (4) Negative-eig preserved (Bofill)  PASS  lam_min = ', &
                    lam_min, '   max|dH| = ', max_diff
            else
                write(*,'(A,F8.4,A,ES10.2,A,I0,A,I0)') &
                    '  (4) Negative-eig preserved (Bofill)  FAIL  lam_min = ', &
                    lam_min, '   max|dH| = ', max_diff, &
                    '   nneg=', nneg, ', npos=', npos
                nfail = nfail + 1
            end if
        end block
    end subroutine check4_neg_eig_preserved

end program test_bofill_update
