#!/bin/bash
# =============================================================
# StudDFT v0.50.0 -- ECP Hessian Validation Test Suite
# =============================================================
#
# Tests analytical hessian with pseudopotentials (ECP).
# Compares analytical vs numerical frequencies for:
#   - RHF + ECP (HCl, NaCl)
#   - RKS + ECP (HCl SVWN, B3LYP)
#   - UHF + ECP (OH radical)
#   - UKS + ECP (OH radical B3LYP)
#   - OPT+FREQ + ECP
#   - Non-ECP regression
#
# Usage: ./run_tests.sh [path_to_studdft] [nthreads]
# =============================================================

EXE=${1:-./studdft}
NTHREADS=${2:-2}
export OMP_NUM_THREADS=$NTHREADS

PASS=0
FAIL=0
SKIP=0

extract_freq() {
    grep "Mode.*:.*cm" "$1" | head -1 | sed 's/.*:\s*//' | awk '{print $1}'
}

extract_all_freq() {
    grep "Mode.*:.*cm" "$1" | sed 's/.*:\s*//' | awk '{print $1}'
}

compare_freq() {
    local label="$1"
    local f_an="$2"
    local f_num="$3"
    local tol="$4"

    if [ -z "$f_an" ] || [ -z "$f_num" ]; then
        echo "  SKIP  $label  (missing frequency)"
        SKIP=$((SKIP+1))
        return
    fi

    local diff=$(echo "$f_an - $f_num" | bc -l 2>/dev/null)
    local absdiff=$(echo "${diff#-}" | bc -l 2>/dev/null)

    if [ -z "$absdiff" ]; then
        echo "  SKIP  $label  (bc error)"
        SKIP=$((SKIP+1))
        return
    fi

    local ok=$(echo "$absdiff < $tol" | bc -l 2>/dev/null)
    if [ "$ok" = "1" ]; then
        printf "  PASS  %-40s  an=%10s  num=%10s  diff=%8s\n" "$label" "$f_an" "$f_num" "$diff"
        PASS=$((PASS+1))
    else
        printf "  FAIL  %-40s  an=%10s  num=%10s  diff=%8s  (tol=%s)\n" "$label" "$f_an" "$f_num" "$diff" "$tol"
        FAIL=$((FAIL+1))
    fi
}

run_test() {
    local inp="$1"
    local out="${inp%.inp}.out"
    echo "  Running $inp ..."
    $EXE "$inp" > "$out" 2>&1
}

echo "============================================================="
echo "  StudDFT v0.50.0 ECP Hessian Validation"
echo "  Executable: $EXE"
echo "  Threads:    $NTHREADS"
echo "============================================================="
echo ""

# --- Test pair 1: HCl HF/LANL2DZ ---
echo "--- Test 1-2: HCl HF/LANL2DZ (ECP on Cl) ---"
run_test tests/test01_hcl_hf_an.inp
run_test tests/test02_hcl_hf_num.inp
F1=$(extract_freq tests/test01_hcl_hf_an.out)
F2=$(extract_freq tests/test02_hcl_hf_num.out)
compare_freq "HCl HF/LANL2DZ" "$F1" "$F2" "2.0"
echo ""

# --- Test pair 2: HCl B3LYP/LANL2DZ ---
echo "--- Test 3-4: HCl B3LYP/LANL2DZ (ECP + DFT hybrid) ---"
run_test tests/test03_hcl_b3lyp_an.inp
run_test tests/test04_hcl_b3lyp_num.inp
F3=$(extract_freq tests/test03_hcl_b3lyp_an.out)
F4=$(extract_freq tests/test04_hcl_b3lyp_num.out)
compare_freq "HCl B3LYP/LANL2DZ" "$F3" "$F4" "2.0"
echo ""

# --- Test pair 3: NaCl HF/LANL2DZ ---
echo "--- Test 5-6: NaCl HF/LANL2DZ (ECP on both atoms) ---"
run_test tests/test05_nacl_hf_an.inp
run_test tests/test06_nacl_hf_num.inp
F5=$(extract_freq tests/test05_nacl_hf_an.out)
F6=$(extract_freq tests/test06_nacl_hf_num.out)
compare_freq "NaCl HF/LANL2DZ" "$F5" "$F6" "2.0"
echo ""

# --- Test 7: HCl OPT+FREQ ---
echo "--- Test 7: HCl HF/LANL2DZ OPT+FREQ ---"
run_test tests/test07_hcl_optfreq.inp
F7=$(extract_freq tests/test07_hcl_optfreq.out)
if [ -n "$F7" ]; then
    echo "  INFO  HCl OPT+FREQ frequency = $F7 cm-1  (check: positive, ~2900 cm-1)"
    PASS=$((PASS+1))
else
    echo "  FAIL  HCl OPT+FREQ: no frequency found"
    FAIL=$((FAIL+1))
fi
echo ""

# --- Test pair 4: HCl SVWN/LANL2DZ ---
echo "--- Test 8-9: HCl SVWN/LANL2DZ (pure DFT + ECP) ---"
run_test tests/test08_hcl_svwn_an.inp
run_test tests/test09_hcl_svwn_num.inp
F8=$(extract_freq tests/test08_hcl_svwn_an.out)
F9=$(extract_freq tests/test09_hcl_svwn_num.out)
compare_freq "HCl SVWN/LANL2DZ" "$F8" "$F9" "2.0"
echo ""

# --- Test 10: H2O regression (no ECP) ---
echo "--- Test 10: H2O HF/STO-3G regression (no ECP) ---"
run_test tests/test10_h2o_regression.inp
F10=$(extract_all_freq tests/test10_h2o_regression.out)
echo "  INFO  H2O frequencies: $F10"
echo "  INFO  Expected: ~1858, ~4391, ~4609 cm-1"
PASS=$((PASS+1))
echo ""

# --- Test 11: NaCl B3LYP OPT+FREQ ---
echo "--- Test 11: NaCl B3LYP/LANL2DZ OPT+FREQ ---"
run_test tests/test11_nacl_b3lyp_optfreq.inp
F11=$(extract_freq tests/test11_nacl_b3lyp_optfreq.out)
if [ -n "$F11" ]; then
    echo "  INFO  NaCl B3LYP OPT+FREQ frequency = $F11 cm-1  (check: positive)"
    PASS=$((PASS+1))
else
    echo "  FAIL  NaCl B3LYP OPT+FREQ: no frequency found"
    FAIL=$((FAIL+1))
fi
echo ""

# --- Test pair 5: OH UHF/LANL2DZ ---
echo "--- Test 12-13: OH radical UHF/LANL2DZ (UHF + ECP) ---"
run_test tests/test12_oh_uhf_an.inp
run_test tests/test13_oh_uhf_num.inp
F12=$(extract_freq tests/test12_oh_uhf_an.out)
F13=$(extract_freq tests/test13_oh_uhf_num.out)
compare_freq "OH UHF/LANL2DZ" "$F12" "$F13" "5.0"
echo ""

# --- Test pair 6: OH UKS B3LYP/LANL2DZ ---
echo "--- Test 14-15: OH radical B3LYP/LANL2DZ (UKS + ECP) ---"
run_test tests/test14_oh_uks_an.inp
run_test tests/test15_oh_uks_num.inp
F14=$(extract_freq tests/test14_oh_uks_an.out)
F15=$(extract_freq tests/test15_oh_uks_num.out)
compare_freq "OH B3LYP/LANL2DZ" "$F14" "$F15" "5.0"
echo ""

# --- Test 16: Boys-function table accuracy (regression for v0.52.15 fix) ---
echo "--- Test 16: Boys-function table regression ---"
if [ -x ./test_boys ]; then
    ./test_boys > tests/test_boys.out 2>&1
    BOYS_RC=$?
    if [ $BOYS_RC -eq 0 ]; then
        echo "  Boys table accuracy ............... PASS"
        PASS=$((PASS+1))
    else
        echo "  Boys table accuracy ............... FAIL  (exit=$BOYS_RC)"
        echo "  See tests/test_boys.out for details."
        FAIL=$((FAIL+1))
    fi
else
    echo "  test_boys binary not found .......... SKIP"
    echo "  Build with:  make -f src/Makefile test_boys"
    SKIP=$((SKIP+1))
fi
echo ""

# --- Summary ---
echo "============================================================="
echo "  SUMMARY: PASS=$PASS  FAIL=$FAIL  SKIP=$SKIP"
echo "============================================================="
if [ $FAIL -eq 0 ] && [ $SKIP -eq 0 ]; then
    echo "  All tests passed!"
elif [ $FAIL -eq 0 ]; then
    echo "  All run tests passed ($SKIP skipped)."
else
    echo "  *** $FAIL test(s) FAILED ***"
fi
