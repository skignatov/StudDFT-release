#!/bin/bash
# =============================================================
# StudDFT v0.65.1 -- MP2 / UMP2 Hessian / frequency regression suite
# =============================================================
#
# Verifies the analytical RMP2 and UMP2 Hessians (FD of analytical
# gradient) against reference implementation values at 1.5 cm^-1 absolute
# tolerance.
#
# Reference values produced by Reference using the IDENTICAL algorithm:
# central FD of reference.grad.{mp2,ump2} with h = 5e-3 bohr,
# conv_tol = 1e-12.  See the reference frequency-generation scripts scripts (or regenerate
# via reference 2.x).
#
# Usage: ./run_mp2hess_tests.sh [path_to_studdft] [nthreads]
# =============================================================

EXE=${1:-./studdft}
NTHREADS=${2:-2}
export OMP_NUM_THREADS=$NTHREADS

PASS=0
FAIL=0

# Extract one frequency by mode index (1-based)
extract_freq_by_mode() {
    local file="$1"
    local idx="$2"
    awk -v target="$idx" '
        /Vibrational Frequency Analysis/ { in_table=1; next }
        in_table && /^   ----/ { next }
        in_table && / vib / {
            count++
            if (count == target) { print $2; exit }
        }
    ' "$file"
}

compare_freq() {
    local label="$1"
    local got="$2"
    local expected="$3"
    local tol="$4"
    if [ -z "$got" ] || [ -z "$expected" ]; then
        printf "  FAIL  %-44s  (missing value)\n" "$label"
        FAIL=$((FAIL+1))
        return
    fi
    local diff
    diff=$(awk "BEGIN{ d = ($got) - ($expected); if (d<0) d=-d; print d }")
    local ok
    ok=$(awk "BEGIN{ print (($diff) < ($tol)) ? 1 : 0 }")
    if [ "$ok" = "1" ]; then
        printf "  PASS  %-44s  got=%9.2f  ref=%9.2f  diff=%5.2f\n" \
            "$label" "$got" "$expected" "$diff"
        PASS=$((PASS+1))
    else
        printf "  FAIL  %-44s  got=%9.2f  ref=%9.2f  diff=%5.2f  (tol=%.1f)\n" \
            "$label" "$got" "$expected" "$diff" "$tol"
        FAIL=$((FAIL+1))
    fi
}

echo "============================================================="
echo "  StudDFT MP2 Hessian / vibrational frequency regression"
echo "  Executable: $EXE"
echo "  Threads:    $NTHREADS"
echo "============================================================="

# ---------------- Test 1: H2/STO-3G ----------------
echo ""
echo "--- Test 1: H2/STO-3G (smallest possible system) ---"
out=/tmp/mp2hess_h2.out
$EXE tests/test_mp2_h2_freq.inp > $out 2>&1
mode1=$(extract_freq_by_mode $out 1)
compare_freq "H2/STO-3G stretch (cm^-1)" "$mode1" "4988.52" "1.5"

# ---------------- Test 2: H2O/6-31G FREQ at MP2 minimum ----------------
echo ""
echo "--- Test 2: H2O/6-31G FREQ at MP2 minimum ---"
out=/tmp/mp2hess_h2o.out
$EXE tests/test_mp2_h2o_freq.inp > $out 2>&1
mode1=$(extract_freq_by_mode $out 1)
mode2=$(extract_freq_by_mode $out 2)
mode3=$(extract_freq_by_mode $out 3)
compare_freq "H2O/6-31G bend (cm^-1)"        "$mode1" "1662.56" "1.5"
compare_freq "H2O/6-31G sym str (cm^-1)"     "$mode2" "3657.90" "1.5"
compare_freq "H2O/6-31G asym str (cm^-1)"    "$mode3" "3834.22" "1.5"

# ---------------- Test 3: H2O/6-31G OPT+FREQ ----------------
echo ""
echo "--- Test 3: H2O/6-31G OPT+FREQ from distorted start ---"
out=/tmp/mp2hess_h2o_opt.out
$EXE tests/test_mp2_h2o_optfreq.inp > $out 2>&1
mode1=$(extract_freq_by_mode $out 1)
mode2=$(extract_freq_by_mode $out 2)
mode3=$(extract_freq_by_mode $out 3)
# OPT+FREQ tolerance is slightly looser (geometry optimizer
# residual gradient is ~1e-4 vs the freq ref at the true minimum).
compare_freq "H2O OPT+FREQ bend (cm^-1)"     "$mode1" "1662.56" "2.0"
compare_freq "H2O OPT+FREQ sym str (cm^-1)"  "$mode2" "3657.90" "2.0"
compare_freq "H2O OPT+FREQ asym str (cm^-1)" "$mode3" "3834.22" "2.0"

# ---------------- Test 4: NaCl/LANL2DZ ECP ----------------
echo ""
echo "--- Test 4: NaCl/LANL2DZ-ECP (validates ECP path) ---"
out=/tmp/mp2hess_nacl.out
$EXE tests/test_mp2_nacl_ecp_freq.inp > $out 2>&1
mode1=$(extract_freq_by_mode $out 1)
compare_freq "NaCl/LANL2DZ-ECP stretch (cm^-1)" "$mode1" "418.45" "1.5"

# ---------------- Test 5: OH UMP2/cc-pVDZ ----------------
echo ""
echo "--- Test 5: OH radical UMP2 / cc-pVDZ (validates UMP2 path) ---"
out=/tmp/mp2hess_oh_ump2.out
$EXE tests/test_ump2_oh_freq.inp > $out 2>&1
mode1=$(extract_freq_by_mode $out 1)
compare_freq "OH UMP2/cc-pVDZ stretch (cm^-1)" "$mode1" "3846.27" "1.5"

# ---------------- Test 6: CH3 UMP2/6-31G(d) ----------------
# Polyatomic radical with cross-spin t2ab amplitudes; validates the
# Stage 3a/3b/3c contributions of the UMP2 gradient through the FD
# Hessian.  Six vibrational modes; the e' degenerate pairs (mode 2/3
# and 5/6) are checked individually since FD breaks degeneracy by
# ~0.1 cm^-1 at h = 5e-3 bohr.
echo ""
echo "--- Test 6: CH3 radical UMP2 / 6-31G(d) (polyatomic open-shell) ---"
out=/tmp/mp2hess_ch3_ump2.out
$EXE tests/test_ump2_ch3_freq.inp > $out 2>&1
mode1=$(extract_freq_by_mode $out 1)
mode2=$(extract_freq_by_mode $out 2)
mode3=$(extract_freq_by_mode $out 3)
mode4=$(extract_freq_by_mode $out 4)
mode5=$(extract_freq_by_mode $out 5)
mode6=$(extract_freq_by_mode $out 6)
compare_freq "CH3 UMP2 umbrella (cm^-1)"      "$mode1" " 413.83" "1.5"
compare_freq "CH3 UMP2 e' bend 1 (cm^-1)"     "$mode2" "1481.91" "1.5"
compare_freq "CH3 UMP2 e' bend 2 (cm^-1)"     "$mode3" "1481.95" "1.5"
compare_freq "CH3 UMP2 a1' sym str (cm^-1)"   "$mode4" "3214.57" "1.5"
compare_freq "CH3 UMP2 e' asym str 1 (cm^-1)" "$mode5" "3402.61" "1.5"
compare_freq "CH3 UMP2 e' asym str 2 (cm^-1)" "$mode6" "3403.32" "1.5"

# ---------------- Summary ----------------
echo ""
echo "============================================================="
echo "  Summary: $PASS pass, $FAIL fail"
echo "============================================================="
exit $FAIL
