#!/bin/bash
# Numerical MP2 gradient for H2O/cc-pVDZ via central finite differences
# Uses StudDFT energy calculations with displaced geometries.

STUDDFT=./studdft
DELTA=0.001  # displacement in bohr

# Equilibrium geometry in bohr
# O: 0.000000  0.000000  0.221741 
# H: 0.000000  1.430901 -0.887266
# H: 0.000000 -1.430901 -0.887266
# (from angstrom: O 0,0,0.117369; H 0,0.75716,-0.469476; H 0,-0.75716,-0.469476)

OX=0.0000000000; OY=0.0000000000; OZ=0.2217407774
HX1=0.0000000000; HY1=1.4309012698; HZ1=-0.8872659361
HX2=0.0000000000; HY2=-1.4309012698; HZ2=-0.8872659361

coords=("$OX" "$OY" "$OZ" "$HX1" "$HY1" "$HZ1" "$HX2" "$HY2" "$HZ2")
atoms=("O" "O" "O" "H" "H" "H" "H" "H" "H")

echo "Numerical MP2/cc-pVDZ gradient (central FD, delta=$DELTA bohr)"
echo "============================================================="

for idx in 0 1 2 3 4 5 6 7 8; do
    # Plus displacement
    c=("${coords[@]}")
    c[$idx]=$(echo "${c[$idx]} + $DELTA" | bc -l)
    
    cat > /tmp/mp2_fd_plus.inp << EOF
%method MP2
%basis cc-pVDZ
%job energy
%charge 0
%mult 1
*geometry bohr
O  ${c[0]}  ${c[1]}  ${c[2]}
H  ${c[3]}  ${c[4]}  ${c[5]}
H  ${c[6]}  ${c[7]}  ${c[8]}
*end
EOF
    E_plus=$($STUDDFT /tmp/mp2_fd_plus.inp 2>/dev/null | grep "MP2 total energy:" | awk '{print $4}')
    
    # Minus displacement
    c=("${coords[@]}")
    c[$idx]=$(echo "${c[$idx]} - $DELTA" | bc -l)
    
    cat > /tmp/mp2_fd_minus.inp << EOF
%method MP2
%basis cc-pVDZ
%job energy
%charge 0
%mult 1
*geometry bohr
O  ${c[0]}  ${c[1]}  ${c[2]}
H  ${c[3]}  ${c[4]}  ${c[5]}
H  ${c[6]}  ${c[7]}  ${c[8]}
*end
EOF
    E_minus=$($STUDDFT /tmp/mp2_fd_minus.inp 2>/dev/null | grep "MP2 total energy:" | awk '{print $4}')
    
    grad=$(echo "($E_plus - $E_minus) / (2 * $DELTA)" | bc -l)
    
    atom_idx=$((idx / 3 + 1))
    comp_idx=$((idx % 3))
    comp_labels=("x" "y" "z")
    echo "  Atom $atom_idx d${comp_labels[$comp_idx]}: E+ = $E_plus  E- = $E_minus  grad = $grad"
done
