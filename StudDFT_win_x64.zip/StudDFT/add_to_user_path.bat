@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem ============================================================
rem  add_to_user_path.bat
rem
rem  Add the folder that contains this script to the per-user
rem  PATH environment variable (persistent, current user only).
rem
rem  Target OS: Windows 7 / 10 / 11, plain cmd.exe.
rem  Administrator rights are NOT required: the user PATH lives
rem  in HKCU, which the current user may always write.
rem
rem  Design notes
rem  ------------
rem  * Writes to HKCU\Environment, so it affects only the user
rem    who runs it and needs no elevation.
rem  * We use reg.exe, not setx:
rem      - setx silently truncates the value at 1024 characters;
rem      - setx stores PATH as REG_SZ, so entries like
rem        %USERPROFILE% would stop being expanded.
rem    reg.exe lets us read/write the raw value and keep its
rem    original REG_EXPAND_SZ type.
rem  * We read PATH from the registry, not from %PATH%. The
rem    %PATH% of a session is the already-expanded merge of the
rem    system and user PATH and must not be written back.
rem  * If the user has no Path value yet, we create one that
rem    contains just this folder.
rem  * Limitation: a folder name that literally contains '!' is
rem    not supported (delayed expansion consumes it). This never
rem    happens with real installation folders.
rem ============================================================

rem ---- (1) Folder of THIS script, without trailing backslash -
rem %~dp0 is the script's own folder and always ends with '\'.
set "TARGET=%~dp0"
if "%TARGET:~-1%"=="\" set "TARGET=%TARGET:~0,-1%"

rem Want the folder the user was in at launch instead? Use:
rem     set "TARGET=%CD%"

echo Folder to add to your user PATH:
echo     "!TARGET!"
echo.

set "REGKEY=HKCU\Environment"

rem ---- (2a) Read the persistent user PATH from the registry --
rem A fresh profile may not have a Path value at all; in that
rem case reg.exe fails, CURPATH stays empty, and we create the
rem value further down. For HKCU this branch means "no Path yet"
rem (your own user hive does not fail to read in practice).
set "CURPATH="
set "PATHTYPE="
for /f "tokens=1,2,*" %%A in ('reg query "%REGKEY%" /v Path 2^>nul ^| find /i "Path"') do (
    set "PATHTYPE=%%B"
    set "CURPATH=%%C"
)

rem Keep the original value type; fall back to REG_EXPAND_SZ
rem (also used when we create a brand-new Path value).
if /i not "!PATHTYPE!"=="REG_SZ" if /i not "!PATHTYPE!"=="REG_EXPAND_SZ" set "PATHTYPE=REG_EXPAND_SZ"

if not defined CURPATH (
    rem ---- No user PATH yet: create it with just this folder --
    set "NEWPATH=!TARGET!"
    goto :WRITE
)

rem ---- (2b) Is TARGET already a complete entry in PATH? ------
rem Pad both sides with ';' so a whole entry is matched
rem ("C:\Foo" must not match inside "C:\FooBar"). The match is
rem case-insensitive. We test with and without a trailing '\'.
set "HAYSTACK=;!CURPATH!;"
set "FOUND="

set "TST=!HAYSTACK:;%TARGET%;=;!"
if not "!TST!"=="!HAYSTACK!" set "FOUND=1"

set "TST=!HAYSTACK:;%TARGET%\;=;!"
if not "!TST!"=="!HAYSTACK!" set "FOUND=1"

if defined FOUND (
    echo This folder is already in your user PATH. Nothing to do.
    echo.
    pause
    exit /b 0
)

rem ---- (3) Append TARGET, avoiding a double ';' --------------
if "!CURPATH:~-1!"==";" (
    set "NEWPATH=!CURPATH!!TARGET!"
) else (
    set "NEWPATH=!CURPATH!;!TARGET!"
)

:WRITE
reg add "%REGKEY%" /v Path /t !PATHTYPE! /d "!NEWPATH!" /f >nul
if errorlevel 1 (
    echo ERROR: failed to write PATH to the registry.
    echo.
    pause
    exit /b 1
)

echo SUCCESS: the folder was added to your user PATH.
echo Open a NEW command prompt (or sign out and back in) so that
echo other programs pick up the change.
echo.
pause
exit /b 0
