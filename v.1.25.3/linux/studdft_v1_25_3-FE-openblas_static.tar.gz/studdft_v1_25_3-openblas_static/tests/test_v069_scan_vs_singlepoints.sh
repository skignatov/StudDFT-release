#!/bin/bash
# Cross-check: each rigid-scan grid point must reproduce a stand-alone
# single-point at the same R bit-for-bit.  This validates that
# build_scan_input does not perturb anything that affects the energy
# (basis, integrals, SCF inputs, atomic numbers, masses).
set -e
cd "$(dirname "$0")/.."
export STUDDFT="$PWD"

# 1) Run the scan and pull out energies (one per grid point).
#    The summary table is the block after "Rigid PES scan -- summary";
#    each row begins with whitespace + index + decimal R + decimal E.
#    We use awk to find the block, then extract column 3 (energy).
./studdft tests/test_v069_h2_scan.inp > /tmp/scan_out.txt 2>&1
SCAN_E=$(awk '
    /Rigid PES scan -- summary/ { in_block = 1; next }
    in_block && /^   ----/        { ndash++; if (ndash >= 1) inrows = 1; next }
    in_block && inrows && NF >= 3 && $1 ~ /^[0-9]+$/ { print $3 }
    in_block && /^$/ && inrows    { exit }
' /tmp/scan_out.txt)

# 2) For each R in {0.5, 0.6, ..., 1.3}, run a single-point and pull
#    the energy.  Compare to the corresponding scan energy.
i=0
mismatch=0
for R in 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3; do
    i=$((i+1))
    cat > /tmp/h2_ref_$i.inp <<EOF
%method  HF
%basis   sto-3g
%job     energy
%gz
H1
H2 H1 $R

EOF
    REF_E=$(./studdft /tmp/h2_ref_$i.inp 2>&1 | grep "Total energy" | head -1 | awk '{print $3}')
    SC_E=$(echo "$SCAN_E" | sed -n "${i}p")
    # Compare to 8 decimal places (Hartree).  Bit-for-bit isn't
    # guaranteed because the scan path does coords -> Cartesian via a
    # different code path, but they agree to <=1e-12 in practice.
    DIFF=$(awk -v a="$REF_E" -v b="$SC_E" 'BEGIN{ d=a-b; if(d<0)d=-d; printf "%.2e", d}')
    THR=$(awk 'BEGIN{print 1e-9}')
    OK=$(awk -v d="$DIFF" -v t="$THR" 'BEGIN{print (d<t)?"OK":"FAIL"}')
    printf "  point %d  R=%s  scan=%s  ref=%s  |dE|=%s  %s\n" \
        $i $R "$SC_E" "$REF_E" "$DIFF" "$OK"
    if [ "$OK" = "FAIL" ]; then
        mismatch=1
    fi
done

if [ $mismatch -eq 0 ]; then
    echo
    echo "  All 9 scan points reproduce stand-alone single-points to <1e-9 Ha."
    echo
    exit 0
else
    echo
    echo "  FAILED: at least one mismatch above the 1e-9 Ha threshold."
    echo
    exit 1
fi
