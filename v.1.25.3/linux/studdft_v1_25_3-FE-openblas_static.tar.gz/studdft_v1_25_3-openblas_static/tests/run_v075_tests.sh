#!/bin/bash
# =============================================================
# StudDFT v0.75.0 -- dihedral-enumeration fix + Cartesian-BFGS
#                    keyword test suite
# =============================================================
#
# Runs every test_v075_*.inp under tests/ and verifies:
#
#   * test_v075_c2h5oh_opt
#       Ethanol HF/6-31G(d,p) opt+freq.  Pre-v0.75 the optimizer
#       got stuck at max|g| = 1.51e-03 for 41 iterations because
#       the dihedral enumeration dropped the nine methyl-rotation
#       torsions around C1-C2.  Asserts:
#         - Internal-coord summary shows 12 dihedrals (was 3)
#         - Optimization converged (NOT the "NOT converged" line)
#         - No imaginary frequencies
#
#   * test_v075_ch3cho_opt
#       Acetaldehyde HF/6-31G(d,p) opt+freq.  Pre-v0.75 this was
#       the *worst* case: zero dihedrals (all dropped by the bug
#       AND nint==3*natom-6 prevented the Cartesian-BFGS fallback
#       from kicking in).  Asserts:
#         - Internal-coord summary shows 6 dihedrals (was 0)
#         - Optimization converged
#         - No imaginary frequencies
#
#   * test_v075_ch3cooh_opt
#       Acetic acid HF/6-31G(d,p) opt+freq.  Same root cause.
#       Asserts:
#         - Internal-coord summary shows 8 dihedrals (was 2)
#         - Optimization converged
#         - No imaginary frequencies
#
#   * test_v075_ethanol_cart_bfgs
#       %opt_coord cart on ethanol HF/STO-3G.  Exercises the new
#       path-selection plumbing.  Asserts:
#         - Output contains "forcing Cartesian-BFGS optimizer"
#         - Optimization converged
#
#   * test_v075_opt_maxiter_alias
#       %opt_maxiter 3 must be honored as an alias of %geom_maxiter.
#       Pre-v0.75 the keyword was silently dropped and the default
#       50-iteration cap was used instead.  Asserts:
#         - "Geom max iter: 3" appears in the Section-1 echo
#         - "NOT converged after 3 steps" appears at the end of opt
#
# Each test runs the binary and inspects its stdout via the same
# awk-based helpers used by run_v074_tests.sh.  The script returns
# 0 only if every test passes.
# =============================================================

set -u
EXE=${1:-./studdft}
cd "$(dirname "$0")/.."
export STUDDFT="$PWD"

PASS=0
FAIL=0
FAIL_NAMES=()

# -----------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------
run_input() {
    local inp="$1"
    OUTBUF=$($EXE "$inp" 2>&1)
    return $?
}

# Count internal coordinate types from the "Internal Coordinates
# Summary" block printed by print_internals.  We look for the
# specific labels and extract the integer.
n_dihedrals() {
    echo "$OUTBUF" | awk '/^   Dihedrals:[[:space:]]+[0-9]+/ {v=$2} END {print v+0}'
}
n_bonds() {
    echo "$OUTBUF" | awk '/^   Bonds:[[:space:]]+[0-9]+/ {v=$2} END {print v+0}'
}
n_angles() {
    echo "$OUTBUF" | awk '/^   Angles:[[:space:]]+[0-9]+/ {v=$2} END {print v+0}'
}

# Convergence detection: positive when optimizer reported success.
opt_converged() {
    echo "$OUTBUF" | grep -q 'Optimization converged in'
}
opt_not_converged() {
    echo "$OUTBUF" | grep -q 'Optimization NOT converged'
}

# Number of imaginary frequencies: any negative value in the
# "Freq (cm^-1)" column of the frequency table, excluding the
# "-0.00" TR markers.  Returns 0 if no Vibrational table is
# printed.
n_imag_freq() {
    echo "$OUTBUF" | awk '
        /Mode +Freq +\(cm\^-1\)/ {in_tbl=1; next}
        in_tbl && /^[[:space:]]*$/ {in_tbl=0}
        in_tbl && NF >= 2 {
            f = $2 + 0
            type_col = $NF
            if (f < -0.5 && type_col != "TR") n++
        }
        END {print n+0}'
}

# Cartesian-BFGS path used?
saw_cart_bfgs() {
    echo "$OUTBUF" | grep -q 'forcing Cartesian-BFGS'
}

# Section-1 echo of the maxiter setting.
echoed_geom_maxiter() {
    echo "$OUTBUF" | awk '/Geom max iter:/ {v=$NF} END {print v+0}'
}

pass() { PASS=$((PASS+1)); printf "  PASS  %s\n" "$1"; }
fail() { FAIL=$((FAIL+1)); FAIL_NAMES+=("$1"); printf "  FAIL  %s  (%s)\n" "$1" "$2"; }

# -----------------------------------------------------------------
# Test 1: ethanol HF/6-31G(d,p) opt+freq.  Headline fix.
# -----------------------------------------------------------------
echo
echo "=== Test 1: ethanol opt+freq (HF/6-31G(d,p), 12 dihedrals expected) ==="
run_input "tests/test_v075_c2h5oh_opt.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "c2h5oh_opt" "rc=$rc"
else
    ND=$(n_dihedrals)
    if [ "$ND" -ne 12 ]; then
        fail "c2h5oh_opt" "dihedrals = $ND, expected 12"
    elif opt_not_converged; then
        fail "c2h5oh_opt" "optimizer did not converge"
    elif ! opt_converged; then
        fail "c2h5oh_opt" "convergence line not found"
    else
        NIMAG=$(n_imag_freq)
        if [ "$NIMAG" -gt 0 ]; then
            fail "c2h5oh_opt" "$NIMAG imaginary frequencies"
        else
            pass "c2h5oh_opt  dihedrals=12, converged, no imag freq"
        fi
    fi
fi

# -----------------------------------------------------------------
# Test 2: acetaldehyde HF/6-31G(d,p) opt+freq.  Worst pre-v0.75 case
# (had zero dihedrals at all).
# -----------------------------------------------------------------
echo
echo "=== Test 2: acetaldehyde opt+freq (HF/6-31G(d,p), 6 dihedrals expected) ==="
run_input "tests/test_v075_ch3cho_opt.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "ch3cho_opt" "rc=$rc"
else
    ND=$(n_dihedrals)
    if [ "$ND" -ne 6 ]; then
        fail "ch3cho_opt" "dihedrals = $ND, expected 6"
    elif opt_not_converged; then
        fail "ch3cho_opt" "optimizer did not converge"
    elif ! opt_converged; then
        fail "ch3cho_opt" "convergence line not found"
    else
        NIMAG=$(n_imag_freq)
        if [ "$NIMAG" -gt 0 ]; then
            fail "ch3cho_opt" "$NIMAG imaginary frequencies"
        else
            pass "ch3cho_opt  dihedrals=6, converged, no imag freq"
        fi
    fi
fi

# -----------------------------------------------------------------
# Test 3: acetic acid HF/6-31G(d,p) opt+freq.
# -----------------------------------------------------------------
echo
echo "=== Test 3: acetic acid opt+freq (HF/6-31G(d,p), 8 dihedrals expected) ==="
run_input "tests/test_v075_ch3cooh_opt.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "ch3cooh_opt" "rc=$rc"
else
    ND=$(n_dihedrals)
    if [ "$ND" -ne 8 ]; then
        fail "ch3cooh_opt" "dihedrals = $ND, expected 8"
    elif opt_not_converged; then
        fail "ch3cooh_opt" "optimizer did not converge"
    elif ! opt_converged; then
        fail "ch3cooh_opt" "convergence line not found"
    else
        NIMAG=$(n_imag_freq)
        if [ "$NIMAG" -gt 0 ]; then
            fail "ch3cooh_opt" "$NIMAG imaginary frequencies"
        else
            pass "ch3cooh_opt  dihedrals=8, converged, no imag freq"
        fi
    fi
fi

# -----------------------------------------------------------------
# Test 4: Cartesian-BFGS via %opt_coord cart.
# -----------------------------------------------------------------
echo
echo "=== Test 4: %opt_coord cart on ethanol (HF/STO-3G) ==="
run_input "tests/test_v075_ethanol_cart_bfgs.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "ethanol_cart_bfgs" "rc=$rc"
elif ! saw_cart_bfgs; then
    fail "ethanol_cart_bfgs" "'forcing Cartesian-BFGS' message missing"
elif ! opt_converged; then
    if opt_not_converged; then
        fail "ethanol_cart_bfgs" "Cartesian-BFGS did not converge (cap too low?)"
    else
        fail "ethanol_cart_bfgs" "optimizer did not complete"
    fi
else
    pass "ethanol_cart_bfgs  Cartesian path selected, converged"
fi

# -----------------------------------------------------------------
# Test 5: %opt_maxiter alias regression.
# -----------------------------------------------------------------
echo
echo "=== Test 5: %opt_maxiter alias (must cap at 3) ==="
run_input "tests/test_v075_opt_maxiter_alias.inp"
rc=$?
# Note: this test deliberately *fails* to converge in 3 steps.  rc
# from the binary may be 0 (graceful unconverged exit) -- we don't
# care, we only check the maxiter echo and the failure mode line.
ECHOED=$(echoed_geom_maxiter)
if [ "$ECHOED" -ne 3 ]; then
    fail "opt_maxiter_alias" "Section-1 echo shows maxiter=$ECHOED, expected 3"
elif ! opt_not_converged; then
    fail "opt_maxiter_alias" "'NOT converged after 3 steps' line missing"
else
    pass "opt_maxiter_alias  maxiter=3 honored as alias"
fi

# -----------------------------------------------------------------
# Summary
# -----------------------------------------------------------------
echo
echo "============================================================="
echo "v0.75.0 test suite:  $PASS pass, $FAIL fail"
if [ $FAIL -gt 0 ]; then
    echo "Failed tests:"
    for n in "${FAIL_NAMES[@]}"; do echo "  - $n"; done
    exit 1
fi
exit 0
