! ============================================================================
! StudDFT v0.72.0-dev -- Standalone test for compute_prfo_step (the
! partitioned-RFO step generator that drives the transition-state
! optimizer).
!
! Five checks:
!
!   (1) TS-mode component is POSITIVE on a quadratic with one negative
!       eigenvalue.
!       Setup: Hq = diag(-2, +1, +5).  At a non-zero gradient g, the
!       step p must have a component along V_t (= e_1, the negative-
!       eigenvalue eigenvector) that goes UPHILL, i.e. its sign is
!       opposite to g_1.  Distinguishes P-RFO from plain RFO (which
!       would always step in the direction that LOWERS the energy along
!       every mode and would therefore NEVER find a TS).
!
!   (2) Non-TS components are minimized (sign opposite to gradient on
!       each non-TS mode).  These behave like plain-RFO descent.
!
!   (3) On a perfect quadratic, with trust radius generous enough not
!       to bind, the predicted Newton step on the non-TS subblock is
!       p_i = -g_i / lambda_i for i != i_ts.  Verify the formula.
!
!   (4) Trust radius is enforced:  pass a tight trust radius, verify
!       |p| <= trust within rounding.
!
!   (5) Mode tracking:  pass V_ts_in pointing along a positive-eigenvalue
!       direction; the picker must NOT default to the lowest eigenvalue
!       but follow the supplied vector even when it is no longer the
!       most-negative mode.
!
! Build:
!   make test_prfo_step
! Run:
!   ./test_prfo_step
! ============================================================================
program test_prfo_step
    use constants, only: dp
    use optimizer_module, only: compute_prfo_step
    implicit none

    integer :: nfail
    nfail = 0

    write(*,'(A)') 'test_prfo_step: P-RFO step generator'
    write(*,'(A)') '----------------------------------------------------------------'

    call check1_uphill_along_ts(nfail)
    call check2_downhill_on_others(nfail)
    call check3_quadratic_step_formula(nfail)
    call check4_trust_radius(nfail)
    call check5_mode_tracking(nfail)

    write(*,'(A)') '----------------------------------------------------------------'
    if (nfail == 0) then
        write(*,'(A)') 'ALL CHECKS PASS.'
    else
        write(*,'(A,I0,A)') 'FAILED: ', nfail, ' check(s).'
        stop 1
    end if

contains

    ! --- Check 1: step ascends along TS mode --------------------------------
    subroutine check1_uphill_along_ts(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 3
        real(dp) :: Hq(n, n), gq(n), p(n), V_in(n), V_out(n)
        integer :: i_ts
        real(dp) :: trust

        ! Hq diagonal with eigenvalues (-2, +1, +5).  After dsyev these
        ! come back in ascending order: (-2, +1, +5).  Mode 1 = TS mode.
        Hq = 0.0_dp
        Hq(1,1) = -2.0_dp
        Hq(2,2) =  1.0_dp
        Hq(3,3) =  5.0_dp

        ! Gradient with components along all 3 directions.
        gq = [ 0.3_dp, -0.4_dp, 0.5_dp ]

        V_in = 0.0_dp     ! first call -> use i_user = 1 (lowest)
        trust = 1.0_dp

        call compute_prfo_step(Hq, gq, n, trust, V_in, 1, p, V_out, i_ts)

        ! On a diagonal Hq the eigenvectors are e_1, e_2, e_3, so
        ! p_1 = step component along the TS mode = the actual p(1).
        !
        ! TS-mode condition:  p_1 must have OPPOSITE sign to g_1.
        ! With g_1 = +0.3 and the TS eigenvalue = -2 (a max along
        ! that direction at an actual TS), we want to step UP, i.e.
        ! p_1 must be NEGATIVE (away from the gradient).
        !
        ! WAIT: the convention is that a transition state is a SADDLE,
        ! and we want to move TOWARD it.  Along the TS coordinate the
        ! curvature is negative (concave); the function maximizes
        ! along that direction.  At a non-TS point with g_1 > 0 (the
        ! function increases along +e_1), we are sitting on the
        ! "downhill" side of the saddle and we must step in the
        ! +g direction (i.e. p_1 > 0) to go uphill toward the saddle.
        !
        ! Mathematically the P-RFO formula is
        !    alpha_t = - g_t / (lambda_t - mu_+)
        ! with mu_+ > 0 > lambda_t, so (lambda_t - mu_+) < 0, hence
        ! alpha_t and g_t have the SAME sign.  Confirm.
        if (i_ts == 1 .and. p(1) * gq(1) > 0.0_dp) then
            write(*,'(A,F10.6)') '  (1) TS-mode step ascends             PASS  p(1)*g(1) = ', &
                p(1) * gq(1)
        else
            write(*,'(A,I0,A,F10.6)') '  (1) TS-mode step ascends             FAIL  i_ts=', &
                i_ts, '  p(1)*g(1) = ', p(1) * gq(1)
            nfail = nfail + 1
        end if
    end subroutine check1_uphill_along_ts

    ! --- Check 2: non-TS modes step opposite to gradient --------------------
    subroutine check2_downhill_on_others(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 3
        real(dp) :: Hq(n, n), gq(n), p(n), V_in(n), V_out(n)
        integer :: i_ts
        real(dp) :: trust

        Hq = 0.0_dp
        Hq(1,1) = -2.0_dp
        Hq(2,2) =  1.0_dp
        Hq(3,3) =  5.0_dp

        gq = [ 0.3_dp, -0.4_dp, 0.5_dp ]
        V_in = 0.0_dp
        trust = 1.0_dp

        call compute_prfo_step(Hq, gq, n, trust, V_in, 1, p, V_out, i_ts)

        ! For the non-TS modes (lambda > 0) the step is
        !    alpha_i = -g_i / (lambda_i - mu_-)
        ! with mu_- < lambda_i (mu_- is the LOWEST eigenvalue of the
        ! augmented matrix), so denominator > 0, hence alpha_i has
        ! OPPOSITE sign to g_i.
        ! We expect: p(2)*g(2) < 0 and p(3)*g(3) < 0.
        if (p(2)*gq(2) < 0.0_dp .and. p(3)*gq(3) < 0.0_dp) then
            write(*,'(A,2F10.6)') '  (2) Non-TS modes descend             PASS  p*g = ', &
                p(2)*gq(2), p(3)*gq(3)
        else
            write(*,'(A,2F10.6)') '  (2) Non-TS modes descend             FAIL  p*g = ', &
                p(2)*gq(2), p(3)*gq(3)
            nfail = nfail + 1
        end if
    end subroutine check2_downhill_on_others

    ! --- Check 3: quadratic step formula on non-TS subblock ----------------
    !
    ! For a tiny gradient (small g_i so that mu_- ~ 0), the non-TS step
    ! reduces to the Newton step alpha_i = -g_i / lambda_i.  Verify
    ! within tolerance.
    subroutine check3_quadratic_step_formula(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 3
        real(dp) :: Hq(n, n), gq(n), p(n), V_in(n), V_out(n)
        real(dp) :: p2_newton, p3_newton, err2, err3
        integer :: i_ts
        real(dp) :: trust

        Hq = 0.0_dp
        Hq(1,1) = -2.0_dp
        Hq(2,2) =  1.0_dp
        Hq(3,3) =  5.0_dp

        gq = [ 1.0e-3_dp, 1.0e-3_dp, 1.0e-3_dp ]   ! very small gradient
        V_in = 0.0_dp
        trust = 10.0_dp                  ! generous, won't bind

        call compute_prfo_step(Hq, gq, n, trust, V_in, 1, p, V_out, i_ts)

        ! Newton-step expectations on non-TS modes:
        p2_newton = -gq(2) / Hq(2,2)     ! = -1e-3 / 1   = -1e-3
        p3_newton = -gq(3) / Hq(3,3)     ! = -1e-3 / 5   = -2e-4

        err2 = abs(p(2) - p2_newton)
        err3 = abs(p(3) - p3_newton)

        ! mu_- in this regime is O(g^2 / lambda) ~ 1e-6, negligible vs
        ! lambda; the Newton formula should hold to ~1e-6 relative.
        if (err2 < 1.0e-6_dp .and. err3 < 1.0e-6_dp) then
            write(*,'(A,ES10.2,1x,ES10.2)') &
                '  (3) Newton step on non-TS subblock   PASS  errs = ', err2, err3
        else
            write(*,'(A,ES10.2,1x,ES10.2)') &
                '  (3) Newton step on non-TS subblock   FAIL  errs = ', err2, err3
            nfail = nfail + 1
        end if
    end subroutine check3_quadratic_step_formula

    ! --- Check 4: trust radius -----------------------------------------------
    subroutine check4_trust_radius(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 3
        real(dp) :: Hq(n, n), gq(n), p(n), V_in(n), V_out(n)
        integer :: i_ts
        real(dp) :: trust, pnorm

        Hq = 0.0_dp
        Hq(1,1) = -2.0_dp
        Hq(2,2) =  0.1_dp     ! soft modes: unscaled step would be huge
        Hq(3,3) =  0.1_dp

        gq = [ 1.0_dp, 1.0_dp, 1.0_dp ]      ! large gradient, soft Hq
        V_in = 0.0_dp
        trust = 0.05_dp

        call compute_prfo_step(Hq, gq, n, trust, V_in, 1, p, V_out, i_ts)

        pnorm = sqrt(sum(p**2))

        if (pnorm <= trust * (1.0_dp + 1.0e-12_dp)) then
            write(*,'(A,F8.5,A,F8.5)') '  (4) Trust radius enforced            PASS  |p|=', &
                pnorm, '  trust=', trust
        else
            write(*,'(A,F8.5,A,F8.5)') '  (4) Trust radius enforced            FAIL  |p|=', &
                pnorm, '  trust=', trust
            nfail = nfail + 1
        end if
    end subroutine check4_trust_radius

    ! --- Check 5: mode tracking ---------------------------------------------
    !
    ! Setup: Hq has eigenvalues (-2, +1, +5) -> dsyev order (-2, +1, +5).
    ! Pass V_ts_in = e_2 (the +1 eigenvector).  The picker must follow
    ! that vector and choose i_ts = 2 (the +1 mode) even though the
    ! lowest eigenvalue is at index 1.
    subroutine check5_mode_tracking(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 3
        real(dp) :: Hq(n, n), gq(n), p(n), V_in(n), V_out(n)
        integer :: i_ts
        real(dp) :: trust

        Hq = 0.0_dp
        Hq(1,1) = -2.0_dp
        Hq(2,2) =  1.0_dp
        Hq(3,3) =  5.0_dp

        gq = [ 0.0_dp, 0.3_dp, 0.0_dp ]   ! gradient only along the +1 mode
        ! Tracking input: previous-step TS eigenvector pointed along e_2
        V_in = [ 0.0_dp, 1.0_dp, 0.0_dp ]
        trust = 1.0_dp

        call compute_prfo_step(Hq, gq, n, trust, V_in, 1, p, V_out, i_ts)

        ! The picker should pick i_ts = 2 (max overlap with V_in).
        ! Step direction: p along the +1 mode must have SAME sign as g
        ! (the alpha_t = -g_t / (lambda_t - mu_+) formula with
        !  lambda_t = +1, g_t = +0.3, gives a positive alpha for the
        !  HIGHER root mu_+ -- but here lambda_t > 0 so mu_+ > lambda_t
        !  and (lambda_t - mu_+) < 0, so alpha and g have the SAME sign).
        if (i_ts == 2 .and. abs(V_out(2)) > 0.99_dp .and. p(2)*gq(2) > 0.0_dp) then
            write(*,'(A,I0,A,F8.5)') &
                '  (5) Mode-tracking max overlap        PASS  i_ts=', &
                i_ts, '  V_out(2)=', V_out(2)
        else
            write(*,'(A,I0,A,F8.5,A,F10.6)') &
                '  (5) Mode-tracking max overlap        FAIL  i_ts=', &
                i_ts, '  V_out(2)=', V_out(2), '  p(2)*g(2)=', p(2)*gq(2)
            nfail = nfail + 1
        end if
    end subroutine check5_mode_tracking

end program test_prfo_step
