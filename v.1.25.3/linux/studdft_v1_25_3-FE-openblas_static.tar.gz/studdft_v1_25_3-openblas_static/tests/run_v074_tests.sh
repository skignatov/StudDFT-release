#!/bin/bash
# =============================================================
# StudDFT v0.74.0 -- IEFPCM + COSMO Stage 2.1 test suite
# =============================================================
#
# Runs every test_v074_*.inp under tests/ and verifies:
#
#   * test_v074_h2o_iefpcm_water
#       HF/STO-3G water in IEFPCM water (eps = 78.36).  Asserts:
#         - SCF converged
#         - G_pol < 0
#         - |sum(q)| < 0.05  (Gauss-law: ~ 0 for a neutral solute)
#         - G_pol close to v0.73.0 C-PCM water reference (rel. diff
#           < 2 %, since both models reduce to the same conductor
#           limit as eps -> infty and water has eps = 78).
#       Reference value (this commit): G_pol = -0.005694270310 Ha.
#
#   * test_v074_anion_iefpcm
#       F- in IEFPCM water -- Gauss-law check for IEFPCM.  For an
#       anion in a high-eps solvent we expect
#           sum(q) = -Q_solute * (eps-1)/eps = +0.987
#       to within the discretization error.  Asserts |sum(q) - 0.987|
#       < 0.05 and G_pol < 0.
#
#   * test_v074_h2o_iefpcm_benzene
#       HF/STO-3G water in IEFPCM benzene (eps = 2.27).  This is the
#       low-eps regime where IEFPCM and C-PCM diverge most.  Asserts:
#         - SCF converged
#         - G_pol < 0  (still stabilizing, just less than in water)
#         - |G_pol(benzene)| < |G_pol(water)|  (less polar, less stab.)
#       Reference: G_pol = -0.002629800277 Ha (paired with C-PCM
#       benzene below for the divergence assertion).
#
#   * test_v074_h2o_cpcm_benzene + (the iefpcm_benzene above)
#       Pair-test: same molecule, same geometry, two PCM models in
#       benzene.  Asserts |G_pol_CPCM - G_pol_IEFPCM| / |G_pol_CPCM|
#       > 0.05 (5 %).  This is the headline physics result of v0.74.0:
#       the conductor approximation behind C-PCM is wrong by ~16 %
#       for benzene-class solvents, and IEFPCM does the right thing.
#
#   * test_v074_h2o_cosmo_water
#       Same H2O geometry, COSMO with the proper Klamt factor
#       f = (eps-1)/(eps+0.5).  Asserts:
#         - SCF converged
#         - G_pol < 0
#         - G_pol differs from C-PCM water (v0.73.0) by ~ 0.6 %
#           (the ratio f_COSMO/f_CPCM = 0.98098/0.98724 = 0.99366).
#       This catches regressions in the f_eps selection per model.
#
#   * test_v074_oh_uhf_iefpcm
#       OH radical in IEFPCM water (UHF).  Verifies the UHF code
#       path also runs through the IEFPCM solver cleanly:
#         - SCF converged
#         - G_pol < 0
#         - <S^2> close to 0.75 (UHF spin contamination check)
#
#   * test_v074_parser_sanitize
#       Torture test for the input-line sanitizer added in v0.74.0:
#       inputs containing TAB between keyword and value, ASCII 255
#       bytes inside whitespace, in-line "! comment" tails, and
#       trailing blanks on multiple lines.  Must produce the same
#       answer as the clean canonical input.
#
#   * test_v074_default_is_iefpcm
#       NO %pcm line.  Verifies that the default model in v0.74.0
#       is IEFPCM (not C-PCM as in v0.73.0).
#
#   --- Stage 2.2a numerical PCM gradient tests (v0.74.x) ---
#
#   * test_v074_h2o_pcm_gradient
#       %job gradient with IEFPCM water.  Asserts the central-FD
#       routine completes, sum-of-forces vanishes (translational
#       invariance), and the O Z component is in the expected range.
#
#   * test_v074_h2o_pcm_opt
#       %job opt with IEFPCM water.  Asserts the optimizer converges,
#       the final O-H bond is ~ 0.987 Angstrom, and the energy
#       improves from the starting geometry.
#
#   * test_v074_pcm_gradient_vacuum_limit
#       %job gradient with %pcm cpcm + %eps 1.0001.  Asserts that
#       the FD-PCM gradient agrees with the gas-phase analytical
#       HF gradient to within the FD truncation/round-off floor
#       (~ 1e-5 a.u./bohr).  This is a strong cross-check of the
#       cavity-rebuild + tess_ao + M_charge + SCF coupling chain.
#
# Usage: ./run_v074_tests.sh [path_to_studdft]
# =============================================================

set -u
EXE=${1:-./studdft}
cd "$(dirname "$0")/.."
export STUDDFT="$PWD"

PASS=0
FAIL=0
FAIL_NAMES=()

# -----------------------------------------------------------------
# Helpers (same as run_v073_tests.sh)
# -----------------------------------------------------------------
run_input() {
    local inp="$1"
    OUTBUF=$($EXE "$inp" 2>&1)
    return $?
}

last_total_energy() {
    echo "$OUTBUF" | awk '/Total energy:/ {v=$NF} END {print v}'
}

last_g_pol() {
    echo "$OUTBUF" | awk '/PCM G_pol:/ {v=$NF} END {print v}'
}

last_sum_q() {
    echo "$OUTBUF" | awk '/sum\(q\):/ {v=$2} END {print v}'
}

last_s2() {
    echo "$OUTBUF" | awk '/<S\*\*2> =/ {v=$3} END {print v}'
}

abs_lt() {
    local a="$1" b="$2" tol="$3"
    awk -v a="$a" -v b="$b" -v t="$tol" \
        'BEGIN {d = a - b; if (d < 0) d = -d; exit !(d < t)}'
}

# Strict less-than comparison for floats: "is a < b?"
lt() {
    local a="$1" b="$2"
    awk -v a="$a" -v b="$b" 'BEGIN {exit !(a < b)}'
}

# Relative-difference test: "is |a-b|/|b| > frac?"
rel_diff_gt() {
    local a="$1" b="$2" frac="$3"
    awk -v a="$a" -v b="$b" -v f="$frac" \
        'BEGIN {if (b == 0) exit 1; d = (a-b)/b; if (d < 0) d = -d; exit !(d > f)}'
}

pass() { PASS=$((PASS+1)); printf "  PASS  %s\n" "$1"; }
fail() { FAIL=$((FAIL+1)); FAIL_NAMES+=("$1"); printf "  FAIL  %s  (%s)\n" "$1" "$2"; }

# v0.73.0 reference numbers, used here as paired comparisons
REF_GPOL_CPCM_WATER="-0.005726363140"
REF_GPOL_CPCM_BENZENE="-0.003118607116"   # this commit, test 5
REF_SUMQ_GAUSS_HIGHEPS="0.987"            # (eps-1)/eps for water

# -----------------------------------------------------------------
# Test 1: water in water (IEFPCM smoke test)
# -----------------------------------------------------------------
echo
echo "=== Test 1: water in water (HF/STO-3G IEFPCM) ==="
run_input "tests/test_v074_h2o_iefpcm_water.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "h2o_iefpcm_water" "rc=$rc"
else
    G_iefpcm_water=$(last_g_pol)
    SUMQ=$(last_sum_q)
    if ! lt "$G_iefpcm_water" "0.0"; then
        fail "h2o_iefpcm_water" "G_pol = $G_iefpcm_water  (expected < 0)"
    elif ! abs_lt "$SUMQ" "0.0" "0.05"; then
        fail "h2o_iefpcm_water" "|sum(q)| = $SUMQ exceeds 0.05"
    elif ! rel_diff_gt "$G_iefpcm_water" "$REF_GPOL_CPCM_WATER" "0.05" \
           && rel_diff_gt "$G_iefpcm_water" "$REF_GPOL_CPCM_WATER" "0.0"; then
        # Want IEFPCM-vs-CPCM to be CLOSE in water (rel diff < 2 %), so
        # the rel_diff_gt(...,0.02) MUST be FALSE.  We test the negation.
        # The double-test above: confirm there IS a small non-zero diff
        # AND it is below 2 %.
        if rel_diff_gt "$G_iefpcm_water" "$REF_GPOL_CPCM_WATER" "0.02"; then
            fail "h2o_iefpcm_water" "G_pol diff vs C-PCM water > 2 %"
        else
            pass "h2o_iefpcm_water  G_pol = $G_iefpcm_water  sum(q) = $SUMQ"
        fi
    else
        # The simpler path for the typical "close" case
        if rel_diff_gt "$G_iefpcm_water" "$REF_GPOL_CPCM_WATER" "0.02"; then
            fail "h2o_iefpcm_water" "G_pol diff vs C-PCM water > 2 %"
        else
            pass "h2o_iefpcm_water  G_pol = $G_iefpcm_water  sum(q) = $SUMQ"
        fi
    fi
fi

# -----------------------------------------------------------------
# Test 2: F- anion in water (IEFPCM Gauss-law)
# -----------------------------------------------------------------
echo
echo "=== Test 2: F- anion in water (HF/STO-3G IEFPCM, Gauss law) ==="
run_input "tests/test_v074_anion_iefpcm.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "anion_iefpcm" "rc=$rc"
else
    G=$(last_g_pol)
    SUMQ=$(last_sum_q)
    if ! lt "$G" "0.0"; then
        fail "anion_iefpcm" "G_pol = $G  (expected < 0)"
    elif ! abs_lt "$SUMQ" "$REF_SUMQ_GAUSS_HIGHEPS" "0.05"; then
        fail "anion_iefpcm" "sum(q) = $SUMQ  off Gauss prediction $REF_SUMQ_GAUSS_HIGHEPS by > 0.05"
    else
        pass "anion_iefpcm  sum(q) = $SUMQ  (Gauss-law prediction $REF_SUMQ_GAUSS_HIGHEPS)"
    fi
fi

# -----------------------------------------------------------------
# Test 3: water in benzene (IEFPCM low-eps)
# -----------------------------------------------------------------
echo
echo "=== Test 3: water in benzene (HF/STO-3G IEFPCM, low eps) ==="
run_input "tests/test_v074_h2o_iefpcm_benzene.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "h2o_iefpcm_benzene" "rc=$rc"
else
    G_iefpcm_benzene=$(last_g_pol)
    if ! lt "$G_iefpcm_benzene" "0.0"; then
        fail "h2o_iefpcm_benzene" "G_pol = $G_iefpcm_benzene  (expected < 0)"
    else
        # |G_pol(benzene)| < |G_pol(water)|: less polar, less stabilization
        # G_pol values are negative; comparing magnitudes means asking
        # benzene > water in signed value (closer to 0).
        if ! lt "$G_iefpcm_water" "$G_iefpcm_benzene"; then
            fail "h2o_iefpcm_benzene" "|G_pol(benzene)| not < |G_pol(water)|"
        else
            pass "h2o_iefpcm_benzene  G_pol = $G_iefpcm_benzene  <  G_pol(water) = $G_iefpcm_water"
        fi
    fi
fi

# -----------------------------------------------------------------
# Test 4: water in benzene (CPCM, paired with test 3 for divergence)
# -----------------------------------------------------------------
echo
echo "=== Test 4: water in benzene (HF/STO-3G C-PCM) ==="
run_input "tests/test_v074_h2o_cpcm_benzene.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "h2o_cpcm_benzene" "rc=$rc"
else
    G_cpcm_benzene=$(last_g_pol)
    if ! lt "$G_cpcm_benzene" "0.0"; then
        fail "h2o_cpcm_benzene" "G_pol = $G_cpcm_benzene  (expected < 0)"
    else
        pass "h2o_cpcm_benzene  G_pol = $G_cpcm_benzene"
    fi
fi

# -----------------------------------------------------------------
# Test 5: divergence assertion -- IEFPCM vs C-PCM in benzene
#         must differ by > 5 %; this is the *physics* result of
#         Stage 2.1 (the conductor approximation breaks down at
#         low eps, IEFPCM gives the rigorous answer).
# -----------------------------------------------------------------
echo
echo "=== Test 5: IEFPCM vs C-PCM divergence at low eps (benzene) ==="
if [ -z "${G_iefpcm_benzene:-}" ] || [ -z "${G_cpcm_benzene:-}" ]; then
    fail "models_diverge_lowEps" "missing prerequisite test result"
elif ! rel_diff_gt "$G_iefpcm_benzene" "$G_cpcm_benzene" "0.05"; then
    fail "models_diverge_lowEps" \
         "rel diff |IEFPCM-CPCM|/|CPCM| not > 5 %  (CPCM=$G_cpcm_benzene IEFPCM=$G_iefpcm_benzene)"
else
    pass "models_diverge_lowEps  IEFPCM=$G_iefpcm_benzene  CPCM=$G_cpcm_benzene  (rel diff > 5 %)"
fi

# -----------------------------------------------------------------
# Test 6: water in water (COSMO with proper Klamt factor)
# -----------------------------------------------------------------
echo
echo "=== Test 6: water in water (HF/STO-3G COSMO) ==="
run_input "tests/test_v074_h2o_cosmo_water.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "h2o_cosmo_water" "rc=$rc"
else
    G_cosmo=$(last_g_pol)
    if ! lt "$G_cosmo" "0.0"; then
        fail "h2o_cosmo_water" "G_pol = $G_cosmo  (expected < 0)"
    elif rel_diff_gt "$G_cosmo" "$REF_GPOL_CPCM_WATER" "0.02"; then
        fail "h2o_cosmo_water" "G_pol diff vs C-PCM water > 2 % (got $G_cosmo)"
    else
        # COSMO's f = (eps-1)/(eps+0.5) is *slightly* smaller than
        # C-PCM's (eps-1)/eps, so we expect |G_pol(COSMO)| < |G_pol(CPCM)|.
        # G_pol values are negative; "smaller magnitude" means COSMO closer to 0,
        # i.e. G_cosmo > G_cpcm_water in signed comparison.
        if ! lt "$REF_GPOL_CPCM_WATER" "$G_cosmo"; then
            fail "h2o_cosmo_water" "|G_pol(COSMO)| not < |G_pol(CPCM)|  (Klamt factor sign issue?)"
        else
            pass "h2o_cosmo_water  G_pol = $G_cosmo  (CPCM ref = $REF_GPOL_CPCM_WATER)"
        fi
    fi
fi

# -----------------------------------------------------------------
# Test 7: OH radical UHF + IEFPCM
# -----------------------------------------------------------------
echo
echo "=== Test 7: OH radical in water (UHF/STO-3G IEFPCM) ==="
run_input "tests/test_v074_oh_uhf_iefpcm.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "oh_uhf_iefpcm" "rc=$rc"
else
    G=$(last_g_pol)
    S2=$(last_s2)
    if ! lt "$G" "0.0"; then
        fail "oh_uhf_iefpcm" "G_pol = $G  (expected < 0)"
    elif [ -z "$S2" ]; then
        fail "oh_uhf_iefpcm" "<S**2> not found in output"
    elif ! abs_lt "$S2" "0.75" "0.05"; then
        fail "oh_uhf_iefpcm" "<S**2> = $S2  exceeds tolerance vs 0.75"
    else
        pass "oh_uhf_iefpcm  G_pol = $G  <S^2> = $S2"
    fi
fi

# -----------------------------------------------------------------
# Test 8: parser sanitization torture test.  Input file contains
#         a literal TAB between %method and HF, ASCII 255 bytes
#         between %basis and sto-3g, in-line "! comment" tails on
#         several lines, and trailing whitespace.  All of this must
#         be cleaned up by sanitize_line so the parser sees clean
#         keywords -- and the resulting energy must match the
#         C-PCM water reference bit-identically.
# -----------------------------------------------------------------
echo
echo "=== Test 8: parser sanitization (TAB, ASCII 255, in-line comments) ==="
run_input "tests/test_v074_parser_sanitize.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "parser_sanitize" "rc=$rc"
else
    G_san=$(last_g_pol)
    if ! abs_lt "$G_san" "$REF_GPOL_CPCM_WATER" "1.0e-9"; then
        fail "parser_sanitize" "G_pol = $G_san  off C-PCM water ref by > 1e-9"
    else
        pass "parser_sanitize  G_pol = $G_san  (matches C-PCM water bit-for-bit)"
    fi
fi

# -----------------------------------------------------------------
# Test 9: default PCM model is IEFPCM (v0.74.0 behavior change).
#         Input has only "%solvent water" (no %pcm).  In v0.73.0
#         this auto-promoted to C-PCM (-0.005726363140); in v0.74.0
#         it must auto-promote to IEFPCM (-0.005694270310).
# -----------------------------------------------------------------
echo
echo "=== Test 9: default PCM model is now IEFPCM (v0.74 default flip) ==="
run_input "tests/test_v074_default_is_iefpcm.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "default_is_iefpcm" "rc=$rc"
else
    G_def=$(last_g_pol)
    REF_IEFPCM_WATER="-0.005694270310"
    # Must match IEFPCM reference, NOT C-PCM reference.
    if ! abs_lt "$G_def" "$REF_IEFPCM_WATER" "1.0e-9"; then
        fail "default_is_iefpcm" "G_pol = $G_def  not = IEFPCM ref $REF_IEFPCM_WATER"
    elif abs_lt "$G_def" "$REF_GPOL_CPCM_WATER" "1.0e-9"; then
        # If the number happens to match CPCM bit-for-bit, the default
        # didn't actually flip -- catch that explicitly.
        fail "default_is_iefpcm" "G_pol matches C-PCM number; default did not flip"
    else
        pass "default_is_iefpcm  G_pol = $G_def  (IEFPCM, NOT $REF_GPOL_CPCM_WATER)"
    fi
fi

# -----------------------------------------------------------------
# Test 10: PCM gradient (numerical, central FD).  Asserts:
#   - SCF + FD gradient run to completion (rc = 0)
#   - |sum F_x|, |sum F_y|, |sum F_z| < 1e-7   (translational invariance)
#   - The reported O Z component is reasonably close to the cached
#     reference (-0.04888 +/- 1e-5 -- matching is geometry-specific,
#     a 1e-5 tolerance catches gross regressions).
# -----------------------------------------------------------------
echo
echo "=== Test 10: %job gradient with IEFPCM water (analytical, default) ==="
run_input "tests/test_v074_h2o_pcm_gradient.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "h2o_pcm_gradient" "rc=$rc"
else
    # Three lines of "atom_label gx gy gz" right after the header
    # Sum-of-forces translational invariance check.
    sums=$(echo "$OUTBUF" | awk '
        /Cartesian gradient/ {ingrad=1; next}
        ingrad && /^     [A-Z][1-9]/ {
            sx += $2; sy += $3; sz += $4; n++
            if (n==3) {ingrad=0}
        }
        END { printf "%.3e %.3e %.3e", sx, sy, sz }')
    sx=$(echo "$sums" | awk '{print $1}')
    sy=$(echo "$sums" | awk '{print $2}')
    sz=$(echo "$sums" | awk '{print $3}')
    if ! abs_lt "$sx" "0.0" "1.0e-7"; then
        fail "h2o_pcm_gradient" "|sum Fx| = $sx > 1e-7"
    elif ! abs_lt "$sy" "0.0" "1.0e-7"; then
        fail "h2o_pcm_gradient" "|sum Fy| = $sy > 1e-7"
    elif ! abs_lt "$sz" "0.0" "1.0e-7"; then
        fail "h2o_pcm_gradient" "|sum Fz| = $sz > 1e-7"
    else
        # Also verify the reported O_Z is in the expected ballpark
        gOz=$(echo "$OUTBUF" | awk '
            /Cartesian gradient/ {ingrad=1; next}
            ingrad && /^     O1/ {print $4; exit}')
        if ! abs_lt "$gOz" "-0.04888" "1.0e-4"; then
            fail "h2o_pcm_gradient" \
                "O Z gradient = $gOz, off cached -0.04888 by > 1e-4"
        else
            pass "h2o_pcm_gradient  O_Z = $gOz  sum(F) = ($sx, $sy, $sz)"
        fi
    fi
fi

# -----------------------------------------------------------------
# Test 11: PCM optimization (numerical FD gradient).  Asserts:
#   - Optimization converges within max_geom_iter=30
#   - Final O-H bond ~ 0.987 +/- 0.02 Angstrom
#   - Final energy more negative than the input geometry's E_total
# -----------------------------------------------------------------
echo
echo "=== Test 11: %job opt with IEFPCM water (analytical, default) ==="
run_input "tests/test_v074_h2o_pcm_opt.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "h2o_pcm_opt" "rc=$rc"
else
    if ! echo "$OUTBUF" | grep -q "Optimization converged"; then
        fail "h2o_pcm_opt" "no 'Optimization converged' line in output"
    else
        # Compute final O-H distance from the printed Optimized
        # Geometry (Angstrom) block.  Format is fixed-width:
        # "   O1   x   y   z"  followed by H2 / H3.
        rOH=$(echo "$OUTBUF" | awk '
            /Optimized Geometry .Angstrom/ {found=1; next}
            found && /^   O1/ {ox=$2; oy=$3; oz=$4; next}
            found && /^   H2/ {
                hx=$2; hy=$3; hz=$4
                d = sqrt((hx-ox)^2 + (hy-oy)^2 + (hz-oz)^2)
                printf "%.4f", d
                exit
            }')
        if [ -z "$rOH" ]; then
            fail "h2o_pcm_opt" "could not parse final O-H distance"
        elif ! abs_lt "$rOH" "0.987" "0.02"; then
            fail "h2o_pcm_opt" "r(O-H) = $rOH Angstrom, expected ~ 0.987 +/- 0.02"
        else
            E_final=$(echo "$OUTBUF" | awk '/Final energy:/ {v=$NF} END {print v}')
            pass "h2o_pcm_opt  r(O-H) = $rOH A  E_final = $E_final"
        fi
    fi
fi

# -----------------------------------------------------------------
# Test 12: vacuum-limit consistency.  At eps = 1.0001, all PCM
# contributions vanish (G_pol -> 0).  The FD-PCM gradient must
# match the gas-phase analytical gradient to within the FD
# truncation/round-off floor (~ 1e-5 a.u./bohr for h = 5e-3).
# -----------------------------------------------------------------
echo
echo "=== Test 12: PCM-FD gradient -> analytical gas gradient (eps -> 1) ==="
run_input "tests/test_v074_pcm_gradient_vacuum_limit.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "pcm_grad_vacuum_limit" "rc=$rc"
else
    # Read O_Z, H2_Y, H2_Z from the printed gradient block.
    gOz=$(echo "$OUTBUF" | awk '/Cartesian gradient/{i=1;next} i&&/^     O1/{print $4;exit}')
    gH2y=$(echo "$OUTBUF" | awk '/Cartesian gradient/{i=1;next} i&&/^     H2/{print $3;exit}')
    gH2z=$(echo "$OUTBUF" | awk '/Cartesian gradient/{i=1;next} i&&/^     H2/{print $4;exit}')
    # Gas-phase HF/STO-3G analytical reference at this geometry
    REF_OZ="-0.05092067"
    REF_HY="-0.02045458"
    REF_HZ="0.02546033"
    if ! abs_lt "$gOz" "$REF_OZ" "1.0e-5"; then
        fail "pcm_grad_vacuum_limit" "O_Z = $gOz, off $REF_OZ by > 1e-5"
    elif ! abs_lt "$gH2y" "$REF_HY" "1.0e-5"; then
        fail "pcm_grad_vacuum_limit" "H2_Y = $gH2y, off $REF_HY by > 1e-5"
    elif ! abs_lt "$gH2z" "$REF_HZ" "1.0e-5"; then
        fail "pcm_grad_vacuum_limit" "H2_Z = $gH2z, off $REF_HZ by > 1e-5"
    else
        pass "pcm_grad_vacuum_limit  matches analytical gas to FD floor"
    fi
fi

# =================================================================
# v0.74.x Stage 2.2b -- analytical PCM gradient regression block
# =================================================================
# These tests exercise the new src/pcm_gradient.f90 module:
#   - Test 13: water/water IEFPCM, headline analytical-vs-FD
#              agreement test ("ana - FD < 1e-5 a.u./bohr" -- the
#              FD-noise-floor target for the analytical path).
#   - Test 14: vacuum-limit consistency for the analytical path.
#              Tighter than Test 12 (FD's 1e-5 floor) because the
#              analytical path has no truncation floor.
#   - Test 15: low-eps IEFPCM (benzene, eps = 2.27) where the
#              full T^T mu = V adjoint solve really matters --
#              CPCM-style approximations diverge by 10%-20% here.
#   - Test 16: cross-model agreement (CPCM/COSMO/IEFPCM) at
#              high eps (water solvent).  Conductor limit; all
#              three should agree to ~ 1e-3 a.u./bohr on water.
#   - Test 17: methanol opt with analytical PCM gradient.
#              Convergence within max_geom_iter = 30; final C-O
#              bond length within ~ 0.02 A of HF/STO-3G expected
#              (~ 1.43 A).
# -----------------------------------------------------------------
# -----------------------------------------------------------------
# Test 13: HEADLINE -- analytical vs FD agreement on water/water
# IEFPCM.  Run both inputs, parse gradients, assert max |a - FD| < 1e-5.
# -----------------------------------------------------------------
echo
echo "=== Test 13: PCM analytical vs FD on water/water IEFPCM ==="
run_input "tests/test_v074_h2o_iefpcm_grad_ana.inp"
rc1=$?
ana_out="$OUTBUF"
run_input "tests/test_v074_h2o_pcm_gradient_fd.inp"
rc2=$?
fd_out="$OUTBUF"
if [ $rc1 -ne 0 ] || [ $rc2 -ne 0 ]; then
    fail "h2o_pcm_grad_ana_vs_fd" "rc1=$rc1 rc2=$rc2"
else
    parse_grad () {
        # Extract O1.gZ, H2.gY, H3.gY from the printed gradient block.
        echo "$1" | awk '
            /Cartesian gradient/ {ingrad=1; next}
            ingrad && /^     O1/ {oz=$4}
            ingrad && /^     H2/ {h2y=$3; h2z=$4}
            ingrad && /^     H3/ {h3y=$3; print oz, h2y, h2z, h3y; exit}'
    }
    g_ana=$(parse_grad "$ana_out")
    g_fd=$( parse_grad "$fd_out" )
    a_oz=$(echo "$g_ana" | awk '{print $1}'); fd_oz=$(echo "$g_fd" | awk '{print $1}')
    a_hy=$(echo "$g_ana" | awk '{print $2}'); fd_hy=$(echo "$g_fd" | awk '{print $2}')
    a_hz=$(echo "$g_ana" | awk '{print $3}'); fd_hz=$(echo "$g_fd" | awk '{print $3}')
    if ! abs_lt "$a_oz" "$fd_oz" "1.0e-5"; then
        fail "h2o_pcm_grad_ana_vs_fd" "O_Z: ana=$a_oz fd=$fd_oz diff > 1e-5"
    elif ! abs_lt "$a_hy" "$fd_hy" "1.0e-5"; then
        fail "h2o_pcm_grad_ana_vs_fd" "H2_Y: ana=$a_hy fd=$fd_hy diff > 1e-5"
    elif ! abs_lt "$a_hz" "$fd_hz" "1.0e-5"; then
        fail "h2o_pcm_grad_ana_vs_fd" "H2_Z: ana=$a_hz fd=$fd_hz diff > 1e-5"
    else
        pass "h2o_pcm_grad_ana_vs_fd  max|a-fd| < 1e-5  (ana O_Z=$a_oz, fd O_Z=$fd_oz)"
    fi
fi

# -----------------------------------------------------------------
# Test 14: vacuum-limit consistency for the ANALYTICAL path.
# Tolerance 1e-6 (no FD floor; the analytical path matches gas-phase
# analytical to ~ 1e-7 in practice, so 1e-6 leaves headroom).
# -----------------------------------------------------------------
echo
echo "=== Test 14: PCM analytical gradient -> analytical gas (eps -> 1) ==="
run_input "tests/test_v074_h2o_pcm_gradient_vacuum_limit_ana.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "pcm_grad_vacuum_limit_ana" "rc=$rc"
else
    gOz=$(echo "$OUTBUF" | awk '/Cartesian gradient/{i=1;next} i&&/^     O1/{print $4;exit}')
    gH2y=$(echo "$OUTBUF" | awk '/Cartesian gradient/{i=1;next} i&&/^     H2/{print $3;exit}')
    gH2z=$(echo "$OUTBUF" | awk '/Cartesian gradient/{i=1;next} i&&/^     H2/{print $4;exit}')
    REF_OZ="-0.05092067"
    REF_HY="-0.02045458"
    REF_HZ="0.02546033"
    if ! abs_lt "$gOz" "$REF_OZ" "1.0e-6"; then
        fail "pcm_grad_vacuum_limit_ana" "O_Z = $gOz, off $REF_OZ by > 1e-6"
    elif ! abs_lt "$gH2y" "$REF_HY" "1.0e-6"; then
        fail "pcm_grad_vacuum_limit_ana" "H2_Y = $gH2y, off $REF_HY by > 1e-6"
    elif ! abs_lt "$gH2z" "$REF_HZ" "1.0e-6"; then
        fail "pcm_grad_vacuum_limit_ana" "H2_Z = $gH2z, off $REF_HZ by > 1e-6"
    else
        pass "pcm_grad_vacuum_limit_ana  matches analytical gas to ~ 1e-7"
    fi
fi

# -----------------------------------------------------------------
# Test 15: low-eps IEFPCM (benzene solvent, eps = 2.27).  Exercises
# the full T^T mu = V adjoint solve.  Compares analytical vs FD at
# the same geometry.
# -----------------------------------------------------------------
echo
echo "=== Test 15: IEFPCM low-eps benzene -- analytical vs FD ==="
run_input "tests/test_v074_h2o_iefpcm_lowEps_grad_ana.inp"
rc1=$?
ana_out="$OUTBUF"
run_input "tests/test_v074_h2o_iefpcm_lowEps_grad_fd.inp"
rc2=$?
fd_out="$OUTBUF"
if [ $rc1 -ne 0 ] || [ $rc2 -ne 0 ]; then
    fail "iefpcm_lowEps_grad" "rc1=$rc1 rc2=$rc2"
else
    a_oz=$(echo "$ana_out" | awk '/Cartesian gradient/{i=1;next} i&&/^     O1/{print $4;exit}')
    a_hy=$(echo "$ana_out" | awk '/Cartesian gradient/{i=1;next} i&&/^     H2/{print $3;exit}')
    fd_oz=$(echo "$fd_out" | awk '/Cartesian gradient/{i=1;next} i&&/^     O1/{print $4;exit}')
    fd_hy=$(echo "$fd_out" | awk '/Cartesian gradient/{i=1;next} i&&/^     H2/{print $3;exit}')
    if ! abs_lt "$a_oz" "$fd_oz" "1.0e-5"; then
        fail "iefpcm_lowEps_grad" "O_Z: ana=$a_oz fd=$fd_oz diff > 1e-5"
    elif ! abs_lt "$a_hy" "$fd_hy" "1.0e-5"; then
        fail "iefpcm_lowEps_grad" "H2_Y: ana=$a_hy fd=$fd_hy diff > 1e-5"
    else
        pass "iefpcm_lowEps_grad  benzene eps=2.27, ana matches FD < 1e-5"
    fi
fi

# -----------------------------------------------------------------
# Test 16: cross-model agreement at high eps (water/water).
# CPCM, COSMO, IEFPCM all approach the conductor limit at eps=78.36;
# all three gradients should be within ~ 1e-3 a.u./bohr on water.
# -----------------------------------------------------------------
echo
echo "=== Test 16: CPCM / COSMO / IEFPCM cross-model agreement (water) ==="
get_oz () {
    echo "$1" | awk '/Cartesian gradient/{i=1;next} i&&/^     O1/{print $4;exit}'
}
run_input "tests/test_v074_h2o_iefpcm_grad_ana.inp"
ief_oz=$(get_oz "$OUTBUF"); rc1=$?
run_input "tests/test_v074_h2o_cpcm_grad_ana.inp"
cpc_oz=$(get_oz "$OUTBUF"); rc2=$?
run_input "tests/test_v074_h2o_cosmo_grad_ana.inp"
cos_oz=$(get_oz "$OUTBUF"); rc3=$?
if [ $rc1 -ne 0 ] || [ $rc2 -ne 0 ] || [ $rc3 -ne 0 ]; then
    fail "pcm_models_xcheck" "rc1=$rc1 rc2=$rc2 rc3=$rc3"
else
    if ! abs_lt "$ief_oz" "$cpc_oz" "1.0e-3"; then
        fail "pcm_models_xcheck" "IEFPCM=$ief_oz, CPCM=$cpc_oz diff > 1e-3 (water)"
    elif ! abs_lt "$ief_oz" "$cos_oz" "1.0e-3"; then
        fail "pcm_models_xcheck" "IEFPCM=$ief_oz, COSMO=$cos_oz diff > 1e-3 (water)"
    else
        pass "pcm_models_xcheck  IEFPCM=$ief_oz CPCM=$cpc_oz COSMO=$cos_oz agree (water)"
    fi
fi

# -----------------------------------------------------------------
# Test 17: methanol geometry optimization with the analytical PCM
# gradient.  Convergence within max_geom_iter = 30; final C-O bond
# length within ~ 0.02 A of HF/STO-3G expectation (~ 1.43 A).
# -----------------------------------------------------------------
echo
echo "=== Test 17: methanol opt with analytical PCM gradient ==="
run_input "tests/test_v074_methanol_pcm_opt_ana.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "methanol_pcm_opt_ana" "rc=$rc"
else
    if ! echo "$OUTBUF" | grep -q "Optimization converged"; then
        fail "methanol_pcm_opt_ana" "no 'Optimization converged' line"
    else
        # Compute final C-O distance from the printed Optimized
        # Geometry (Angstrom) block.
        rCO=$(echo "$OUTBUF" | awk '
            /Optimized Geometry .Angstrom/ {found=1; next}
            found && /^   C1/ {cx=$2; cy=$3; cz=$4; next}
            found && /^   O2/ {
                ox=$2; oy=$3; oz=$4
                d = sqrt((ox-cx)^2 + (oy-cy)^2 + (oz-cz)^2)
                printf "%.4f", d
                exit
            }')
        if [ -z "$rCO" ]; then
            fail "methanol_pcm_opt_ana" "could not parse final C-O distance"
        elif ! abs_lt "$rCO" "1.43" "0.04"; then
            fail "methanol_pcm_opt_ana" "r(C-O) = $rCO Angstrom, expected ~ 1.43 +/- 0.04"
        else
            E_final=$(echo "$OUTBUF" | awk '/Final energy:/ {v=$NF} END {print v}')
            pass "methanol_pcm_opt_ana  r(C-O) = $rCO A  E_final = $E_final"
        fi
    fi
fi

# -----------------------------------------------------------------
# Summary
# -----------------------------------------------------------------
echo
echo "============================================================="
printf "  v0.74.x PCM Stage 2.1 / 2.2a / 2.2b tests:  %d PASS,  %d FAIL\n" "$PASS" "$FAIL"
echo "============================================================="
if [ ${#FAIL_NAMES[@]} -gt 0 ]; then
    echo "Failed tests:"
    for name in "${FAIL_NAMES[@]}"; do
        echo "    - $name"
    done
    exit 1
fi
exit 0
