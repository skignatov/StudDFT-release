! ============================================================================
! StudDFT v0.72.0-dev -- Standalone test for the v0.72 additions to
! internal_coords.f90: transform_hess_to_internal and track_ts_mode.
!
! Five checks:
!
!   (1) Hessian transform on a 3-coord, 3-Cartesian "identity" example.
!       With B = I (square, full-rank, identity) and Hx an arbitrary
!       symmetric matrix, the internal-coord Hessian is exactly Hx.
!       Verifies the matrix-product chain G^{-1} B Hx B^T G^{-1}.
!
!   (2) Hessian transform under a coordinate scaling.  With B = diag(1,2,3)
!       (still full-rank, square), G^{-1} B Hx B^T G^{-1} = B^{-1} Hx B^{-T},
!       i.e. each (i,j) entry is scaled by 1/(B_ii B_jj).  Verifies that
!       the pseudoinverse is computed correctly.
!
!   (3) Hessian transform on a redundant coordinate set.  We project a
!       2-Cartesian example into a 3-internal-coordinate redundant space
!       (rows of B span the same 2-D image as cart axes); H_q in that
!       redundant basis is rank-2 and its non-zero eigenvalues must equal
!       the Cartesian eigenvalues (no extra spurious eigenvalues from
!       the redundant null space).
!
!   (4) track_ts_mode first-call path.  V_prev = 0; user-mode-index = 1
!       must select the lowest-eigenvalue mode of a synthetic Hq with
!       eigenvalues (-3, +1, +5).  The selected V_ts must be parallel
!       to that eigenvector.
!
!   (5) track_ts_mode max-overlap path.  Build Hq with eigenvalues
!       (+1, -2, +5) and pass V_prev = the +1-eigenvalue eigenvector.
!       The picker must NOT pick the lowest (which is now -2) but rather
!       the +1 mode it was tracking; dot_max must be very close to 1.0.
!
! Build:
!   make test_internal_hess_tools
! Run:
!   ./test_internal_hess_tools
! ============================================================================
program test_internal_hess_tools
    use constants, only: dp
    use internal_coords, only: transform_hess_to_internal, track_ts_mode
    implicit none

    integer :: nfail
    nfail = 0

    write(*,'(A)') 'test_internal_hess_tools: transform_hess_to_internal + track_ts_mode'
    write(*,'(A)') '----------------------------------------------------------------------'

    call check1_identity_transform(nfail)
    call check2_scaling_transform(nfail)
    call check3_redundant_transform(nfail)
    call check4_track_first_call(nfail)
    call check5_track_max_overlap(nfail)

    write(*,'(A)') '----------------------------------------------------------------------'
    if (nfail == 0) then
        write(*,'(A)') 'ALL CHECKS PASS.'
    else
        write(*,'(A,I0,A)') 'FAILED: ', nfail, ' check(s).'
        stop 1
    end if

contains

    ! --- Check 1: B = I_3 ---------------------------------------------------
    subroutine check1_identity_transform(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 3
        real(dp) :: B(n, n), Hx(n, n), Hq(n, n)
        real(dp) :: max_diff
        integer :: i, j

        B = 0.0_dp
        do i = 1, n
            B(i, i) = 1.0_dp
        end do

        ! Arbitrary symmetric Hessian
        Hx = reshape([ &
              2.0_dp, 0.5_dp, -0.3_dp, &
              0.5_dp, 1.0_dp,  0.7_dp, &
             -0.3_dp, 0.7_dp,  4.0_dp ], shape(Hx))

        call transform_hess_to_internal(B, Hx, n, n, Hq)

        max_diff = 0.0_dp
        do j = 1, n
            do i = 1, n
                max_diff = max(max_diff, abs(Hq(i, j) - Hx(i, j)))
            end do
        end do

        if (max_diff < 1.0e-12_dp) then
            write(*,'(A,ES10.2)') '  (1) B=I identity transform           PASS  max|dH| = ', max_diff
        else
            write(*,'(A,ES10.2)') '  (1) B=I identity transform           FAIL  max|dH| = ', max_diff
            nfail = nfail + 1
        end if
    end subroutine check1_identity_transform

    ! --- Check 2: B = diag(1, 2, 3) ----------------------------------------
    subroutine check2_scaling_transform(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 3
        real(dp) :: B(n, n), Hx(n, n), Hq(n, n), Hexp(n, n)
        real(dp) :: max_diff
        real(dp) :: bdiag(n)
        integer :: i, j

        B = 0.0_dp
        bdiag = [1.0_dp, 2.0_dp, 3.0_dp]
        do i = 1, n
            B(i, i) = bdiag(i)
        end do

        Hx = reshape([ &
              2.0_dp, 0.5_dp, -0.3_dp, &
              0.5_dp, 1.0_dp,  0.7_dp, &
             -0.3_dp, 0.7_dp,  4.0_dp ], shape(Hx))

        call transform_hess_to_internal(B, Hx, n, n, Hq)

        ! Expected:  Hq(i,j) = Hx(i,j) / (B_ii * B_jj)
        do j = 1, n
            do i = 1, n
                Hexp(i, j) = Hx(i, j) / (bdiag(i) * bdiag(j))
            end do
        end do

        max_diff = 0.0_dp
        do j = 1, n
            do i = 1, n
                max_diff = max(max_diff, abs(Hq(i, j) - Hexp(i, j)))
            end do
        end do

        if (max_diff < 1.0e-12_dp) then
            write(*,'(A,ES10.2)') '  (2) Diagonal-scaling transform       PASS  max|dH| = ', max_diff
        else
            write(*,'(A,ES10.2)') '  (2) Diagonal-scaling transform       FAIL  max|dH| = ', max_diff
            nfail = nfail + 1
        end if
    end subroutine check2_scaling_transform

    ! --- Check 3: Redundant 3-internal vs 2-Cartesian -----------------------
    !
    ! For a redundant B (nint > ncart, B has full column rank ncart):
    !   - Hq = G^+ B Hx B^T G^+ has rank exactly ncart (one zero eigenvalue
    !     for the redundant null direction).
    !   - B^T G^+ B = I_{ncart} (left inverse), so B^T Hq B = Hx exactly.
    ! Eigenvalues of Hq are NOT generally equal to eigenvalues of Hx (they
    ! depend on the internal-coord metric G), but the SIGN signature IS
    ! preserved -- crucial for TS search.
    subroutine check3_redundant_transform(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: nint = 3, ncart = 2
        real(dp) :: B(nint, ncart), Hx(ncart, ncart), Hq(nint, nint)
        real(dp) :: A(nint, nint), eA(nint), wkA(4*nint)
        integer :: info, i
        integer :: nzero, npos
        real(dp) :: max_back

        ! Three internal coords, all linear combinations of two Cartesians.
        ! B has rank 2; G = B B^T has one zero singular value.
        B(1, :) = [ 1.0_dp, 0.0_dp ]
        B(2, :) = [ 0.0_dp, 1.0_dp ]
        B(3, :) = [ 1.0_dp, 1.0_dp ]   ! redundant: q3 = q1 + q2

        Hx = reshape([ &
              3.0_dp, 0.4_dp, &
              0.4_dp, 1.0_dp ], shape(Hx))

        call transform_hess_to_internal(B, Hx, nint, ncart, Hq)

        ! (a) Diagonalize Hq, count rank.  Eigenvalues come back ascending.
        A = Hq
        call dsyev('V', 'U', nint, A, nint, eA, wkA, 4*nint, info)
        if (info /= 0) then
            write(*,'(A,I0)') '  (3) Redundant transform              FAIL  dsyev info=', info
            nfail = nfail + 1
            return
        end if
        nzero = 0; npos = 0
        do i = 1, nint
            if (abs(eA(i)) < 1.0e-10_dp) then
                nzero = nzero + 1
            else if (eA(i) > 0.0_dp) then
                npos = npos + 1
            end if
        end do
        if (nzero /= 1 .or. npos /= 2) then
            write(*,'(A,I0,A,I0,A,I0)') '  (3) Redundant transform              FAIL  ', &
                'nzero=', nzero, ', npos=', npos, ', expected 1/2'
            write(*,'(A,3F12.6)') '       eigenvalues: ', eA(1), eA(2), eA(3)
            nfail = nfail + 1
            return
        end if

        ! (b) Back-transform: B^T Hq B must equal Hx (within rounding).
        block
            real(dp) :: HqB(nint, ncart), BtHqB_loc(ncart, ncart)
            integer :: ii, jj
            call dgemm('N', 'N', nint, ncart, nint, 1.0_dp, &
                        Hq, nint, B, nint, 0.0_dp, HqB, nint)
            call dgemm('T', 'N', ncart, ncart, nint, 1.0_dp, &
                        B, nint, HqB, nint, 0.0_dp, BtHqB_loc, ncart)
            max_back = 0.0_dp
            do jj = 1, ncart
                do ii = 1, ncart
                    max_back = max(max_back, abs(BtHqB_loc(ii, jj) - Hx(ii, jj)))
                end do
            end do
        end block

        if (max_back < 1.0e-12_dp) then
            write(*,'(A,ES10.2)') '  (3) Redundant transform back-trip    PASS  max|B^T Hq B - Hx| = ', max_back
        else
            write(*,'(A,ES10.2)') '  (3) Redundant transform back-trip    FAIL  max|B^T Hq B - Hx| = ', max_back
            nfail = nfail + 1
        end if
    end subroutine check3_redundant_transform

    ! --- Check 4: track_ts_mode first call (V_prev = 0) ---------------------
    subroutine check4_track_first_call(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 3
        real(dp) :: Hq(n, n), V_prev(n), evals(n), evecs(n, n), V_ts(n)
        real(dp) :: dot_max
        integer :: i_ts

        ! Diagonal Hq with eigenvalues (-3, +1, +5).  After dsyev they
        ! come back in ascending order; mode index 1 = lowest = -3.
        Hq = 0.0_dp
        Hq(1,1) = -3.0_dp
        Hq(2,2) =  1.0_dp
        Hq(3,3) =  5.0_dp

        V_prev = 0.0_dp

        call track_ts_mode(Hq, V_prev, n, 1, evals, evecs, i_ts, V_ts, dot_max)

        if (i_ts == 1 .and. abs(evals(1) + 3.0_dp) < 1.0e-12_dp) then
            write(*,'(A,F8.4)') '  (4) Track first-call lowest mode     PASS  evals(1) = ', evals(1)
        else
            write(*,'(A,I0,A,F8.4)') '  (4) Track first-call lowest mode     FAIL  i_ts=', i_ts, &
                ' evals(1)=', evals(1)
            nfail = nfail + 1
        end if
    end subroutine check4_track_first_call

    ! --- Check 5: track_ts_mode max-overlap selection -----------------------
    subroutine check5_track_max_overlap(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 3
        real(dp) :: Hq(n, n), V_prev(n), evals(n), evecs(n, n), V_ts(n)
        real(dp) :: dot_max
        integer :: i_ts

        ! Diagonal Hq with eigenvalues (+1, -2, +5).  After dsyev these
        ! come back in ascending order: evals = (-2, +1, +5).  We pass
        ! V_prev = e_1 (the eigenvector for the +1 eigenvalue, which now
        ! sits at index 2 after sorting).  The picker must pick i_ts=2,
        ! NOT i_ts=1 (the lowest).
        Hq = 0.0_dp
        Hq(1,1) =  1.0_dp
        Hq(2,2) = -2.0_dp
        Hq(3,3) =  5.0_dp

        V_prev = 0.0_dp
        V_prev(1) = 1.0_dp     ! the original +1 eigenvector

        call track_ts_mode(Hq, V_prev, n, 1, evals, evecs, i_ts, V_ts, dot_max)

        ! Expect: evals = (-2, +1, +5); i_ts = 2 (the +1 mode); dot_max ~ 1.
        if (i_ts == 2 .and. &
            abs(evals(1) + 2.0_dp) < 1.0e-12_dp .and. &
            abs(evals(2) - 1.0_dp) < 1.0e-12_dp .and. &
            abs(dot_max - 1.0_dp) < 1.0e-10_dp) then
            write(*,'(A,F8.5)') '  (5) Track max-overlap survives swap  PASS  dot_max = ', dot_max
        else
            write(*,'(A,I0,A,F8.5,A,F8.4,1x,F8.4,1x,F8.4)') &
                '  (5) Track max-overlap survives swap  FAIL  i_ts=', i_ts, &
                ' dot_max=', dot_max, ' evals=', evals(1), evals(2), evals(3)
            nfail = nfail + 1
        end if
    end subroutine check5_track_max_overlap

end program test_internal_hess_tools
