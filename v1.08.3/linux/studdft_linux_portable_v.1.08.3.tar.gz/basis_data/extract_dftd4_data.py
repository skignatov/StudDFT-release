#!/usr/bin/env python3
# ============================================================================
# StudDFT -- Extract Grimme D4 reference data from dftd4's reference.inc
#
# Parses the fixed-form Fortran data file that ships with dftd4, applies
# the set_refalpha_eeq post-processing formula internally (ga=3, gc=2
# defaults), runs the 23-point trapezoidal Casimir-Polder integration
# against itself, and emits three data files ready for StudDFT:
#
#     d4_atomic.dat     per-element scalar constants
#     d4_c6ref.dat      pre-integrated C6(iref, jref, Z_A, Z_B)
#     d4_refcnq.dat     per-element (nref, CN, q_ref, ngw) arrays
#
# Additionally extracts EEQ parameters via ctypes calls on the already-
# installed libdftd4.so because the scalar getters DO work via ctypes --
# it is only the assumed-shape array setters that do not.
#
# Usage:
#     python basis_data/extract_dftd4_data.py \
#         /path/to/dftd4-x.y.z/subprojects/dftd4/src/dftd4 \
#         basis_data/
# ============================================================================
import ctypes
import os
import re
import sys
from pathlib import Path

import numpy as np

# ----------------------------------------------------------------------------
# 1. Load libdftd4 for scalar getters
# ----------------------------------------------------------------------------
_libdir = "/usr/local/lib/python3.12/dist-packages/dftd4.libs"
if os.path.isdir(_libdir):
    for fn in sorted(os.listdir(_libdir)):
        if fn.endswith(".so") or ".so." in fn:
            try:
                ctypes.CDLL(os.path.join(_libdir, fn), mode=ctypes.RTLD_GLOBAL)
            except OSError:
                pass
SO = ctypes.CDLL(
    "/usr/local/lib/python3.12/dist-packages/dftd4/"
    "_libdftd4.cpython-312-x86_64-linux-gnu.so",
    mode=ctypes.RTLD_GLOBAL,
)

def _scal(sym):
    f = getattr(SO, sym)
    f.restype = ctypes.c_double
    f.argtypes = [ctypes.POINTER(ctypes.c_int)]
    def call(z):
        zc = ctypes.c_int(z)
        return f(ctypes.byref(zc))
    return call

rcov_fn    = _scal("__dftd4_data_covrad_MOD_get_covalent_rad_num")
r4r2_fn    = _scal("__dftd4_data_r4r2_MOD_get_r4r2_val_num")
zeff_fn    = _scal("__dftd4_data_zeff_MOD_get_effective_charge_num")
hardness_fn= _scal("__dftd4_data_hardness_MOD_get_hardness_num")
eeq_chi_fn = _scal("__multicharge_param_eeq2019_MOD_get_eeq_chi_num")
eeq_eta_fn = _scal("__multicharge_param_eeq2019_MOD_get_eeq_eta_num")
eeq_rad_fn = _scal("__multicharge_param_eeq2019_MOD_get_eeq_rad_num")
eeq_kcn_fn = _scal("__multicharge_param_eeq2019_MOD_get_eeq_kcnchi_num")

# ----------------------------------------------------------------------------
# 2. Parse reference.inc
# ----------------------------------------------------------------------------
SCALAR_NAMES = ("dftq", "hcount", "ascale", "refcovcn", "refcn",
                "clsh", "clsq", "secq", "sscale", "seccnD3", "seccn")
MAX_ELEM = 118
MAX_REF  = 7
NOMEGA   = 23
NSEC     = 18   # sectors indexed 1..17, we allocate [0..17]

def parse_reference_inc(path):
    """Return a dict of all arrays, shape-matched to the Fortran declarations."""
    text = Path(path).read_text()

    # normalize: strip & line-continuations, keep newlines
    # Fortran-fixed-form: col 6 '&' for continuation; but this file uses
    # trailing '&' + newline for continuation lines instead.
    text = re.sub(r"&\s*\n\s*&?", " ", text)

    out = {
        "refn":     np.zeros(MAX_ELEM + 1, dtype=int),
        "refsys":   np.zeros((MAX_REF + 1, MAX_ELEM + 1), dtype=int),
        "alphaiw":  np.zeros((NOMEGA, MAX_REF + 1, MAX_ELEM + 1), dtype=float),
        "secaiw":   np.zeros((NOMEGA, NSEC), dtype=float),
    }
    for name in SCALAR_NAMES:
        if name in ("secq", "sscale", "seccnD3", "seccn"):
            out[name] = np.zeros(NSEC, dtype=float)
        else:
            out[name] = np.zeros((MAX_REF + 1, MAX_ELEM + 1), dtype=float)

    # ---- (A) refn(iat) / N / ------------------------------------------------
    for m in re.finditer(r"data\s+refn\s*\(\s*(\d+)\s*\)\s*/\s*(\d+)\s*/", text):
        out["refn"][int(m.group(1))] = int(m.group(2))

    # ---- (B) 2D real tables: dftq, hcount, ascale, refcovcn, refcn, clsh ----
    real_pat = re.compile(
        r"data\s+(dftq|hcount|ascale|refcovcn|refcn|clsh|clsq)"
        r"\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*/\s*"
        r"([\-0-9.eEdDwp_+]+)\s*/"
    )
    for m in real_pat.finditer(text):
        name, ir, iat, val = m.groups()
        v = float(val.replace("_wp", "").replace("D", "e").replace("d", "e"))
        out[name][int(ir), int(iat)] = v

    # ---- (C) refsys(ir, iat) / int / ----------------------------------------
    for m in re.finditer(
        r"data\s+refsys\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*/\s*(-?\d+)\s*/",
        text,
    ):
        ir, iat, val = int(m.group(1)), int(m.group(2)), int(m.group(3))
        out["refsys"][ir, iat] = val

    # ---- (D) sector 1D scalars (secq, sscale, seccnD3, seccn) ---------------
    # Format:  data secq(I)/V/;data sscale(I)/V/   etc. -- two per line
    for m in re.finditer(
        r"data\s+(secq|sscale|seccnD3|seccn)\s*\(\s*(\d+)\s*\)\s*/\s*"
        r"([\-0-9.eEdDwp_+]+)\s*/",
        text,
    ):
        name, idx, val = m.groups()
        v = float(val.replace("_wp", "").replace("D", "e").replace("d", "e"))
        out[name][int(idx)] = v

    # ---- (E) alphaiw(:, ir, iat) /23 floats/ --------------------------------
    for m in re.finditer(
        r"data\s+alphaiw\s*\(\s*:\s*,\s*(\d+)\s*,\s*(\d+)\s*\)\s*/([^/]+)/",
        text,
    ):
        ir, iat, payload = int(m.group(1)), int(m.group(2)), m.group(3)
        nums = re.findall(r"[\-0-9.eEdDwp_+]+", payload)
        vals = [
            float(x.replace("_wp", "").replace("D", "e").replace("d", "e"))
            for x in nums if "_wp" in x or any(c.isdigit() for c in x)
        ]
        if len(vals) == NOMEGA:
            out["alphaiw"][:, ir, iat] = vals

    # ---- (F) secaiw(:, i) /23 floats/ ---------------------------------------
    for m in re.finditer(
        r"data\s+secaiw\s*\(\s*:\s*,\s*(\d+)\s*\)\s*/([^/]+)/", text,
    ):
        idx, payload = int(m.group(1)), m.group(2)
        nums = re.findall(r"[\-0-9.eEdDwp_+]+", payload)
        vals = [
            float(x.replace("_wp", "").replace("D", "e").replace("d", "e"))
            for x in nums if "_wp" in x or any(c.isdigit() for c in x)
        ]
        if len(vals) == NOMEGA:
            out["secaiw"][:, idx] = vals

    return out


# ----------------------------------------------------------------------------
# 3. D4 charge-scaling function zeta (dftd4/src/dftd4/model/utils.f90)
# ----------------------------------------------------------------------------
def zeta(a, c, qref, qmod):
    if qmod < 0.0:
        return np.exp(a)
    return np.exp(a * (1.0 - np.exp(c * (1.0 - qref / qmod))))


# ----------------------------------------------------------------------------
# 4. Trapezoidal rule for Casimir-Polder (exact replica of dftd4 trapzd)
# ----------------------------------------------------------------------------
FREQ = np.array([0.000001, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70,
                 0.80, 0.90, 1.00, 1.20, 1.40, 1.60, 1.80, 2.00, 2.50, 3.00,
                 4.00, 5.00, 7.50, 10.00])
TW_W = 0.5 * np.concatenate([
    [FREQ[1] - FREQ[0]],
    [FREQ[i + 1] - FREQ[i - 1] for i in range(1, NOMEGA - 1)],
    [FREQ[NOMEGA - 1] - FREQ[NOMEGA - 2]],
])
THOPI = 3.0 / np.pi


def build_refalpha_eeq(data, Z, ga=3.0, gc=2.0):
    """Replicate set_refalpha_eeq_num formula from dftd4 reference.f90."""
    nref = data["refn"][Z]
    alpha = np.zeros((NOMEGA, nref))
    for ir in range(1, nref + 1):
        isec = data["refsys"][ir, Z]
        if abs(isec) < 1e-12:
            continue
        iz = zeff_fn(isec)
        eta_is = hardness_fn(isec)
        clsh_ir = data["clsh"][ir, Z]
        zeta_val = zeta(ga, eta_is * gc, iz, clsh_ir + iz)
        aiw = data["sscale"][isec] * data["secaiw"][:, isec] * zeta_val
        scale = data["ascale"][ir, Z]
        hcnt  = data["hcount"][ir, Z]
        a_ref = data["alphaiw"][:, ir, Z]
        alpha[:, ir - 1] = np.maximum(scale * (a_ref - hcnt * aiw), 0.0)
    return alpha


# ----------------------------------------------------------------------------
# 5. Main extraction
# ----------------------------------------------------------------------------
def main(inc_path: Path, out_dir: Path):
    print(f"# Parsing {inc_path} ...", file=sys.stderr)
    data = parse_reference_inc(inc_path)

    # ---- atomic constants ---------------------------------------------------
    with open(out_dir / "d4_atomic.dat", "w") as fh:
        fh.write("# StudDFT -- Grimme D4 per-element atomic constants\n")
        fh.write("# Source: libdftd4 (simple-dftd4 + multicharge / EEQ 2019)\n")
        fh.write("# License: LGPL-3.0-or-later\n")
        fh.write("#\n")
        fh.write("# Format: Z rcov r4r2 zeff eta_chem eeq_chi eeq_eta "
                 "eeq_rad eeq_kcnchi\n")
        for z in range(1, 104):
            fh.write(
                f"{z:4d} "
                f"{rcov_fn(z):14.10f} {r4r2_fn(z):14.10f} "
                f"{zeff_fn(z):14.10f} {hardness_fn(z):14.10f} "
                f"{eeq_chi_fn(z):14.10f} {eeq_eta_fn(z):14.10f} "
                f"{eeq_rad_fn(z):14.10f} {eeq_kcn_fn(z):14.10f}\n"
            )

    # ---- per-element reference CN, reference q, ngw, nref -----------------
    # IMPORTANT: reference.inc stores TWO separate per-iref CN columns,
    # used by two different canonical routines:
    #
    #   refcovcn(ir, Z)  -- covalent/D4-flavor reference CN (used by
    #                       set_refcn_num -> d4_model%cn -> weight_references
    #                       where it is the CN target in exp(-wf*(cn-cnref)^2))
    #   refcn   (ir, Z)  -- EEQ-flavor reference CN (used by set_refgw_num
    #                       for triangular-number NGW bin assignment only)
    #
    # These tables differ substantially for multi-reference elements
    # (e.g. O iref=3: refcovcn=1.611, refcn=1.989).  Reading the wrong
    # column caused the ~1-2% residual C6 error on C/N/O that was chased
    # across 14+ sessions before v0.58.0.
    #
    # The two tables do NOT agree under nint() in general (88 mismatches
    # Z<=103), so we compute NGW from refcn here and write it as a
    # pre-computed integer column; StudDFT's loader then does not need
    # to know about the two-CN distinction at all.
    #
    # For charges there is a parallel pitfall flagged in v0.57.0:
    # use clsq, not dftq.  dftq is the "DFT-computed" reference charge
    # stored in reference.inc but NOT what set_refq_eeq_num reads --
    # that routine returns clsq (the EEQ-solved reference charge for
    # each model cluster).
    max_cn_bin = 19
    with open(out_dir / "d4_refcnq.dat", "w") as fh:
        fh.write("# StudDFT -- Grimme D4 per-element reference system data\n")
        fh.write("# Format: Z iref CN_ref Q_ref NGW  (1<=iref<=nref(Z))\n")
        fh.write("# CN_ref column is refcovcn (D4/covalent), NOT refcn.\n")
        fh.write("# Q_ref  column is clsq      (EEQ-solved),  NOT dftq.\n")
        fh.write("# NGW    triangular-number bin count from set_refgw_num\n")
        fh.write("#        (binned on refcn, which is NOT refcovcn -- do\n")
        fh.write("#         not attempt to recompute NGW from CN_ref).\n")
        for z in range(1, 104):
            n = data["refn"][z]
            if n == 0:
                continue
            # Replicate set_refgw_num: bin on refcn, use triangular number.
            cnc = [1] + [0] * max_cn_bin
            for ir in range(1, n + 1):
                icn = min(int(round(data["refcn"][ir, z])), max_cn_bin)
                cnc[icn] += 1
            for ir in range(1, n + 1):
                icn  = cnc[min(int(round(data["refcn"][ir, z])), max_cn_bin)]
                ngw  = icn * (icn + 1) // 2
                cnv  = data["refcovcn"][ir, z]
                q    = data["clsq"][ir, z]
                fh.write(f"{z:4d} {ir:3d} {cnv:14.10f} {q:14.10f} {ngw:4d}\n")

    # ---- pair reference C6 --------------------------------------------------
    # Pre-compute alpha(iw, iref, Z) for every element with EEQ defaults,
    # then trapezoidal Casimir-Polder integration over omega for every pair
    # of reference systems.
    alpha = {}
    for z in range(1, 104):
        alpha[z] = build_refalpha_eeq(data, z)

    total = 0
    with open(out_dir / "d4_c6ref.dat", "w") as fh:
        fh.write("# StudDFT -- Grimme D4 reference C6 database\n")
        fh.write("# Source: libdftd4 reference.inc, pre-integrated via "
                 "23-point Casimir-Polder trapezoidal rule (ga=3, gc=2)\n")
        fh.write("# License: LGPL-3.0-or-later\n")
        fh.write("# Format: Z_A Z_B iref_A iref_B C6_AB\n")
        fh.write("#\n")
        for zA in range(1, 104):
            nA = data["refn"][zA]
            if nA == 0:
                continue
            for zB in range(zA, 104):
                nB = data["refn"][zB]
                if nB == 0:
                    continue
                any_line = False
                for iA in range(nA):
                    for iB in range(nB):
                        aiw = alpha[zA][:, iA] * alpha[zB][:, iB]
                        c6 = THOPI * np.sum(aiw * TW_W)
                        if c6 < 1e-12:
                            continue
                        if not any_line:
                            fh.write(f"# ---- Z={zA} - Z={zB} ----\n")
                            any_line = True
                        fh.write(f"{zA:4d} {zB:4d} {iA+1:3d} {iB+1:3d}"
                                 f" {c6:14.6f}\n")
                        total += 1
        fh.write(f"# total entries: {total}\n")

    print(f"# {total} C6 reference entries written", file=sys.stderr)
    return 0


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(
            "Usage: extract_dftd4_data.py <dftd4 src dir> <output dir>",
            file=sys.stderr,
        )
        sys.exit(2)
    sys.exit(
        main(Path(sys.argv[1]) / "reference.inc", Path(sys.argv[2]))
    )
