#!/usr/bin/env python3
# ============================================================================
# StudDFT -- D4 dispersion Python prototype
#
# Full pure-Python re-implementation of the Grimme D4 dispersion energy,
# built to serve as the reference for the Fortran translation in
# src/dispersion_d4.f90.  The prototype is validated against libdftd4 to
# machine precision before any Fortran line is written.
#
# Algorithmic pipeline (EEQ2019 charge model, D4 dispersion model,
# BJ/rational damping, no ATM three-body for the first pass):
#
#   1. Covalent radii + Pauling EN come from libdftd4 (scalar getters).
#   2. Parse reference.inc to obtain per-element:
#        refn(Z), refcn(iref, Z), refq_eeq(iref, Z),
#        alpha_ref(omega, iref, Z) after set_refalpha_eeq transform
#   3. D4 CN via erf-with-EN counting function (kcn=7.5, k4/k5/k6 from
#      mctc-lib, exact formula from mctc_ncoord_erf_dftd4).
#   4. EEQ solve: augmented (n+1)x(n+1) linear system with charge-
#      conservation constraint, RHS = -chi - kcn_eeq*sqrt(cn).
#   5. weight_references: nested Gaussian sum over ngw(iref, Z) copies
#      (all ngw=1 for D4-2019 which is what simple-dftd4 defaults to)
#      times zeta(ga, eta*gc, q_ref+zeff, q+zeff) charge-scaling factor.
#   6. Atomic C6: double-sum over reference pairs weighted by the gw's,
#      using pre-computed pair C6 from d4_c6ref.dat.
#   7. BJ energy: -sum_{A<B} (s6 C6 / (R^6 + f^6) + s8 C8 / (R^8 + f^8))
#      with f = a1*sqrt(3*r4r2_A*r4r2_B) + a2, exactly as in D3(BJ).
# ============================================================================
import ctypes
import os
import sys
from pathlib import Path

import numpy as np

# ---- 0. Load libdftd4 for scalar getters and reference validation --------
_libdir = "/usr/local/lib/python3.12/dist-packages/dftd4.libs"
for fn in sorted(os.listdir(_libdir)):
    if fn.endswith(".so") or ".so." in fn:
        try:
            ctypes.CDLL(os.path.join(_libdir, fn), mode=ctypes.RTLD_GLOBAL)
        except OSError:
            pass
SO = ctypes.CDLL(
    "/usr/local/lib/python3.12/dist-packages/dftd4/"
    "_libdftd4.cpython-312-x86_64-linux-gnu.so",
    mode=ctypes.RTLD_GLOBAL,
)

def _scal(sym):
    f = getattr(SO, sym)
    f.restype = ctypes.c_double
    f.argtypes = [ctypes.POINTER(ctypes.c_int)]
    def call(z):
        zc = ctypes.c_int(z)
        return f(ctypes.byref(zc))
    return call

rcov_fn     = _scal("__dftd4_data_covrad_MOD_get_covalent_rad_num")
r4r2_fn     = _scal("__dftd4_data_r4r2_MOD_get_r4r2_val_num")
zeff_fn     = _scal("__dftd4_data_zeff_MOD_get_effective_charge_num")
hardness_fn = _scal("__dftd4_data_hardness_MOD_get_hardness_num")
eeq_chi_fn  = _scal("__multicharge_param_eeq2019_MOD_get_eeq_chi_num")
eeq_eta_fn  = _scal("__multicharge_param_eeq2019_MOD_get_eeq_eta_num")
eeq_rad_fn  = _scal("__multicharge_param_eeq2019_MOD_get_eeq_rad_num")
eeq_kcn_fn  = _scal("__multicharge_param_eeq2019_MOD_get_eeq_kcnchi_num")

# Pauling EN (from dftd4 en.f90 — used by D4 CN EN-weighting)
# Hard-coded for Z=1..18 which is all we need for the validation tests.
PAULING_EN = {
    1: 2.20, 2: 3.00,
    3: 0.98, 4: 1.57, 5: 2.04, 6: 2.55, 7: 3.04, 8: 3.44, 9: 3.98, 10: 4.50,
    11: 0.93, 12: 1.31, 13: 1.61, 14: 1.90, 15: 2.19, 16: 2.58, 17: 3.16,
    18: 3.50,
}

# ---- 1. Parse reference.inc (one-time, cached in module globals) --------
MAX_ELEM = 118
MAX_REF  = 7
NOMEGA   = 23
NSEC     = 18

import re

def parse_reference_inc(path):
    text = Path(path).read_text()
    text = re.sub(r"&\s*\n\s*&?", " ", text)

    out = {
        "refn":    np.zeros(MAX_ELEM + 1, dtype=int),
        "refsys":  np.zeros((MAX_REF + 1, MAX_ELEM + 1), dtype=int),
        "alphaiw": np.zeros((NOMEGA, MAX_REF + 1, MAX_ELEM + 1)),
        "secaiw":  np.zeros((NOMEGA, NSEC)),
    }
    for name in ("dftq", "hcount", "ascale", "refcovcn", "refcn", "clsh", "clsq"):
        out[name] = np.zeros((MAX_REF + 1, MAX_ELEM + 1))
    for name in ("secq", "sscale", "seccnD3", "seccn"):
        out[name] = np.zeros(NSEC)

    for m in re.finditer(r"data\s+refn\s*\(\s*(\d+)\s*\)\s*/\s*(\d+)\s*/", text):
        out["refn"][int(m.group(1))] = int(m.group(2))

    for m in re.finditer(
        r"data\s+(dftq|hcount|ascale|refcovcn|refcn|clsh|clsq)"
        r"\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*/\s*([\-0-9.eEdDwp_+]+)\s*/",
        text,
    ):
        name, ir, iat, v = m.groups()
        out[name][int(ir), int(iat)] = float(
            v.replace("_wp","").replace("D","e").replace("d","e"))

    for m in re.finditer(
        r"data\s+refsys\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*/\s*(-?\d+)\s*/", text,
    ):
        out["refsys"][int(m.group(1)), int(m.group(2))] = int(m.group(3))

    for m in re.finditer(
        r"data\s+(secq|sscale|seccnD3|seccn)\s*\(\s*(\d+)\s*\)\s*/\s*"
        r"([\-0-9.eEdDwp_+]+)\s*/",
        text,
    ):
        name, idx, v = m.groups()
        out[name][int(idx)] = float(
            v.replace("_wp","").replace("D","e").replace("d","e"))

    for m in re.finditer(
        r"data\s+alphaiw\s*\(\s*:\s*,\s*(\d+)\s*,\s*(\d+)\s*\)\s*/([^/]+)/",
        text,
    ):
        ir, iat, payload = int(m.group(1)), int(m.group(2)), m.group(3)
        nums = re.findall(r"[\-0-9.eEdDwp_+]+", payload)
        vals = [float(x.replace("_wp","").replace("D","e").replace("d","e"))
                for x in nums if any(c.isdigit() for c in x)]
        if len(vals) == NOMEGA:
            out["alphaiw"][:, ir, iat] = vals

    for m in re.finditer(
        r"data\s+secaiw\s*\(\s*:\s*,\s*(\d+)\s*\)\s*/([^/]+)/", text,
    ):
        idx, payload = int(m.group(1)), m.group(2)
        nums = re.findall(r"[\-0-9.eEdDwp_+]+", payload)
        vals = [float(x.replace("_wp","").replace("D","e").replace("d","e"))
                for x in nums if any(c.isdigit() for c in x)]
        if len(vals) == NOMEGA:
            out["secaiw"][:, idx] = vals

    return out

REFINC = parse_reference_inc(
    "/tmp/dftd4-src/dftd4-4.1.0/subprojects/dftd4/src/dftd4/reference.inc"
)

# ---- 2. Auxiliary functions (exact copies of dftd4 utils.f90) -----------
def zeta_fn(a, c, qref, qmod):
    """dftd4_model_utils::zeta."""
    if qmod < 0.0:
        return np.exp(a)
    return np.exp(a * (1.0 - np.exp(c * (1.0 - qref / qmod))))

def weight_cn(wf, cn, cnref):
    return np.exp(-wf * (cn - cnref) ** 2)

# 23-point Casimir-Polder integration weights
FREQ_OMEGA = np.array([
    0.000001, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70,
    0.80, 0.90, 1.00, 1.20, 1.40, 1.60, 1.80, 2.00, 2.50, 3.00,
    4.00, 5.00, 7.50, 10.00,
])
TRAP_W = 0.5 * np.concatenate([
    [FREQ_OMEGA[1] - FREQ_OMEGA[0]],
    [FREQ_OMEGA[i + 1] - FREQ_OMEGA[i - 1] for i in range(1, NOMEGA - 1)],
    [FREQ_OMEGA[NOMEGA - 1] - FREQ_OMEGA[NOMEGA - 2]],
])
THOPI = 3.0 / np.pi

def build_refalpha_eeq(Z, ga=3.0, gc=2.0):
    """Exact Python copy of reference.f90::set_refalpha_eeq_num."""
    nref = REFINC["refn"][Z]
    alpha = np.zeros((NOMEGA, nref))
    for ir in range(1, nref + 1):
        isec = REFINC["refsys"][ir, Z]
        if abs(isec) < 1e-12:
            continue
        iz = zeff_fn(isec)
        eta_is = hardness_fn(isec)
        aiw = (REFINC["sscale"][isec] * REFINC["secaiw"][:, isec]
               * zeta_fn(ga, eta_is * gc, iz,
                          REFINC["clsh"][ir, Z] + iz))
        scale = REFINC["ascale"][ir, Z]
        hcnt  = REFINC["hcount"][ir, Z]
        a_ref = REFINC["alphaiw"][:, ir, Z]
        alpha[:, ir - 1] = np.maximum(scale * (a_ref - hcnt * aiw), 0.0)
    return alpha

# ---- 3. D4 coordination number (with EN weighting) ----------------------
#   mctc_ncoord_erf_dftd4 constants (exact):
K4 = 4.10451
K5 = 19.08857
K6 = 2 * 11.28174 ** 2.0
KCN = 7.5
NORM_EXP = 1.0
CN_CUTOFF = 25.0

def en_factor(zi, zj):
    """erf_dftd4::get_en_factor."""
    return K4 * np.exp(-(abs(PAULING_EN[zi] - PAULING_EN[zj]) + K5) ** 2 / K6)

def compute_d4_cn(numbers, positions):
    """mctc_ncoord::ncoord with cn_count%dftd4 -- the D4-flavor CN with
    electronegativity factor, matching mctc-lib erf_dftd4.  This is the
    CN that feeds weight_references.  It is NOT the CN to pass to the
    EEQ solver; see compute_eeq_cn below.
    """
    n = len(numbers)
    rcov = np.array([rcov_fn(z) for z in numbers])
    cn = np.zeros(n)
    cutoff2 = CN_CUTOFF ** 2
    for i in range(n):
        for j in range(i + 1):
            rij = positions[i] - positions[j]
            r2  = rij @ rij
            if r2 > cutoff2 or r2 < 1e-12:
                continue
            r1 = np.sqrt(r2)
            rc = rcov[i] + rcov[j]
            den = en_factor(numbers[i], numbers[j])
            count = 0.5 * (1.0 + __import__("math").erf(-KCN * (r1 - rc) / rc ** NORM_EXP))
            countf = den * count
            cn[i] += countf
            if i != j:
                cn[j] += countf  # directed_factor = +1 for D4
    return cn

# Backward-compatible alias -- the original prototype exposed a single
# compute_cn that returned the D4-flavor CN.  Keep it so downstream
# call sites that imported the old name keep working.
compute_cn = compute_d4_cn


def compute_eeq_cn(numbers, positions):
    """multicharge::ncoord with cn_count%exp (plain erf, no EN factor),
    followed by log_cn_cut(cn, cn_max=8) smoothing.  Matches
    multicharge/src/multicharge/model/eeq.f90 verbatim.  This is the
    CN that feeds the EEQ charge solver.

    Mixing this up with compute_d4_cn (as earlier prototype versions
    did) causes partial charges on polarized atoms to be off by ~3%,
    which amplifies through the zeta scaling to ~10-15% in final
    dispersion energy.
    """
    n = len(numbers)
    rcov = np.array([rcov_fn(z) for z in numbers])
    cn = np.zeros(n)
    cutoff2 = CN_CUTOFF ** 2
    for i in range(n):
        for j in range(i + 1):
            rij = positions[i] - positions[j]
            r2  = rij @ rij
            if r2 > cutoff2 or r2 < 1e-12:
                continue
            r1 = np.sqrt(r2)
            rc = rcov[i] + rcov[j]
            # NOTE: no EN factor here -- this is the plain counting
            count = 0.5 * (1.0 + __import__("math").erf(-KCN * (r1 - rc) / rc ** NORM_EXP))
            cn[i] += count
            if i != j:
                cn[j] += count
    # log_cn_cut(cn, cn_max=8.0):  cn <- log(1+exp(8)) - log(1+exp(8-cn))
    cn_max = 8.0
    log_cnmax = np.log(1.0 + np.exp(cn_max))
    cn = log_cnmax - np.log(1.0 + np.exp(cn_max - cn))
    return cn

# ---- 4. EEQ2019 charge model --------------------------------------------
def solve_eeq(numbers, positions, cn, total_charge=0.0):
    """multicharge::get_eeq_charges for a molecular (non-periodic) system.

    Builds and solves the augmented (n+1)x(n+1) symmetric system:

        [ A  1 ] [ q ]   [ -chi - kcn*sqrt(cn) ]
        [ 1' 0 ] [ L ] = [ total_charge        ]

    where A_ii = eta + sqrt(2/pi)/rad   and
          A_ij = erf(R_ij / sqrt(rad_i^2 + rad_j^2)) / R_ij   (i != j)
    """
    n = len(numbers)
    chi = np.array([eeq_chi_fn(z) for z in numbers])
    eta = np.array([eeq_eta_fn(z) for z in numbers])
    rad = np.array([eeq_rad_fn(z) for z in numbers])
    kcn = np.array([eeq_kcn_fn(z) for z in numbers])

    # Guard sqrt(cn) — dftd4 clips cn at zero
    cn_safe = np.maximum(cn, 0.0)
    x = -(chi - kcn * np.sqrt(cn_safe))

    A = np.zeros((n + 1, n + 1))
    for i in range(n):
        A[i, i] = eta[i] + np.sqrt(2.0 / np.pi) / rad[i]
        for j in range(i):
            rij = positions[i] - positions[j]
            r   = np.sqrt(rij @ rij)
            gam = 1.0 / np.sqrt(rad[i] ** 2 + rad[j] ** 2)
            aij = __import__("math").erf(r * gam) / r
            A[i, j] = A[j, i] = aij
        A[i, n] = A[n, i] = 1.0
    A[n, n] = 0.0

    rhs = np.concatenate([x, [total_charge]])
    sol = np.linalg.solve(A, rhs)
    return sol[:n]

# ---- 5. Weight references + atomic C6 -----------------------------------
WF_DEFAULT = 6.0
GA_DEFAULT = 3.0
GC_DEFAULT = 2.0
# For D4-2019 each reference has a single Gaussian width (ngw(iref,Z)=1 is
# the default -- simple-dftd4 uses set_refgw which for D4 always returns 1).

def compute_ngw(Z):
    """Reference set_refgw_num from dftd4/reference.f90 — counts how many
    times each CN bin is used and assigns triangular numbers to the slots."""
    nref = REFINC["refn"][Z]
    if nref == 0:
        return np.zeros(MAX_REF + 1, dtype=int)
    max_cn = 19
    cnc = [1] + [0] * max_cn
    for ir in range(1, nref + 1):
        icn = min(round(REFINC["refcn"][ir, Z]), max_cn)
        cnc[icn] += 1
    ngw = np.ones(MAX_REF + 1, dtype=int)
    for ir in range(1, nref + 1):
        icn = cnc[min(round(REFINC["refcn"][ir, Z]), max_cn)]
        ngw[ir] = icn * (icn + 1) // 2
    return ngw

_NGW_CACHE = {}
def get_ngw(Z):
    if Z not in _NGW_CACHE:
        _NGW_CACHE[Z] = compute_ngw(Z)
    return _NGW_CACHE[Z]

def weight_references(numbers, cn, q):
    """dftd4_model_d4::weight_references (energy variant, no derivs).

    Note: each reference system has ngw(iref) Gaussians stacked at widths
    wf, 2*wf, 3*wf, ..., ngw(iref)*wf -- this is the nested loop that I was
    missing in the first prototype version.

    CN-matching subtlety (fixed in v0.58.0): this routine matches the
    runtime D4-CN against REFINC["refcovcn"], NOT REFINC["refcn"].
    reference.inc ships BOTH per-iref CN columns (they differ by up to
    25% on multi-reference O/N/C), and the canonical set_refcn_num
    routine populates d4_model%cn from refcovcn.  Using refcn here (as
    earlier prototype versions did) cascaded into a ~1-2% energy error.
    NGW binning (above) still uses refcn, per canonical set_refgw_num.
    """
    n = len(numbers)
    mref = max(REFINC["refn"][z] for z in numbers)
    gw = np.zeros((mref, n))
    eps_norm = np.finfo(float).tiny ** 0.5

    for iat in range(n):
        Z = numbers[iat]
        nref = REFINC["refn"][Z]
        zi = zeff_fn(Z)
        gi = hardness_fn(Z) * GC_DEFAULT
        ngw_arr = get_ngw(Z)

        # Norm over all reference systems with all stacked Gaussians
        norm = 0.0
        for iref in range(1, nref + 1):
            for igw in range(1, ngw_arr[iref] + 1):
                wf = igw * WF_DEFAULT
                norm += weight_cn(wf, cn[iat], REFINC["refcovcn"][iref, Z])
        if abs(norm) > eps_norm:
            inv_norm = 1.0 / norm
        else:
            inv_norm = 0.0

        for iref in range(1, nref + 1):
            expw = 0.0
            for igw in range(1, ngw_arr[iref] + 1):
                wf = igw * WF_DEFAULT
                expw += weight_cn(wf, cn[iat], REFINC["refcovcn"][iref, Z])
            gwk = expw * inv_norm
            if not np.isfinite(gwk) or inv_norm == 0.0:
                maxcn = max(REFINC["refcovcn"][ir, Z] for ir in range(1, nref + 1))
                gwk = 1.0 if abs(maxcn - REFINC["refcovcn"][iref, Z]) < 1e-12 else 0.0
            qref = REFINC["clsq"][iref, Z]
            gw[iref - 1, iat] = gwk * zeta_fn(GA_DEFAULT, gi, qref + zi, q[iat] + zi)
    return gw

# Pre-compute the pair C6 from the extracted alpha(omega) tables
_ALPHA_CACHE = {}
def get_pair_c6(zA, iA, zB, iB):
    if zA not in _ALPHA_CACHE:
        _ALPHA_CACHE[zA] = build_refalpha_eeq(zA)
    if zB not in _ALPHA_CACHE:
        _ALPHA_CACHE[zB] = build_refalpha_eeq(zB)
    aiw = _ALPHA_CACHE[zA][:, iA] * _ALPHA_CACHE[zB][:, iB]
    return THOPI * np.sum(aiw * TRAP_W)

def atomic_c6(numbers, gw):
    """dftd4_model_d4::get_atomic_c6."""
    n = len(numbers)
    c6 = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1):
            nri = REFINC["refn"][numbers[i]]
            nrj = REFINC["refn"][numbers[j]]
            s = 0.0
            for iref in range(nri):
                for jref in range(nrj):
                    cij = get_pair_c6(numbers[i], iref, numbers[j], jref)
                    s += gw[iref, i] * gw[jref, j] * cij
            c6[i, j] = c6[j, i] = s
    return c6

# ---- 6. BJ damping energy ------------------------------------------------
def d4_energy_bj(numbers, positions, params):
    """Total D4-BJ 2-body dispersion energy.

    Uses the two-CN pipeline that canonical dftd4 uses:
      - EEQ-CN (plain + log_cn_cut) feeds the charge solver
      - D4-CN  (with EN factor) feeds weight_references
    Earlier prototype versions passed a single D4-CN into both paths,
    which made charges on polarized atoms (O/N) off by ~3% and cascaded
    into ~0.5-2% final-energy error.  Fixed in v0.58.0.
    """
    n = len(numbers)
    r4r2 = np.array([r4r2_fn(z) for z in numbers])
    cn_d4  = compute_d4_cn (numbers, positions)
    cn_eeq = compute_eeq_cn(numbers, positions)
    q  = solve_eeq(numbers, positions, cn_eeq)
    gw = weight_references(numbers, cn_d4, q)
    c6 = atomic_c6(numbers, gw)

    s6, s8, a1, a2 = params["s6"], params["s8"], params["a1"], params["a2"]
    E = 0.0
    for i in range(n - 1):
        for j in range(i + 1, n):
            rij = positions[i] - positions[j]
            r2  = rij @ rij
            if r2 < 1e-12:
                continue
            r6 = r2 ** 3
            r8 = r6 * r2
            c6ij = c6[i, j]
            c8ij = 3.0 * c6ij * r4r2[i] * r4r2[j]
            f = a1 * np.sqrt(c8ij / c6ij) + a2
            f6 = f ** 6
            f8 = f ** 8
            E -= s6 * c6ij / (r6 + f6) + s8 * c8ij / (r8 + f8)
    # Return the D4-CN for backward compatibility of the cn field.
    return E, cn_d4, q, c6


# ---- 7. Validation against libdftd4 -------------------------------------
if __name__ == "__main__":
    from dftd4.interface import DispersionModel, DampingParam

    # BP86 D4(BJ) parameters -- note s8, a1, a2 all differ from the
    # BP86 D3(BJ) values.  These match canonical dftd4 parameters.toml.
    BP86 = dict(s6=1.0, s8=3.35497927, a1=0.43645861, a2=4.92406854)

    tests = [
        ("H2 at 1.4",  [1, 1], [[0,0,0],[1.4,0,0]]),
        ("H2O",        [8, 1, 1], [[0,0,0],[1.8,0,0],[0,1.8,0]]),
        ("CH4+H2O",    [6,1,1,1,1,8,1,1],
         [[0,0,0],[1.186,1.186,1.186],[-1.186,-1.186,1.186],
          [-1.186,1.186,-1.186],[1.186,-1.186,-1.186],
          [7.0,0,0],[7.8,1.5,0],[7.8,-1.5,0]]),
    ]
    print(f"{'test':<14s} {'dE':>14s} {'max|dq|':>12s} {'max|dcn|':>12s}"
          f" {'max|dC6|':>12s}")
    for name, nums, pos in tests:
        nums = np.array(nums, dtype=np.int32)
        pos  = np.array(pos, dtype=np.float64)

        E_my, cn_my, q_my, c6_my = d4_energy_bj(nums, pos, BP86)

        m = DispersionModel(numbers=nums, positions=pos)
        E_ref = m.get_dispersion(param=DampingParam(method="bp"),
                                  grad=False)["energy"]
        p = m.get_properties()
        cn_ref = p["coordination numbers"]
        q_ref  = p["partial charges"]
        c6_ref = np.asarray(p["c6 coefficients"]).reshape(len(nums),len(nums))

        dE  = abs(E_my - E_ref)
        dq  = np.max(np.abs(q_my - q_ref))
        dcn = np.max(np.abs(cn_my - cn_ref))
        dc6 = np.max(np.abs(c6_my - c6_ref))
        print(f"{name:<14s} {dE:14.2e} {dq:12.2e} {dcn:12.2e} {dc6:12.2e}")
