#!/bin/bash
# =============================================================
# StudDFT v0.72.0 -- Transition-state search test suite
# =============================================================
#
# Runs every test_v072_*.inp under tests/ and verifies:
#
#   * Smoke test (h2o freq writes hess): "%job freq" produces both
#     a .hess and a .molden file with the right basenames.
#
#   * HCN -> HNC TS (auto-Hessian path): converges, final energy
#     matches the known HF/STO-3G TS value (-91.5649 Ha) within
#     1 mHa, validation freq pass reports exactly one imaginary
#     mode in the right cm^-1 range.
#
#   * HCN -> HNC TS (read-cached-Hessian path): loads the .hess
#     written by the previous test, converges to the same TS in
#     the same step count and final energy.
#
#   * HOOH cis/trans barrier: converges, validation freq pass
#     reports one imaginary mode in the few-hundred cm^-1 range
#     consistent with the torsion mode.
#
#   * Geometry-mismatch negative test: the reader detects an atom
#     moved by 0.5 A and aborts with rc=1 + "geometry mismatch"
#     diagnostic.
#
#   * Method-mismatch negative test: the reader detects a B3LYP
#     follow-up against an HF-written .hess file and aborts with
#     rc=1 + "method mismatch" diagnostic.
#
# Usage: ./run_v072_tests.sh [path_to_studdft]
# =============================================================

set -u
EXE=${1:-./studdft}
cd "$(dirname "$0")/.."
export STUDDFT="$PWD"

PASS=0
FAIL=0

# Helper: run an input and capture stdout into $OUTBUF, return rc
run_input() {
    local inp="$1"
    OUTBUF=$($EXE "$inp" 2>&1)
    return $?
}

# Helper: extract the last "Final energy:" value (may appear in
# both the optimizer summary and the post-pass freq summary; we
# want the optimizer's value, which comes first).
final_energy() {
    echo "$OUTBUF" | awk '/Final energy:/{print $3; exit}'
}

# Helper: extract the (signed) imaginary-mode frequency printed by
# the validation freq pass.  We grab the line that says "imag",
# field 2 is the frequency.
last_imag_freq() {
    echo "$OUTBUF" | awk '/imag/{f=$2} END{print f}'
}

# ---------- 1. h2o freq writes hess (smoke) ----------
echo
echo "=== Test 1: h2o freq writes hess + molden ==="
rm -f test_v072_h2o_freq_writes_hess.hess test_v072_h2o_freq_writes_hess.molden
run_input tests/test_v072_h2o_freq_writes_hess.inp
rc=$?
if [ $rc -eq 0 ] \
    && [ -f test_v072_h2o_freq_writes_hess.hess ] \
    && [ -f test_v072_h2o_freq_writes_hess.molden ]; then
    echo "  PASS  test_v072_h2o_freq_writes_hess  (rc=0, both files present)"
    PASS=$((PASS+1))
else
    echo "  FAIL  test_v072_h2o_freq_writes_hess  (rc=$rc, files: \
$( [ -f test_v072_h2o_freq_writes_hess.hess ] && echo hess || echo HESS-MISSING ) \
$( [ -f test_v072_h2o_freq_writes_hess.molden ] && echo molden || echo MOLDEN-MISSING ))"
    FAIL=$((FAIL+1))
fi

# ---------- 2. HCN -> HNC TS+FREQ (auto-Hessian) ----------
echo
echo "=== Test 2: HCN -> HNC TS+FREQ (auto-Hessian path) ==="
rm -f test_v072_hcn_tsfreq.hess test_v072_hcn_tsfreq.molden \
      test_v072_hcn_tsfreq_ts.hess test_v072_hcn_tsfreq_ts.molden
run_input tests/test_v072_hcn_tsfreq.inp
rc=$?
e_final=$(final_energy)
imag_freq=$(last_imag_freq)
e_ref="-91.564"
# Verify rc, energy in [-91.566, -91.563], imag freq present
if [ $rc -eq 0 ] \
    && [ -f test_v072_hcn_tsfreq.hess ] \
    && [ -f test_v072_hcn_tsfreq_ts.hess ] \
    && awk -v e="$e_final" 'BEGIN{ if (e < -91.566 || e > -91.563) exit 1 }' \
    && [ -n "$imag_freq" ] \
    && awk -v f="$imag_freq" 'BEGIN{ if (f > -100.0 || f < -3000.0) exit 1 }'; then
    echo "  PASS  test_v072_hcn_tsfreq  (E=$e_final, imag=$imag_freq cm^-1)"
    PASS=$((PASS+1))
else
    echo "  FAIL  test_v072_hcn_tsfreq  (rc=$rc, E=$e_final, imag=$imag_freq)"
    FAIL=$((FAIL+1))
fi

# ---------- 3. HCN -> HNC TS via %read_hess ----------
echo
echo "=== Test 3: HCN -> HNC TS (read cached Hessian) ==="
# DON'T remove test_v072_hcn_tsfreq.hess -- this test consumes it!
run_input tests/test_v072_hcn_ts_read.inp
rc=$?
e_read=$(final_energy)
# Should match Test 2's optimizer value within 0.1 mHa
e_ref="-91.5648999"
if [ $rc -eq 0 ] \
    && awk -v e="$e_read" 'BEGIN{ if (e < -91.566 || e > -91.563) exit 1 }'; then
    echo "  PASS  test_v072_hcn_ts_read  (E=$e_read)"
    PASS=$((PASS+1))
else
    echo "  FAIL  test_v072_hcn_ts_read  (rc=$rc, E=$e_read)"
    FAIL=$((FAIL+1))
fi

# ---------- 4. HOOH cis/trans TS ----------
echo
echo "=== Test 4: HOOH cis/trans torsion TS+FREQ ==="
rm -f test_v072_hooh_tsfreq.hess test_v072_hooh_tsfreq.molden \
      test_v072_hooh_tsfreq_ts.hess test_v072_hooh_tsfreq_ts.molden
run_input tests/test_v072_hooh_tsfreq.inp
rc=$?
e_hooh=$(final_energy)
# HOOH HF/STO-3G TS energy ~ -148.76 Ha
if [ $rc -eq 0 ] \
    && [ -f test_v072_hooh_tsfreq.hess ] \
    && awk -v e="$e_hooh" 'BEGIN{ if (e < -148.80 || e > -148.74) exit 1 }'; then
    echo "  PASS  test_v072_hooh_tsfreq  (E=$e_hooh)"
    PASS=$((PASS+1))
else
    echo "  FAIL  test_v072_hooh_tsfreq  (rc=$rc, E=$e_hooh)"
    FAIL=$((FAIL+1))
fi

# ---------- 5. Geometry-mismatch negative test ----------
echo
echo "=== Test 5: Geometry mismatch detection (negative) ==="
run_input tests/test_v072_hess_geom_mismatch.inp
rc=$?
if [ $rc -ne 0 ] \
    && echo "$OUTBUF" | grep -q "geometry mismatch"; then
    echo "  PASS  test_v072_hess_geom_mismatch  (clean diagnostic, rc=$rc)"
    PASS=$((PASS+1))
else
    echo "  FAIL  test_v072_hess_geom_mismatch  (rc=$rc, no mismatch diagnostic)"
    FAIL=$((FAIL+1))
fi

# ---------- 6. Method-mismatch negative test ----------
echo
echo "=== Test 6: Method mismatch detection (negative) ==="
run_input tests/test_v072_hess_method_mismatch.inp
rc=$?
if [ $rc -ne 0 ] \
    && echo "$OUTBUF" | grep -q "method mismatch"; then
    echo "  PASS  test_v072_hess_method_mismatch  (clean diagnostic, rc=$rc)"
    PASS=$((PASS+1))
else
    echo "  FAIL  test_v072_hess_method_mismatch  (rc=$rc, no mismatch diagnostic)"
    FAIL=$((FAIL+1))
fi

# ---------- summary ----------
echo
echo "  Summary:  $PASS passed, $FAIL failed."
echo

# Cleanup output files (leave only the .inp inputs alongside the
# other test_v0xx_*.inp from older release suites)
rm -f test_v072_*.hess test_v072_*.molden

if [ $FAIL -gt 0 ]; then
    exit 1
else
    exit 0
fi
