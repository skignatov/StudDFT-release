#!/usr/bin/env python3
# ============================================================================
# StudDFT -- Convert dftd3 reference data to StudDFT D3 C6 format
#
# Usage:
#   python convert_dftd3_pars.py <path_to_dftd3_pars.f> [<output.dat>]
#
# The Grimme dftd3 Fortran source distributes the reference C6 database as
# one or several fixed-form include files, typically pars.f or copyc6.f,
# containing lines of the form
#
#     c6ab(iat,jat,iadr,jadr,1) =  7.5916d0
#     c6ab(iat,jat,iadr,jadr,2) =  0.9118d0
#     c6ab(iat,jat,iadr,jadr,3) =  0.9118d0
#
# where the 5th index selects (1) C6 value, (2) CN of atom A, (3) CN of B.
# A single reference point is therefore spread over THREE consecutive lines.
# This script collects complete triplets and emits them in StudDFT's
# free-format database style:
#
#     Z_A  Z_B  CN_A  CN_B  C6_AB
#
# Requirements: Python 3.6+, no external libraries.
#
# This utility intentionally does not depend on dftd3 being installed; it
# only parses the text of pars.f.  The dftd3 source is distributed under
# its own (academic) license by the Grimme group, University of Bonn.
# ============================================================================
import re
import sys
from collections import defaultdict

PATTERN = re.compile(
    r"""c6ab\s*\(\s*
        (\d+)\s*,\s*    # iat  (Z of atom A, 1-based)
        (\d+)\s*,\s*    # jat  (Z of atom B)
        (\d+)\s*,\s*    # iadr (ref-CN index for A)
        (\d+)\s*,\s*    # jadr (ref-CN index for B)
        (\d+)\s*\)\s*=  # k: 1=C6, 2=CN_A, 3=CN_B
        \s*([\-\+0-9\.dDeE]+)""",
    re.VERBOSE,
)


def parse_pars(path):
    """Return dict keyed by (zA,zB,iA,iB) -> [C6, CNA, CNB]."""
    records = defaultdict(lambda: [None, None, None])
    nlines = 0
    with open(path, "r") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("!") or line.startswith("c "):
                continue
            m = PATTERN.search(line)
            if not m:
                continue
            za, zb, ia, ib, k, val = m.groups()
            za, zb = int(za), int(zb)
            ia, ib = int(ia), int(ib)
            k = int(k)
            val = float(val.replace("d", "e").replace("D", "e"))
            records[(za, zb, ia, ib)][k - 1] = val
            nlines += 1
    print(f"# Parsed {nlines} c6ab() lines from {path}", file=sys.stderr)
    return records


def write_dat(records, outpath):
    """Emit StudDFT format, upper triangle only (Z_A <= Z_B)."""
    with open(outpath, "w") as fh:
        fh.write("# StudDFT D3 reference C6 database\n")
        fh.write("# Generated automatically from dftd3's pars.f\n")
        fh.write("# Format: Z_A Z_B CN_A CN_B C6_AB (atomic units)\n")
        fh.write("#\n")
        fh.write("# Source: Grimme group reference implementation (dftd3)\n")
        fh.write("# Reference: Grimme et al., JCP 132, 154104 (2010)\n")
        fh.write("#\n")
        nwritten = 0
        nskipped = 0
        # Sort by (zA, zB, iA, iB) for stable output
        keys = sorted(records.keys())
        current_pair = None
        for k in keys:
            za, zb, ia, ib = k
            if za > zb:
                nskipped += 1
                continue
            rec = records[k]
            if any(v is None for v in rec):
                print(
                    f"# WARNING: incomplete record {k}: {rec}",
                    file=sys.stderr,
                )
                continue
            c6, cna, cnb = rec
            if (za, zb) != current_pair:
                fh.write(f"# ---- Z={za:<2d} - Z={zb:<2d} ----\n")
                current_pair = (za, zb)
            fh.write(
                f"  {za:<3d}{zb:<3d}"
                f"{cna:10.6f}{cnb:10.6f}{c6:14.6f}\n"
            )
            nwritten += 1
        fh.write("\n# End of database.\n")
    print(
        f"# Wrote {nwritten} unique reference entries "
        f"(skipped {nskipped} lower-triangle duplicates).",
        file=sys.stderr,
    )


def main(argv):
    if len(argv) < 2 or len(argv) > 3:
        print(
            "Usage: convert_dftd3_pars.py <pars.f> [output.dat]",
            file=sys.stderr,
        )
        return 1
    inpath = argv[1]
    outpath = argv[2] if len(argv) == 3 else "d3_c6ref.dat"
    records = parse_pars(inpath)
    if not records:
        print(
            "# ERROR: no c6ab() records found in the input file.",
            file=sys.stderr,
        )
        return 2
    write_dat(records, outpath)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
