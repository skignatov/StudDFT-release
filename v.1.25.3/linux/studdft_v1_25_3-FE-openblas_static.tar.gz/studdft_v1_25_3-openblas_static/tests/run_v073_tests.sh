#!/bin/bash
# =============================================================
# StudDFT v0.73.0 -- C-PCM Stage 1 test suite
# =============================================================
#
# Runs every test_v073_*.inp under tests/ and verifies:
#
#   * test_v073_no_pcm_regression
#       HF/STO-3G water without any solvent keyword.  Asserts the
#       total energy is bit-for-bit identical to v0.72.0 to within
#       1e-9 Ha (i.e. the optional pcm argument did not break the
#       gas-phase code path).  Reference: -74.963919012725 Ha.
#
#   * test_v073_h2o_cpcm_water
#       HF/STO-3G water in C-PCM water (eps = 78.36).  Asserts:
#         - SCF converged
#         - G_pol < 0 (solvation stabilizes)
#         - |sum(q)| < 0.05 (Gauss-law: ~0 for a neutral solute)
#         - Total energy more negative than the no-PCM regression
#
#   * test_v073_h2o_cpcm_dmso
#       Same molecule in DMSO (eps = 46.83).  Asserts G_pol still
#       negative, and |G_pol(DMSO)| < |G_pol(water)| (less polar
#       solvent gives smaller stabilization).
#
#   * test_v073_methanol_cpcm
#       Methanol in water.  Smoke test: cavity build, multi-element
#       atomic radii, full SCF with PCM.  Asserts G_pol < 0 and
#       SCF converged.
#
#   * test_v073_anion_cpcm
#       F- (charge = -1) in water.  Strict Gauss-law check:
#       sum(q) is expected to be approximately +0.987 = -Q*(eps-1)/eps.
#       Asserts |sum(q) - 0.987| < 0.10 (10% tolerance for the
#       lebedev_n = 110 discretization on a single sphere).
#
#   * test_v073_h2o_b3lyp_cpcm
#       Water in water at B3LYP/STO-3G.  Exercises the DFT + PCM
#       code path simultaneously; asserts SCF converged and G_pol < 0.
#
#   * test_v073_oh_uhf_cpcm
#       OH radical in water.  Exercises run_scf_uhf with PCM;
#       asserts SCF converged and G_pol < 0 and <S^2> close to 0.75.
#
#   * test_v073_negative_grad
#       NEGATIVE test:  "%solvent water" + "%job gradient" must
#       abort cleanly with the Stage-2 deferral message and rc != 0.
#
# Usage: ./run_v073_tests.sh [path_to_studdft]
# =============================================================

set -u
EXE=${1:-./studdft}
cd "$(dirname "$0")/.."
export STUDDFT="$PWD"

PASS=0
FAIL=0
FAIL_NAMES=()

# -----------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------
run_input() {
    # Run input and capture output; return rc.
    local inp="$1"
    OUTBUF=$($EXE "$inp" 2>&1)
    return $?
}

# Extract the last "Total energy:" value from $OUTBUF.
last_total_energy() {
    echo "$OUTBUF" | awk '/Total energy:/ {v=$NF} END {print v}'
}

# Extract the final "PCM G_pol:" value from $OUTBUF.
last_g_pol() {
    echo "$OUTBUF" | awk '/PCM G_pol:/ {v=$NF} END {print v}'
}

# Extract the final "sum(q):" value from $OUTBUF.  The line format is
#   "     sum(q):                 -0.001963868928   (Gauss-law: ...)"
# so the value is the second field, taking the token right after "sum(q):".
last_sum_q() {
    echo "$OUTBUF" | awk '/sum\(q\):/ {v=$2} END {print v}'
}

# Extract <S^2> if present.
last_s2() {
    echo "$OUTBUF" | awk '/<S\*\*2> =/ {v=$3} END {print v}'
}

# Floating-point comparison: "is |a - b| < tol?"
abs_lt() {
    local a="$1" b="$2" tol="$3"
    awk -v a="$a" -v b="$b" -v t="$tol" \
        'BEGIN {d = a - b; if (d < 0) d = -d; exit !(d < t)}'
}

# Pass / fail bookkeeping.
pass() { PASS=$((PASS+1)); printf "  PASS  %s\n" "$1"; }
fail() { FAIL=$((FAIL+1)); FAIL_NAMES+=("$1"); printf "  FAIL  %s  (%s)\n" "$1" "$2"; }

# -----------------------------------------------------------------
# 1. No-PCM regression -- bit identical to v0.72.0 path
# -----------------------------------------------------------------
echo
echo "=== Test 1: no-PCM regression (water HF/STO-3G) ==="
run_input "tests/test_v073_no_pcm_regression.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "no_pcm_regression" "rc=$rc"
else
    E=$(last_total_energy)
    REF="-74.963919012725"
    if abs_lt "$E" "$REF" "1.0e-8"; then
        pass "no_pcm_regression  E = $E"
    else
        fail "no_pcm_regression" "E = $E, expected ~ $REF"
    fi
fi

# -----------------------------------------------------------------
# 2. Water in water -- the canonical C-PCM smoke test
# -----------------------------------------------------------------
echo
echo "=== Test 2: water in water (HF/STO-3G C-PCM) ==="
run_input "tests/test_v073_h2o_cpcm_water.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "h2o_cpcm_water" "rc=$rc"
else
    E_solv=$(last_total_energy)
    G_pol_water=$(last_g_pol)       # save for test 3 comparison
    SUMQ=$(last_sum_q)
    if ! echo "$OUTBUF" | grep -q "SCF converged"; then
        fail "h2o_cpcm_water" "SCF did not converge"
    elif ! awk -v g="$G_pol_water" 'BEGIN {exit !(g < 0)}'; then
        fail "h2o_cpcm_water" "G_pol >= 0:  $G_pol_water"
    elif ! abs_lt "$SUMQ" "0" "0.05"; then
        fail "h2o_cpcm_water" "|sum(q)| > 0.05:  $SUMQ"
    else
        pass "h2o_cpcm_water  E_solv = $E_solv  G_pol = $G_pol_water  sum(q) = $SUMQ"
    fi
fi

# -----------------------------------------------------------------
# 3. Water in DMSO -- |G_pol(DMSO)| < |G_pol(water)|
# -----------------------------------------------------------------
echo
echo "=== Test 3: water in DMSO (HF/STO-3G C-PCM) ==="
run_input "tests/test_v073_h2o_cpcm_dmso.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "h2o_cpcm_dmso" "rc=$rc"
else
    G_pol_dmso=$(last_g_pol)
    if ! awk -v g="$G_pol_dmso" 'BEGIN {exit !(g < 0)}'; then
        fail "h2o_cpcm_dmso" "G_pol >= 0:  $G_pol_dmso"
    else
        # |G_pol(DMSO)| should be less than |G_pol(water)| (less polar)
        if awk -v gd="$G_pol_dmso" -v gw="${G_pol_water:-0}" \
              'BEGIN {ad=gd; if (ad<0) ad=-ad; aw=gw; if (aw<0) aw=-aw; exit !(ad < aw)}'; then
            pass "h2o_cpcm_dmso  G_pol(DMSO) = $G_pol_dmso  <  G_pol(water) = $G_pol_water"
        else
            fail "h2o_cpcm_dmso" "|G_pol(DMSO)| >= |G_pol(water)| violates polarity ordering"
        fi
    fi
fi

# -----------------------------------------------------------------
# 4. Methanol in water -- multi-element cavity smoke test
# -----------------------------------------------------------------
echo
echo "=== Test 4: methanol in water (HF/STO-3G C-PCM) ==="
run_input "tests/test_v073_methanol_cpcm.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "methanol_cpcm" "rc=$rc"
else
    G_pol=$(last_g_pol)
    if ! echo "$OUTBUF" | grep -q "SCF converged"; then
        fail "methanol_cpcm" "SCF did not converge"
    elif ! awk -v g="$G_pol" 'BEGIN {exit !(g < 0)}'; then
        fail "methanol_cpcm" "G_pol >= 0:  $G_pol"
    else
        pass "methanol_cpcm  G_pol = $G_pol"
    fi
fi

# -----------------------------------------------------------------
# 5. F- in water -- Gauss law: sum(q) ~ -Q*(eps-1)/eps = +0.987
# -----------------------------------------------------------------
echo
echo "=== Test 5: F- anion in water (HF/STO-3G C-PCM, Gauss-law check) ==="
run_input "tests/test_v073_anion_cpcm.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "anion_cpcm" "rc=$rc"
else
    SUMQ=$(last_sum_q)
    GAUSS_PRED="0.98724"   # +1 * (78.3553 - 1) / 78.3553
    if ! echo "$OUTBUF" | grep -q "SCF converged"; then
        fail "anion_cpcm" "SCF did not converge"
    elif abs_lt "$SUMQ" "$GAUSS_PRED" "0.10"; then
        pass "anion_cpcm  sum(q) = $SUMQ  (Gauss-law prediction $GAUSS_PRED)"
    else
        fail "anion_cpcm" "|sum(q) - Gauss pred| > 0.10:  $SUMQ vs $GAUSS_PRED"
    fi
fi

# -----------------------------------------------------------------
# 6. B3LYP + PCM
# -----------------------------------------------------------------
echo
echo "=== Test 6: water in water (B3LYP/STO-3G C-PCM) ==="
run_input "tests/test_v073_h2o_b3lyp_cpcm.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "h2o_b3lyp_cpcm" "rc=$rc"
else
    G_pol=$(last_g_pol)
    if ! echo "$OUTBUF" | grep -q "SCF converged"; then
        fail "h2o_b3lyp_cpcm" "SCF did not converge"
    elif ! awk -v g="$G_pol" 'BEGIN {exit !(g < 0)}'; then
        fail "h2o_b3lyp_cpcm" "G_pol >= 0:  $G_pol"
    else
        pass "h2o_b3lyp_cpcm  G_pol = $G_pol"
    fi
fi

# -----------------------------------------------------------------
# 7. UHF + PCM (open-shell)
# -----------------------------------------------------------------
echo
echo "=== Test 7: OH radical in water (UHF/STO-3G C-PCM) ==="
run_input "tests/test_v073_oh_uhf_cpcm.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "oh_uhf_cpcm" "rc=$rc"
else
    G_pol=$(last_g_pol)
    S2=$(last_s2)
    if ! echo "$OUTBUF" | grep -q "SCF converged"; then
        fail "oh_uhf_cpcm" "SCF did not converge"
    elif ! awk -v g="$G_pol" 'BEGIN {exit !(g < 0)}'; then
        fail "oh_uhf_cpcm" "G_pol >= 0:  $G_pol"
    elif ! abs_lt "$S2" "0.75" "0.05"; then
        fail "oh_uhf_cpcm" "<S^2> = $S2 (expected ~0.75)"
    else
        pass "oh_uhf_cpcm  G_pol = $G_pol  <S^2> = $S2"
    fi
fi

# -----------------------------------------------------------------
# 8. NEGATIVE: PCM + gradient must abort cleanly
# -----------------------------------------------------------------
echo
echo "=== Test 8: NEGATIVE test (PCM + gradient should abort) ==="
run_input "tests/test_v073_negative_grad.inp"
rc=$?
if [ $rc -eq 0 ]; then
    fail "negative_grad" "rc=0 (run should have failed)"
elif ! echo "$OUTBUF" | grep -qE "PCM ERROR.*(Stage 1|Stage 2\\.[0-9]).*only %job energy|PCM ERROR: Stage 1|PCM ERROR: PCM with this %job is deferred"; then
    fail "negative_grad" "no PCM stage deferral message in output"
else
    pass "negative_grad  rc = $rc  + Stage-1 deferral message present"
fi

# -----------------------------------------------------------------
# Final summary
# -----------------------------------------------------------------
echo
echo "============================================================="
printf "  v0.73.0 PCM Stage 1 tests:  %d PASS,  %d FAIL\n" "$PASS" "$FAIL"
echo "============================================================="
if [ $FAIL -ne 0 ]; then
    echo "Failed tests:"
    for n in "${FAIL_NAMES[@]}"; do echo "    - $n"; done
    exit 1
fi
exit 0
