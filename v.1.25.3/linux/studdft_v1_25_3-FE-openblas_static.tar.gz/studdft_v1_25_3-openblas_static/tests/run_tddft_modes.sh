#!/bin/bash
# =============================================================
# StudDFT v1.17.0 -- TDDFT mode-coverage matrix
# =============================================================
#
# WHAT THIS IS, AND WHAT IT IS NOT
# --------------------------------
# This is a COVERAGE smoke test, not a numerical anchor suite.  It
# answers one question: "does every advertised TDDFT mode still run,
# and does every advertised refusal still refuse?"  It does NOT
# validate excitation energies against theory -- that job belongs to
# the hand-verified anchors:
#
#   tests/test_v087_h2o_tddft.inp    B3LYP/STO-3G singlets + triplets
#   tests/test_v0871_heh_tddft_dip.inp   CIS + GMH vs a python reference
#   tests/test_v094_h2o_tddft_pcm.inp    LR-PCM reference values
#
# The reference numbers below were RECORDED from a v1.17.0 run
# (gfortran -O2, reference BLAS, 1 thread) and are regression
# tripwires only: they prove a mode did not change, not that it was
# ever right.  Re-record deliberately after an intentional change.
#
# Usage:  ./run_tddft_modes.sh [path_to_studdft] [nthreads]
#
# v1.17.1: case m18 added -- the unstable-reference branch, which no
# other case in this file reaches.
# =============================================================

EXE=${1:-./studdft}
NTHREADS=${2:-1}
export OMP_NUM_THREADS=$NTHREADS

TDIR="$(cd "$(dirname "$0")" && pwd)"
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

PASS=0; FAIL=0

# ---- helpers -------------------------------------------------

# First singlet (or first listed) excitation energy in eV.
# NOTE the state-machine guard: the molecule summary contains a
# "Shell details" table whose rows also start with an integer, so a
# bare pattern match picks up "s" from the shell column instead.
# v1.17.1: the leading minus signs are REQUIRED -- an unstable
# reference produces a negative E_exc, and that row is exactly the one
# case m18 exists to check.  A pattern that only matches positives
# would silently score m18 as 0.0 eV.
first_exc() {
    awk '/excited states:/ {f=1}
         f && /^ +1 +-?[0-9]+\.[0-9]+ +-?[0-9]/ {print $3; exit}' "$1"
}

# Run a case that MUST complete.  $3 = expected first excitation (eV),
# "-" to skip the numeric comparison.  Tolerance 1e-3 eV absorbs grid
# noise and last-digit BLAS differences.
expect_ok() {
    local tag="$1" inp="$2" ref="$3"
    local log="$WORK/$tag.log"
    if ! "$EXE" "$TDIR/$inp" > "$log" 2>&1; then
        echo "  FAIL  $tag -- run aborted (expected success)"
        grep -m2 -E "ERROR|error stop" "$log" | sed 's/^/          /'
        FAIL=$((FAIL+1)); return
    fi
    if ! grep -q "Excited States (Linear Response)" "$log"; then
        echo "  FAIL  $tag -- TDDFT section never started"
        FAIL=$((FAIL+1)); return
    fi
    local got; got=$(first_exc "$log")
    if [ -z "$got" ]; then
        echo "  FAIL  $tag -- no excitation table in output"
        FAIL=$((FAIL+1)); return
    fi
    if [ "$ref" = "-" ]; then
        echo "  PASS  $tag -- ran, E1 = $got eV (not pinned)"
        PASS=$((PASS+1)); return
    fi
    local ok
    ok=$(awk -v a="$got" -v b="$ref" 'BEGIN{print (((a-b)<0.001)&&((b-a)<0.001))?1:0}')
    if [ "$ok" = "1" ]; then
        echo "  PASS  $tag -- E1 = $got eV"
        PASS=$((PASS+1))
    else
        echo "  FAIL  $tag -- E1 = $got eV, expected $ref eV"
        FAIL=$((FAIL+1))
    fi
}

# Run a case that MUST stop, and must say why.  $3 = required substring.
expect_refusal() {
    local tag="$1" inp="$2" needle="$3"
    local log="$WORK/$tag.log"
    if "$EXE" "$TDIR/$inp" > "$log" 2>&1; then
        echo "  FAIL  $tag -- completed, but MUST refuse"
        FAIL=$((FAIL+1)); return
    fi
    if grep -q "$needle" "$log"; then
        echo "  PASS  $tag -- refused with the expected diagnostic"
        PASS=$((PASS+1))
    else
        echo "  FAIL  $tag -- refused, but not with '$needle'"
        grep -m3 -E "ERROR" "$log" | sed 's/^/          /'
        FAIL=$((FAIL+1))
    fi
}

# Presence check for an extra artefact or log line.
expect_line() {
    local tag="$1" logtag="$2" needle="$3"
    if grep -q "$needle" "$WORK/$logtag.log" 2>/dev/null; then
        echo "  PASS  $tag"
        PASS=$((PASS+1))
    else
        echo "  FAIL  $tag -- '$needle' not in the $logtag log"
        FAIL=$((FAIL+1))
    fi
}

# ---- the matrix ----------------------------------------------

echo "=============================================================="
echo " StudDFT TDDFT mode matrix   (exe=$EXE, OMP=$NTHREADS)"
echo "=============================================================="
echo
echo " Reference / solver branches:"
# Values marked [X] are ALSO produced by an independently validated
# anchor test, so they are cross-checked, not merely recorded:
#   m05/m06/m12 vs test_v087_h2o_tddft.inp   (hand-verified eV values)
#   m08/m09     vs test_v094_h2o_tddft_pcm.inp
#   m10         vs test_v0871_heh_tddft_dip.inp (python RHF+CIS)
# The rest are recorded tripwires only.
expect_ok m01_cis           test_v1170_tddft_m01_cis.inp            13.1835
expect_ok m02_tdhf          test_v1170_tddft_m02_tdhf.inp           13.1416
expect_ok m03_lda           test_v1170_tddft_m03_lda.inp            11.3849
expect_ok m04_gga           test_v1170_tddft_m04_gga.inp            11.3452
expect_ok m05_hybrid_tda    test_v1170_tddft_m05_hybrid_tda.inp     11.6974
expect_ok m06_hybrid_rpa    test_v1170_tddft_m06_hybrid_rpa_both.inp 11.6432
expect_ok m07_rs_hybrid     test_v1170_tddft_m07_rs_hybrid.inp      11.8431

# Physics invariant: RPA must lie below its TDA partner (the
# de-excitation block can only lower the eigenvalues).
#   m02 13.1416 < m01 13.1835      HF reference
#   m06 11.6432 < m05 11.6974      B3LYP reference

echo
echo " Environment:"
expect_ok m08_pcm_neq       test_v1170_tddft_m08_pcm_neq.inp        11.9308
expect_ok m09_pcm_eq        test_v1170_tddft_m09_pcm_eq.inp         11.9266
# Invariant: equilibrium solvation lowers the singlet further than
# nonequilibrium (11.9266 < 11.9308).  Equal values mean %tddft_pcm
# is being ignored.

echo
echo " Analysis and basis handling:"
expect_ok m10_dipmom        test_v1170_tddft_m10_dipmom_export.inp  28.9892
expect_line "m10 GMH block"      m10_dipmom "GMH"
expect_ok m11_spherical     test_v1170_tddft_m11_spherical.inp      11.6974
# Invariant: STO-3G has no d shells, so m11 must equal m05 exactly.
expect_ok m12_triplet_only  test_v1170_tddft_m12_triplet_only.inp    9.6846
# Invariant: T1 (9.6846) < S1 of m06 (11.6432).

echo
echo " Edge cases and sizing:"
expect_ok m13_nstates_clamp test_v1170_tddft_m13_nstates_clamp.inp  25.7681
expect_line "m13 clamp note"     m13_nstates_clamp "but only 1 exist"
expect_ok m14_maxdim_auto   test_v1170_tddft_m14_maxdim_auto.inp    11.6432
expect_line "m14 memory forecast" m14_maxdim_auto "peak working set"

echo
echo " Unstable reference (v1.17.1):"
expect_ok m18_unstable      test_v1171_tddft_m18_unstable_ref.inp   -3.5209
expect_line "m18 UNSTABLE marker"   m18_unstable "\\*\\*\\* UNSTABLE"
expect_line "m18 instability verdict" m18_unstable "NON-POSITIVE excitation energy"
expect_line "m18 GMH pairs skipped"   m18_unstable "pair(s) were SKIPPED"
# The negative value itself is the anchor: RHF/6-31G H2 at 2.5 A has
# a triplet instability of -0.129391 Ha = -3.5209 eV.  If this ever
# turns positive, either the reference changed or the sign is being
# swallowed again.

echo
echo " Refusals (a silent success here is the dangerous outcome):"
expect_refusal m15_mgga     test_v1170_tddft_m15_mgga_refuse.inp   "meta-GGA"
expect_refusal m16_uhf      test_v1170_tddft_m16_uhf_refuse.inp    "closed-shell"
expect_refusal m17_maxdim   test_v1170_tddft_m17_maxdim_cap.inp    "hard cap"

echo
echo "=============================================================="
echo " PASS: $PASS   FAIL: $FAIL"
echo "=============================================================="
[ "$FAIL" -eq 0 ] || exit 1
