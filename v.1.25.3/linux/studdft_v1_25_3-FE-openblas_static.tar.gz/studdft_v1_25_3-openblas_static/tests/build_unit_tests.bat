@echo off
rem ======================================================================
rem  StudDFT -- build the standalone unit-test drivers on Windows
rem  (v1.19.8).  Runs from a plain cmd: it locates the Intel Fortran
rem  environment itself if the compiler is not already on PATH.
rem
rem      tests\build_unit_tests.bat  [extra ifort/link flags]
rem
rem  WHAT THIS DOES AND WHY IT IS THE "QUICK" ROUTE
rem  ----------------------------------------------
rem  Each driver in tests\*.f90 is its own PROGRAM.  It USEs modules from
rem  src\, so it needs two products of the main build:
rem
rem      *.mod   the compiler's description of each module's interface,
rem              required to COMPILE the driver;
rem      *.obj   the machine code of those modules, required to LINK it.
rem
rem  Both already exist -- Visual Studio produced them when it built
rem  StudDFT.exe -- but they cannot be recovered from the .exe, so the
rem  driver has to link the same object files.  All of them except
rem  main.obj: that one holds `program studdft`, and a program can have
rem  only one entry point.
rem
rem  This script finds those directories, compiles each driver against
rem  them, and drops the result next to StudDFT.exe, where tests\runner.py
rem  looks for it.  Nothing in the solution changes.
rem
rem  The cost of that convenience: this file duplicates knowledge that
rem  properly belongs to the project settings (where objects live, which
rem  libraries to link).  Change the configuration and it must be changed
rem  too.  If the driver set grows -- and the capability audit says it
rem  should -- the durable answer is to split the solution: a static
rem  StudDFT.lib from every source but main.f90, then StudDFT.exe and each
rem  driver as thin projects on top of it.
rem
rem  NOT TESTED BY THE AUTHOR: there is no Windows toolchain in the
rem  development container.  The logic mirrors the Makefile rules, but
rem  the first run may need the flags below adjusted.
rem ======================================================================

setlocal enabledelayedexpansion

rem --- locate the repository root (this script lives in tests\) --------
rem  Remember the caller's directory BEFORE pushd: an argument like
rem  "x64\FullEdition\StudDFT.exe" is relative to wherever the user
rem  typed it, which is usually tests\ or the repository root, and %~f1
rem  resolves against the CURRENT directory.  Try both.
set "CALLDIR=%CD%"
set "ROOT=%~dp0.."
pushd "%ROOT%" || (echo Cannot enter "%ROOT%" & exit /b 1)
set "ROOT=%CD%"

echo.
echo === StudDFT unit-test drivers ===
echo Repository root : %ROOT%

rem --- make sure a Fortran compiler is on PATH -------------------------
rem  ifort lives under Program Files but is only on PATH inside an Intel
rem  environment.  Rather than demand a special prompt, find the setup
rem  script and run it here, so this works from a plain cmd.
rem
rem  Override either of these before calling if the guesses are wrong:
rem      set FC=ifx
rem      set INTEL_SETVARS=C:\Path\To\setvars.bat
set "FC=%FC%"
if "%FC%"=="" set "FC=ifort"

where %FC% >nul 2>&1
if not errorlevel 1 goto :have_compiler

echo Compiler "%FC%" not on PATH; looking for the Intel environment...

set "PF86=%ProgramFiles(x86)%"
set "SETVARS="
if not "%INTEL_SETVARS%"=="" if exist "%INTEL_SETVARS%" set "SETVARS=%INTEL_SETVARS%"
if not defined SETVARS if not "%ONEAPI_ROOT%"=="" if exist "%ONEAPI_ROOT%\setvars.bat" set "SETVARS=%ONEAPI_ROOT%\setvars.bat"
if not defined SETVARS if exist "%PF86%\Intel\oneAPI\setvars.bat" set "SETVARS=%PF86%\Intel\oneAPI\setvars.bat"
if not defined SETVARS if exist "%ProgramFiles%\Intel\oneAPI\setvars.bat"      set "SETVARS=%ProgramFiles%\Intel\oneAPI\setvars.bat"
if not defined SETVARS if exist "%PF86%\Intel\oneAPI\compiler\latest\env\vars.bat" set "SETVARS=%PF86%\Intel\oneAPI\compiler\latest\env\vars.bat"

rem  Parallel Studio / Composer XE: ifortvars.bat, needs an architecture
rem  argument, so it is handled separately below.
rem
rem  NOTE: %ProgramFiles(x86)% is copied to a plain name FIRST.  Used
rem  directly inside a parenthesised block, the ")" in the variable name
rem  closes the block and the script dies with a syntax error.
set "IFVARS="
if not defined SETVARS (
    for /f "delims=" %%V in ('dir /b /s "!PF86!\Intel\ifortvars.bat" 2^>nul') do (
        if not defined IFVARS set "IFVARS=%%V"
    )
)

if defined SETVARS (
    echo   using "%SETVARS%"
    call "%SETVARS%" intel64 >nul 2>&1
) else if defined IFVARS (
    echo   using "%IFVARS%"
    call "%IFVARS%" intel64 >nul 2>&1
)

where %FC% >nul 2>&1
if not errorlevel 1 goto :have_compiler

rem  oneAPI 2024+ ships ifx and no longer ifort.
if /i "%FC%"=="ifort" (
    where ifx >nul 2>&1
    if not errorlevel 1 (
        echo   ifort is gone in this toolchain; using ifx instead
        set "FC=ifx"
        goto :have_compiler
    )
)

echo.
echo ERROR: no Intel Fortran compiler found.
echo.
echo   Either open the Start-menu shortcut
echo     "Intel oneAPI command prompt for Intel 64 for Visual Studio 2019"
echo   and run this script from there, or point it at the setup script:
echo     set INTEL_SETVARS=C:\Program Files (x86)\Intel\oneAPI\setvars.bat
echo     tests\build_unit_tests.bat
echo.
echo   If your toolchain has ifx rather than ifort:  set FC=ifx
popd & exit /b 1

:have_compiler
set "FCPATH="
for /f "delims=" %%C in ('where %FC%') do (
    if not defined FCPATH set "FCPATH=%%C"
)
echo Compiler        : %FCPATH%


rem --- decide which build we are extending ------------------------------
rem  v1.19.10.  The previous version searched the tree for main.obj and
rem  StudDFT.exe and took the FIRST hit.  A working repository is full
rem  of old build outputs and stray copies, so on the reference machine
rem  it picked objects from a stale x64\Debug and dropped the drivers in
rem  a scratch folder named grid5 -- where the runner does not look.
rem  Everything "succeeded" and nothing worked.
rem
rem  So: derive from the executable you actually test with, and REFUSE
rem  to guess when the answer is ambiguous.  Silently choosing one of
rem  several candidates is how the previous version wasted a cycle.
rem
rem      tests\build_unit_tests.bat x64\FullEdition\StudDFT.exe [flags]
rem      set STUDDFT_OBJDIR=...   set STUDDFT_MODDIR=...

rem  Argument 1 is the executable when it ends in .exe; everything else
rem  is passed through to the compiler.  No SHIFT here: shift inside a
rem  parenthesised block does not do what it looks like it does.
set "EXEPATH="
set "ARGS=%*"
if /i "%~x1"==".exe" (
    set "EXEPATH=%~f1"
    set "ARGS=%2 %3 %4 %5 %6 %7 %8 %9"
)
rem  %~f1 resolved against the repository root.  If that is not where
rem  the file is, try the directory the user was standing in.
if defined EXEPATH if not exist "%EXEPATH%" (
    if exist "%CALLDIR%\%~1" set "EXEPATH=%CALLDIR%\%~1"
)
if not defined EXEPATH if not "%STUDDFT_EXE%"=="" set "EXEPATH=%STUDDFT_EXE%"

if not defined EXEPATH (
    rem  A repository this old holds dozens of stray copies -- the
    rem  reference machine has about sixty.  Printing them all buries
    rem  the message, so count everything, show a few, and single out
    rem  the ones under a platform directory, which are the real build
    rem  outputs.  Still a SUGGESTION: the script does not choose.
    set /a NEXE=0
    for /f "delims=" %%F in ('dir /b /s "%ROOT%\StudDFT.exe" 2^>nul') do (
        set /a NEXE+=1
        set "EXEPATH=%%~fF"
        if !NEXE! leq 8 echo   candidate: %%~fF
    )
    if !NEXE! gtr 8 echo   ... and !NEXE! in total
    if !NEXE! gtr 1 (
        echo.
        echo ERROR: !NEXE! copies of StudDFT.exe under the repository.
        echo        I will not guess which build you mean -- guessing is
        echo        what linked the drivers against a stale x64\Debug
        echo        last time.
        echo.
        echo        Most of those are scratch copies. The real build
        echo        outputs live under the platform directory; run one of
        echo        these from the repository root:
        echo.
        set "NPLAT=0"
        for /f "delims=" %%P in ('dir /b /s "%ROOT%\x64\StudDFT.exe" 2^>nul') do (
            set /a NPLAT+=1
            echo            tests\build_unit_tests.bat "%%~fP"
        )
        if "!NPLAT!"=="0" echo            tests\build_unit_tests.bat path\to\StudDFT.exe
        popd
        exit /b 1
    )
    if !NEXE! equ 0 (
        echo.
        echo ERROR: no StudDFT.exe under %ROOT%. Build the project first.
        popd
        exit /b 1
    )
)
if not exist "%EXEPATH%" (
    echo ERROR: "%EXEPATH%" does not exist.
    popd & exit /b 1
)
for %%F in ("%EXEPATH%") do set "OUTDIR=%%~dpF"
set "OUTDIR=%OUTDIR:~0,-1%"
echo Executable      : %EXEPATH%
echo Output directory: %OUTDIR%

rem --- object directory --------------------------------------------------
rem  Prefer the one belonging to this executable: Visual Studio usually
rem  puts intermediates beside the output, and when it does not, the
rem  configuration directory is still the right place to look first.
set "OBJDIR="
if not "%STUDDFT_OBJDIR%"=="" set "OBJDIR=%STUDDFT_OBJDIR%"
if not defined OBJDIR if exist "%OUTDIR%\main.obj" set "OBJDIR=%OUTDIR%"

if not defined OBJDIR (
    set /a NOBJ=0
    for /f "delims=" %%F in ('dir /b /s "%ROOT%\main.obj" 2^>nul') do (
        set /a NOBJ+=1
        set "OBJDIR=%%~dpF"
        echo   candidate objects: %%~dpF
    )
    if !NOBJ! gtr 1 (
        echo.
        echo ERROR: main.obj exists in several places and none of them is
        echo        the executable's own directory, so I cannot tell which
        echo        build these objects belong to. Linking the wrong ones
        echo        produces drivers that test a different program.
        echo        Choose one:
        echo            set STUDDFT_OBJDIR=D:\...\x64\FullEdition
        popd
        exit /b 1
    )
    if !NOBJ! equ 0 (
        echo.
        echo ERROR: main.obj not found under %ROOT%. Build the project
        echo        first; this script links the objects that build makes.
        popd
        exit /b 1
    )
    if defined OBJDIR set "OBJDIR=!OBJDIR:~0,-1!"
)
echo Object directory: %OBJDIR%

rem --- module directory --------------------------------------------------
set "MODDIR="
if not "%STUDDFT_MODDIR%"=="" set "MODDIR=%STUDDFT_MODDIR%"
if not defined MODDIR if exist "%OBJDIR%\constants.mod" set "MODDIR=%OBJDIR%"
if not defined MODDIR if exist "%OUTDIR%\constants.mod" set "MODDIR=%OUTDIR%"
if not defined MODDIR (
    echo.
    echo ERROR: constants.mod is neither in the object directory nor
    echo        beside the executable.  Check Fortran -^> Output Files
    echo        -^> Module Path, or set STUDDFT_MODDIR.
    popd & exit /b 1
)
echo Module directory: %MODDIR%

rem  A mismatch here is the failure this version exists to prevent.
for %%A in ("%OBJDIR%") do set "OBJTAG=%%~nxA"
for %%B in ("%OUTDIR%") do set "OUTTAG=%%~nxB"
if /i not "%OBJTAG%"=="%OUTTAG%" (
    echo.
    echo NOTE: objects come from "%OBJTAG%" but the executable lives in
    echo       "%OUTTAG%".  That is normal if the project separates
    echo       intermediate and output directories, and WRONG if you are
    echo       linking a different configuration than you test.  Check it.
    echo.
)

rem --- collect every object except main.obj ----------------------------
set "OBJS="
for %%O in ("%OBJDIR%\*.obj") do (
    if /i not "%%~nxO"=="main.obj" set "OBJS=!OBJS! "%%~fO""
)
if not defined OBJS (
    echo ERROR: no object files in %OBJDIR%.
    popd & exit /b 1
)

rem --- match the C runtime of the existing objects ----------------------
rem  LNK4098 ("defaultlib LIBCMTD conflicts with use of other libs")
rem  means the objects and the driver disagree about which C runtime to
rem  link.  Visual Studio records the choice as a linker directive
rem  inside every .obj, and the four possibilities are distinguishable
rem  by name:
rem
rem      LIBCMTD   static, debug      -> /libs:static /dbglibs
rem      LIBCMT    static, release    -> /libs:static          (default)
rem      MSVCRTD   dll,    debug      -> /libs:dll    /dbglibs
rem      MSVCRT    dll,    release    -> /libs:dll
rem
rem  The directive is a plain string in the object file, so findstr can
rem  read it without dumpbin and without the VS environment.  Order
rem  matters: LIBCMT is a prefix of LIBCMTD, so test the longer name
rem  first.
rem
rem  Getting this wrong is not cosmetic.  Two C runtimes in one image
rem  means two heaps, and memory allocated by one and released by the
rem  other crashes.  These drivers allocate.
set "CRT="
findstr /m /c:"LIBCMTD" "%OBJDIR%\main.obj" >nul 2>&1
if not errorlevel 1 (
    set "CRT=/libs:static /dbglibs"
    echo C runtime       : static debug ^(LIBCMTD^)
)
if not defined CRT (
    findstr /m /c:"MSVCRTD" "%OBJDIR%\main.obj" >nul 2>&1
    if not errorlevel 1 (
        set "CRT=/libs:dll /dbglibs"
        echo C runtime       : dll debug ^(MSVCRTD^)
    )
)
if not defined CRT (
    findstr /m /c:"MSVCRT" "%OBJDIR%\main.obj" >nul 2>&1
    if not errorlevel 1 (
        set "CRT=/libs:dll"
        echo C runtime       : dll release ^(MSVCRT^)
    )
)
if not defined CRT (
    set "CRT=/libs:static"
    echo C runtime       : static release ^(default^)
)

rem --- flags ------------------------------------------------------------
rem  /Qmkl:sequential covers the BLAS/LAPACK the drivers reach through
rem  the StudDFT modules.  If the project links a different BLAS, pass
rem  the right flag as an argument instead:
rem      tests\build_unit_tests.bat /Qmkl:parallel
rem      tests\build_unit_tests.bat mylapack.lib myblas.lib
rem  v1.19.12: trim ARGS before testing it.  When the executable is
rem  given as argument 1, ARGS becomes "%2 %3 ... %9", which with no
rem  further arguments is a string of spaces -- not empty -- so the
rem  default below never applied and "Extra flags :" printed blank.
for /f "tokens=*" %%A in ("%ARGS%") do set "ARGS=%%A"
set "EXTRA=%ARGS%"
if "%EXTRA%"=="" set "EXTRA=/Qmkl:sequential"
echo Extra flags     : %EXTRA%

rem  Scratch for the driver's own .obj, so the build tree stays clean.
set "SCRATCH=%ROOT%\tests\.build"
if not exist "%SCRATCH%" mkdir "%SCRATCH%"

rem --- the seven drivers ------------------------------------------------
set DRIVERS=test_boys test_d3_grad test_tddft_memory test_hessian_io test_internal_hess_tools test_bofill_update test_prfo_step perf_standard

set /a NOK=0
set /a NFAIL=0
echo.
for %%D in (%DRIVERS%) do (
    <nul set /p "=  %%D ... "
    %FC% /nologo /warn:none !CRT! /I"%MODDIR%" /module:"%SCRATCH%" ^
          /object:"%SCRATCH%\\" ^
          "%ROOT%\tests\%%D.f90" !OBJS! %EXTRA% ^
          /exe:"%OUTDIR%\%%D.exe" > "%SCRATCH%\%%D.buildlog" 2>&1
    if errorlevel 1 (
        echo FAILED  -- see tests\.build\%%D.buildlog
        set /a NFAIL+=1
    ) else (
        echo ok
        set /a NOK+=1
    )
)

echo.
echo built !NOK!, failed !NFAIL!
if !NFAIL! gtr 0 (
    echo.
    echo The most common cause is the BLAS/LAPACK flag. Open one of the
    echo build logs in tests\.build\ and look for unresolved externals
    echo named dgemm, dsyev, dgesv and the like; if they are there, pass
    echo the linkage your project uses as an argument to this script.
    echo.
    echo If instead you see LNK4098 about conflicting default libraries,
    echo the C runtime detected above does not match the project; pass
    echo the right pair explicitly, for example:
    echo     tests\build_unit_tests.bat /libs:static /dbglibs /Qmkl:sequential
    popd & exit /b 1
)

echo.
echo Now run them:
echo   python tests\runner.py --exe "%OUTDIR%\StudDFT.exe" --tags unit
popd
endlocal
