#!/usr/bin/env python3
# =====================================================================
# StudDFT test runner (v1.18.0)
#
# One runner, one manifest format, four classes of assertion.  Replaces
# the per-version shell scripts (run_v069.sh ... run_v076.sh), which
# could not run on the Windows machine where StudDFT is developed and
# which each reimplemented their own float comparison on top of `bc`.
#
# WHY FOUR CLASSES.  Three consecutive real defects passed a suite that
# checked only numbers:
#
#   v1.17.0  an 8x ERI slowdown (/heap-arrays0).  Every energy stayed
#            bit-identical.  Needs a PERFORMANCE assertion.
#   v1.17.1  non-positive TDDFT states printed as orphaned amplitudes
#            with no row.  The numbers were fine; the OUTPUT lied.
#            Needs a BEHAVIOURAL assertion.
#   v1.17.2  triplet energies not bit-reproducible across thread
#            counts.  Needs a REPRODUCIBILITY assertion.
#
# So: value/contains/absent/exit (numerical + behavioural),
# throughput (performance), stable (reproducibility), matches
# (cross-check between two runs, e.g. analytic vs finite difference).
#
# PROVENANCE IS MANDATORY.  Every numerical assertion carries src=,
# one of hand|literature|external|internal|recorded.  A `recorded`
# value proves only that a result did not CHANGE; it can never prove
# it was right.  The summary prints the ratio, because a suite that is
# mostly tripwires gives false confidence -- which is exactly how the
# three defects above survived.
#
# Usage:
#   python3 tests/runner.py                       # everything
#   python3 tests/runner.py --tags smoke          # one tier
#   python3 tests/runner.py --id tddft_m06        # one test
#   python3 tests/runner.py --exe ./studdft --jobs 4
#   python3 tests/runner.py --list                # no runs, just names
#
# Exit status is 0 only if every selected test passed.
# =====================================================================

import argparse
import json
import os
import re
import shutil
import subprocess
import textwrap
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

PROVENANCE = ("hand", "literature", "external", "internal", "recorded")


# ---------------------------------------------------------------------
# Manifest parsing
# ---------------------------------------------------------------------

class Assertion:
    """One check applied to the captured output of a test."""

    def __init__(self, kind, args, raw, lineno, source):
        self.kind = kind
        self.args = args
        self.raw = raw
        self.lineno = lineno
        self.source = source
        self.src = args.get("src")

    def __repr__(self):
        return "%s(%s)" % (self.kind, self.raw)


class Test:
    def __init__(self, kind, origin, lineno):
        self.kind = kind            # 'test' (input file) or 'program'
        self.origin = origin        # manifest file
        self.lineno = lineno
        self.id = None
        self.input = None
        self.build = None           # for kind == 'program'
        self.tags = []
        self.timeout = 300
        self.threads = None         # override OMP_NUM_THREADS
        self.repeat = 1             # >1 for `stable`
        self.needs = None           # v1.19.0: producer test id
        self.expect = "pass"        # v1.20.2: "fail" marks a known defect
        self.note = None            # v1.21.0: footnote, marks the line with *
        self.asserts = []
        self.note = None

    def __repr__(self):
        return "Test(%s)" % self.id


def _split_kv(text):
    """Parse `a=b c=d "e f"` into a dict, honouring double quotes."""
    out = {}
    for m in re.finditer(r'(\w+)=("([^"]*)"|\S+)', text):
        key = m.group(1)
        out[key] = m.group(3) if m.group(3) is not None else m.group(2)
    return out


def parse_manifest(path):
    tests = []
    cur = None
    with open(path, encoding="utf-8") as fh:
        for lineno, raw in enumerate(fh, 1):
            line = raw.split("#", 1)[0].strip() if not raw.lstrip().startswith("#") else ""
            if not line:
                continue
            m = re.match(r"^\[(test|program)\]$", line)
            if m:
                cur = Test(m.group(1), path, lineno)
                tests.append(cur)
                continue
            if cur is None:
                raise SyntaxError("%s:%d: content before any [test] header"
                                  % (path, lineno))
            if "=" not in line:
                raise SyntaxError("%s:%d: expected key = value" % (path, lineno))
            key, val = line.split("=", 1)
            key = key.strip().lower()
            val = val.strip()
            if key == "assert":
                parts = val.split(None, 1)
                kind = parts[0]
                rest = parts[1] if len(parts) > 1 else ""
                tests[-1].asserts.append(
                    Assertion(kind, _split_kv(rest), val, lineno, path))
                # keep the positional remainder for regex-style asserts
                tests[-1].asserts[-1].positional = rest
            elif key == "tags":
                cur.tags = [t.strip() for t in val.split(",") if t.strip()]
            elif key == "timeout":
                cur.timeout = int(val)
            elif key == "threads":
                cur.threads = int(val)
            elif key == "repeat":
                cur.repeat = int(val)
            elif hasattr(cur, key):
                setattr(cur, key, val)
            else:
                raise SyntaxError("%s:%d: unknown key '%s'" % (path, lineno, key))
    return tests


def load_all_manifests(mdir):
    tests = []
    for p in sorted(Path(mdir).glob("*.mf")):
        tests.extend(parse_manifest(p))
    seen = {}
    for t in tests:
        if t.id is None:
            raise SyntaxError("%s:%d: [%s] block has no id"
                              % (t.origin, t.lineno, t.kind))
        if t.id in seen:
            raise SyntaxError("duplicate test id '%s' (%s:%d and %s:%d)"
                              % (t.id, seen[t.id].origin, seen[t.id].lineno,
                                 t.origin, t.lineno))
        seen[t.id] = t
    return tests


# ---------------------------------------------------------------------
# Assertion evaluation
# ---------------------------------------------------------------------

def _strip_kv(text):
    """Remove trailing key=value pairs, leaving the positional regex."""
    return re.sub(r'\s+\w+=("[^"]*"|\S+)', "", text).strip()


def _find_field(lines, pattern, field, after=None, occurrence=1):
    """Return the `field`-th whitespace token of the `occurrence`-th line
    matching `pattern`, searching only after a line matching `after`.

    v1.19.2: occurrence may be the string 'last'.  A multi-stage job
    prints the same label many times -- a ts+freq run reports
    "Total energy:" at every optimizer step and again after the final
    frequency pass, and prints two whole "Mode 1:" blocks -- so the
    FIRST match is almost never the one a test means.  Pinning the
    first match against a value read off the end of the log is an easy
    and silent way to write an assertion that can never pass; it is
    how the fill_b3lyp_tsfreq entry was first written.
    """
    rx = re.compile(pattern)
    armed = after is None
    arx = re.compile(after) if after else None
    want_last = (str(occurrence).lower() == 'last')
    hits = 0
    found = None
    for ln in lines:
        if not armed:
            if arx.search(ln):
                armed = True
            continue
        if rx.search(ln):
            hits += 1
            toks = ln.split()
            if field <= 0 or field > len(toks):
                return None, "field %d out of range in: %s" % (field, ln.strip())
            if want_last:
                found = toks[field - 1]
            elif hits == occurrence:
                return toks[field - 1], None
    if want_last and found is not None:
        return found, None
    return None, "no line matching /%s/%s" % (
        pattern, (" after /%s/" % after) if after else "")


def _as_float(tok):
    try:
        return float(tok.replace("D", "E").replace("d", "e"))
    except (ValueError, AttributeError):
        return None


def evaluate(a, run, runs_by_id):
    """Return (ok, detail). `run` is the primary RunResult."""
    text = run.output
    lines = text.split("\n")
    pos = _strip_kv(a.positional)
    pos = pos[1:-1] if len(pos) > 1 and pos[0] == '"' and pos[-1] == '"' else pos

    if a.kind == "exit":
        want = pos.strip()
        if want == "zero":
            return run.rc == 0, "exit status %s" % run.rc
        if want == "nonzero":
            return run.rc != 0, "exit status %s" % run.rc
        return False, "exit expects zero|nonzero, got '%s'" % want

    if a.kind == "contains":
        return (re.search(pos, text) is not None), "/%s/" % pos

    if a.kind == "geometry":
        # ------------------------------------------------------------
        # v1.22.0: compare a GEOMETRY, not a number.
        #
        # StudDFT prints Cartesian coordinates in its own orientation
        # and the reference programs store an interatomic distance
        # matrix, so the two cannot be compared directly -- a
        # translation or rotation changes every coordinate and no
        # bond length.  This assertion reads the Cartesian block,
        # computes every pairwise distance, sorts them, and compares
        # against a sorted reference.
        #
        # Sorting removes the last dependence on atom ORDER as well
        # as on orientation, which matters because the two programs
        # need not list the atoms the same way.  What survives is
        # the shape of the molecule, which is the thing being tested.
        # ------------------------------------------------------------
        ref = a.args.get("ref")
        tol = _as_float(a.args.get("tol"))
        if ref is None or tol is None:
            return False, "geometry needs ref= and tol="
        want = sorted(float(x) for x in ref.split(","))
        armed = a.args.get("after") is None
        arx = re.compile(a.args["after"]) if a.args.get("after") else None
        coords, started = [], False
        for ln in lines:
            if not armed:
                if arx.search(ln):
                    armed = True
                continue
            m = re.match(r"\s*[A-Z][a-z]?\d*\s+(-?\d+\.\d+)\s+"
                         r"(-?\d+\.\d+)\s+(-?\d+\.\d+)\s*$", ln)
            if m:
                started = True
                coords.append(tuple(float(m.group(i)) for i in (1, 2, 3)))
            elif started and ln.strip() and not ln.strip().startswith("-"):
                break
        if len(coords) < 2:
            return False, "no Cartesian block found after the anchor"
        got = []
        for i in range(len(coords)):
            for j in range(i + 1, len(coords)):
                got.append(sum((coords[i][k] - coords[j][k]) ** 2
                               for k in range(3)) ** 0.5)
        got.sort()
        if len(got) != len(want):
            return False, ("%d distances in the output, %d in the "
                           "reference" % (len(got), len(want)))
        dev = [abs(g - w) for g, w in zip(got, want)]
        worst = max(dev)
        run.observed[a.raw] = worst
        return worst <= tol, ("%d distances, max |d| = %.2e A, mean "
                              "%.2e (tol %.2e)"
                              % (len(got), worst,
                                 sum(dev) / len(dev), tol))

    if a.kind == "absent":
        m = re.search(pos, text)
        if m:
            return False, "found /%s/ at: %s" % (pos, m.group(0)[:60])
        return True, "/%s/ absent" % pos

    if a.kind in ("value", "throughput"):
        field = int(a.args.get("field", 1))
        occ = a.args.get("occurrence", 1)
        if str(occ).lower() != "last":
            occ = int(occ)
        tok, err = _find_field(lines, pos, field, a.args.get("after"), occ)
        if err:
            return False, err
        got = _as_float(tok)
        if got is None:
            return False, "field %d is not numeric: '%s'" % (field, tok)
        run.observed[a.raw] = got

        if a.kind == "throughput":
            lo = _as_float(a.args.get("min"))
            if lo is None:
                return False, "throughput needs min="
            # v1.19.5: per_thread_field normalises the rate by the
            # thread count printed on the same line.  A flat floor is
            # tied to one machine's core count -- raise the thread
            # count and a broken build sails over it, lower it and a
            # healthy build trips.  Per-thread throughput is the
            # quantity that actually distinguishes a correct build
            # from one whose ERI workspaces are on the heap.
            ptf = a.args.get("per_thread_field")
            if ptf is not None:
                ntok, err2 = _find_field(lines, pos, int(ptf),
                                         a.args.get("after"), occ)
                if err2:
                    return False, "thread-count field: " + err2
                nthr = _as_float(ntok)
                if not nthr or nthr <= 0:
                    return False, "thread count is not a positive number: %r" % ntok
                per = got / nthr
                run.observed[a.raw + " [per thread]"] = per
                return per >= lo, ("%.6g total on %g thread(s) = %.6g each "
                                   "(floor %.6g)" % (got, nthr, per, lo))
            return got >= lo, "%.6g (floor %.6g)" % (got, lo)

        exp = _as_float(a.args.get("eq"))
        if exp is None:
            return False, "value needs eq="
        tol = _as_float(a.args.get("tol")) or 0.0
        d = abs(got - exp)
        return d <= tol, "%.10g vs %.10g (|d|=%.3g, tol=%.3g)" % (got, exp, d, tol)

    if a.kind == "ratio":
        # v1.25.0: numerator/denominator from two lines of the SAME log,
        # compared with a RELATIVE tolerance.  The machine divides out
        # only when the two quantities stress the same code class --
        # own-compiled Fortran against std_flow, LAPACK stages against
        # std_eig/std_gemm.  See 32_perf_standard.mf for the philosophy
        # and the honest limits.
        field = int(a.args.get("field", 1))
        den_rx = a.args.get("over")
        if den_rx is None:
            return False, 'ratio needs over="regex"'
        dfield = int(a.args.get("den_field", 1))
        ntok, err = _find_field(lines, pos, field, a.args.get("after"), 1)
        if err:
            return False, "numerator: " + err
        den_lines = lines
        den_test = a.args.get("den_test")
        if den_test is not None:
            if den_test not in runs_by_id:
                return False, "den_test '%s' has not run" % den_test
            den_run = runs_by_id[den_test]
            if getattr(den_run, "skipped", None) or not den_run.output.strip():
                return False, ("den_test '%s' produced no output (%s)"
                               % (den_test,
                                  den_run.skipped or "empty log"))
            den_lines = den_run.output.split("\n")
        dtok, err = _find_field(den_lines, den_rx, dfield,
                                a.args.get("den_after"), 1)
        if err:
            return False, "denominator: " + err
        num = _as_float(ntok)
        den = _as_float(dtok)
        if num is None or den is None:
            return False, "non-numeric ratio operand: %r / %r" % (ntok, dtok)
        if den <= 0.0:
            return False, "denominator not positive: %g" % den
        got = num / den
        run.observed[a.raw] = got
        exp = _as_float(a.args.get("eq"))
        rtol = _as_float(a.args.get("rtol"))
        vmin = _as_float(a.args.get("min"))
        vmax = _as_float(a.args.get("max"))
        if exp is not None and rtol is not None:
            ok = abs(got - exp) <= rtol * exp
            return ok, "%.4g / %.4g = %.4g vs %.4g (rtol %.0f%%)" % (
                num, den, got, exp, 100.0 * rtol)
        # v1.25.3: CORRIDOR form -- asymmetric one-sided bounds for
        # ratios whose two failure directions have different owners
        # and different cross-toolchain spreads (see
        # 32_perf_standard.mf).  Either bound may be given alone.
        if vmin is not None or vmax is not None:
            ok = True
            if vmin is not None and got < vmin:
                ok = False
            if vmax is not None and got > vmax:
                ok = False
            lo = "%g" % vmin if vmin is not None else "-inf"
            hi = "%g" % vmax if vmax is not None else "+inf"
            return ok, "%.4g / %.4g = %.4g vs corridor [%s .. %s]" % (
                num, den, got, lo, hi)
        return False, "ratio needs eq=+rtol= or min=/max= bounds"

    if a.kind == "stable":
        field = int(a.args.get("field", 1))
        tol = _as_float(a.args.get("tol")) or 0.0
        vals = []
        for r in run.repeats:
            tok, err = _find_field(r.split("\n"), pos, field, a.args.get("after"))
            if err:
                return False, err
            v = _as_float(tok)
            if v is None:
                return False, "non-numeric field in a repeat"
            vals.append(v)
        if len(vals) < 2:
            return False, "stable needs repeat >= 2"
        spread = max(vals) - min(vals)
        return spread <= tol, "spread %.3g over %d runs (tol %.3g)" % (
            spread, len(vals), tol)

    if a.kind == "matches":
        other = a.args.get("test")
        if other not in runs_by_id:
            return False, "no run for test '%s' (order it earlier, same tier)" % other
        field = int(a.args.get("field", 1))
        tol = _as_float(a.args.get("tol")) or 0.0
        t1, e1 = _find_field(lines, pos, field, a.args.get("after"))
        t2, e2 = _find_field(runs_by_id[other].output.split("\n"), pos, field,
                             a.args.get("after"))
        if e1:
            return False, "this run: " + e1
        if e2:
            return False, "%s: %s" % (other, e2)
        v1, v2 = _as_float(t1), _as_float(t2)
        if v1 is None or v2 is None:
            return False, "non-numeric field"
        return abs(v1 - v2) <= tol, "%.10g vs %s %.10g (|d|=%.3g)" % (
            v1, other, v2, abs(v1 - v2))

    return False, "unknown assertion kind '%s'" % a.kind


# ---------------------------------------------------------------------
# Execution
# ---------------------------------------------------------------------

class RunResult:
    def __init__(self):
        self.rc = None
        self.output = ""
        self.repeats = []
        self.wall = 0.0
        self.observed = {}
        self.skipped = None


def run_one(test, exe, workdir, default_threads):
    # v1.19.0, `needs`: some jobs consume a file another job WRITES.
    # %job irc requires the .hess produced by a preceding ts+freq run;
    # a checkpoint restart requires the .chk of the run it restarts.
    # Per-test working directories -- correct for isolation -- break
    # exactly those chains, so a test declaring `needs = <id>` runs in
    # its producer's directory instead of its own.  The runner also
    # orders the pair and skips the consumer if the producer failed,
    # because a consumer failing for want of an input its producer
    # never wrote is a misleading second failure, not a second defect.
    # NOTE ON THE WORKING DIRECTORY.
    #
    # StudDFT resolves data files as
    #     $STUDDFT/basis_data/<name>   if STUDDFT is set
    #     basis_data/<name>            otherwise, relative to the CWD
    # (molecule_builder.f90 basis and ECP lookup, driver_setup.f90,
    # driver_jobs.f90:2193).  The relative form is the FALLBACK, not
    # the rule.
    #
    # So the runner exports STUDDFT and gives every test its own
    # working directory.  That matters for more than tidiness: the
    # program writes .chk, .molden and *_states.txt next to the CWD,
    # and running everything from the project root makes those
    # artefacts collide between tests -- which in turn is what made
    # --jobs > 1 unsafe.  With per-test directories the artefacts are
    # isolated and concurrency is sound.
    #
    # An earlier revision ran from the project root instead, after
    # misreading `Cannot load basis for Z= 8 from basis_data/sto-3g.dat`
    # as proof that only the CWD was consulted.  It was proof only
    # that STUDDFT was unset.
    res = RunResult()
    env = dict(os.environ)
    # v1.19.1: RESPECT an existing STUDDFT.  It names the directory
    # that CONTAINS basis_data, and that need not be the repository
    # root -- a user with a shared data tree would otherwise see every
    # test fail with a basis-not-found error that looks like a program
    # bug.  Supply the fallback only when the variable is unset.
    env.setdefault("STUDDFT", str(ROOT))
    nt = test.threads if test.threads is not None else default_threads
    if nt:
        env["OMP_NUM_THREADS"] = str(nt)

    if test.kind == "program":
        # Standalone drivers run at the project root.  They have no
        # artefacts to isolate, and at least one of them
        # (tests/test_d3_grad.f90) hardcodes 'basis_data/...' relative
        # to the CWD instead of consulting $STUDDFT the way the rest
        # of the program does.  That inconsistency is worth fixing in
        # the driver -- it is listed as an open item -- but it should
        # not hold up the suite, and the exemption is harmless here.
        # v1.20.3: [program] entries run in their OWN directory now.
        # They were exempted because tests/test_d3_grad.f90
        # hardcoded a relative basis_data path; that is fixed, and
        # the exemption cost more than it saved -- test_hessian_io
        # wrote its test_hio_*.hess into the repository ROOT on
        # every run, where they accumulated.
        # v1.19.1: look for the driver next to the main executable as
        # well as in the project root.  A Makefile build leaves both in
        # the root; a Visual Studio build puts everything in
        # x64\Release (or wherever the configuration points), and
        # --exe already tells us where that is.
        stem = test.build + (".exe" if os.name == "nt" else "")
        candidates = [ROOT / stem, Path(exe).resolve().parent / stem]
        target = next((c for c in candidates if c.exists()), None)
        if target is None:
            how = ("build the %s project in this solution"
                   if os.name == "nt" else "run `make %s`")
            res.skipped = "not built: " + (how % test.build)
            return res
        cmd = [str(target)]
    else:
        inp = ROOT / test.input
        if not inp.exists():
            res.skipped = "missing input %s" % test.input
            return res
        # v1.19.2: COPY the input into the working directory and invoke
        # it by bare name.
        #
        # StudDFT derives every artefact name from the input path --
        # <input>.chk, <input>_mo.molden, <input>_tddft_states.txt and
        # so on -- so passing an ABSOLUTE path wrote them all next to
        # the input, in tests/, no matter what the working directory
        # was.  v1.18.1 introduced per-test directories precisely to
        # isolate those artefacts and did not achieve it: the
        # directories came out empty and a suite run left 21 stray .chk
        # files in tests/.  Copying the input in is what actually makes
        # the isolation real, and it costs a few kilobytes.
        local = workdir / inp.name
        try:
            if not local.exists() or local.read_bytes() != inp.read_bytes():
                shutil.copyfile(str(inp), str(local))
        except OSError as e:
            res.skipped = "cannot stage input: %s" % e
            return res
        cmd = [str(exe), inp.name]

    t0 = time.time()
    for _ in range(max(1, test.repeat)):
        try:
            p = subprocess.run(cmd, cwd=str(workdir), env=env,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT,
                               timeout=test.timeout)
            out = p.stdout.decode("utf-8", errors="replace")
            rc = p.returncode
        except subprocess.TimeoutExpired:
            out = "*** RUNNER: timeout after %d s\n" % test.timeout
            rc = -9
        res.repeats.append(out)
        res.rc = rc
        res.output = out
        if rc != 0 and test.repeat > 1:
            break
    res.wall = time.time() - t0
    return res


def select(tests, tags, ids):
    out = tests
    if tags:
        want = set(tags)
        out = [t for t in out if want & set(t.tags)]
    if ids:
        pats = [re.compile(i) for i in ids]
        out = [t for t in out if any(p.search(t.id) for p in pats)]
    return out


def main():
    ap = argparse.ArgumentParser(description="StudDFT test runner")
    ap.add_argument("--exe", default=None,
                    help="StudDFT executable (default: ./studdft next to the Makefile)")
    ap.add_argument("--manifest-dir", default=str(HERE / "manifest"))
    ap.add_argument("--tags", default="", help="comma-separated tier/feature tags")
    ap.add_argument("--id", action="append", default=[],
                    help="regex on test id; repeatable")
    ap.add_argument("--threads", type=int, default=1,
                    help="OMP_NUM_THREADS for tests that do not set it (default 1)")
    ap.add_argument("--jobs", type=int, default=1,
                    help="tests to run concurrently (each still uses --threads)")
    ap.add_argument("--work", default=None, help="scratch directory")
    ap.add_argument("--keep-logs", action="store_true",
                    help="keep logs of passing tests too")
    ap.add_argument("--run-xfail", action="store_true",
                    help="also run the tests marked `expect = fail`, which "
                         "document known defects and are skipped by default")
    ap.add_argument("--report", action="store_true",
                    help="print the observed value and deviation for every "
                         "numerical assertion, passing ones included")
    ap.add_argument("--json", default=None, help="write a machine-readable summary")
    ap.add_argument("--list", action="store_true", help="list selected tests and exit")
    args = ap.parse_args()

    exe = Path(args.exe) if args.exe else ROOT / "studdft"
    if os.name == "nt" and not exe.suffix:
        exe = exe.with_suffix(".exe")

    tests = load_all_manifests(args.manifest_dir)
    tags = [t.strip() for t in args.tags.split(",") if t.strip()]
    sel = select(tests, tags, args.id)

    # ------------------------------------------------------------------
    # v1.20.5: `expect = fail` tests are NOT RUN by default.
    #
    # v1.20.3 only suppressed their output, which was the wrong reading
    # of "screen it off": the test still ran, still consumed its share
    # of the wall clock, still appeared in the total and still put an
    # XFAIL line in the summary.  A known defect that has been decided
    # against acting on should cost nothing at all -- neither time nor
    # attention.
    #
    # The manifest entry stays, with its explanation, which is the point
    # of not deleting it.  --run-xfail brings them back when someone
    # wants to check whether a defect is still there.
    # ------------------------------------------------------------------
    held = [t for t in sel if t.expect == "fail"]
    if held and not args.run_xfail:
        sel = [t for t in sel if t.expect != "fail"]

    if args.list:
        for t in sel:
            print("%-40s %s" % (t.id, ",".join(t.tags)))
        print("\n%d test(s) selected of %d" % (len(sel), len(tests)))
        return 0

    if not sel:
        print("no tests selected")
        return 1
    if not exe.exists():
        print("executable not found: %s   (run `make` first)" % exe)
        return 2

    work = Path(args.work) if args.work else ROOT / "test_work"
    if work.exists():
        shutil.rmtree(str(work))
    work.mkdir(parents=True)

    print("=" * 70)
    print(" StudDFT test suite")
    print("   exe      : %s" % exe)
    print("   selected : %d test(s)%s" % (len(sel), (" [tags: %s]" % ",".join(tags)) if tags else ""))
    if held and not args.run_xfail:
        print("   held back: %d marked `expect = fail` (known defect);"
              " --run-xfail to include" % len(held))
    print("   threads  : %d" % args.threads)
    print("   STUDDFT  : %s%s"
          % (os.environ.get("STUDDFT", str(ROOT)),
             "" if os.environ.get("STUDDFT")
             else "   (not set; falling back to the repository root)"))
    print("=" * 70)

    runs_by_id = {}
    results = []
    npass = nfail = nskip = nxfail = nxpass = 0
    twall = 0.0
    idx = 0
    prov = {k: 0 for k in PROVENANCE}
    prov["unspecified"] = 0

    produced = {}

    results_so_far = {}

    def log_path(t):
        # v1.19.4: the captured stdout goes INSIDE the test's working
        # directory, next to the .chk / .molden / .txt files the run
        # produced.  It used to be written to the top of test_work, so
        # a kept run showed 34 directories and 34 loose .log files side
        # by side and nothing indicated which belonged to which.  A
        # test's output is one thing; it belongs in one place.
        #
        # A `needs` consumer runs in its producer's directory, so its
        # log lands there too -- named after the consumer, so the two
        # cannot collide.
        d = (work / t.needs) if t.needs else (work / t.id)
        return d / ("%s.log" % t.id)

    def execute(t):
        if t.needs:
            wd = work / t.needs
            if t.needs not in produced:
                r = RunResult()
                # Distinguish "not selected" from "does not exist".  The
                # single message covering both read as an ordering
                # problem and hid a deleted producer for two releases.
                known = {x.id for x in tests}
                if t.needs in known:
                    r.skipped = ("producer '%s' not in this selection "
                                 "(add it, or run a wider tag)" % t.needs)
                else:
                    r.skipped = ("producer '%s' DOES NOT EXIST -- this "
                                 "test can never run" % t.needs)
                return t, r
            if produced[t.needs] != 0:
                r = RunResult()
                # v1.25.1: a producer that was SKIPPED (e.g. a driver
                # program not built in this solution) is not a
                # failure, and saying "failed" sent one field
                # investigation to the wrong place.  Name the state.
                prod_res = results_so_far.get(t.needs)
                if prod_res is not None and prod_res.skipped:
                    r.skipped = ("producer '%s' was skipped: %s"
                                 % (t.needs, prod_res.skipped))
                else:
                    r.skipped = "producer '%s' failed" % t.needs
                return t, r
        else:
            wd = work / t.id
        # v1.19.3: create the directory only when the test is actually
        # going to run.  Creating it up front left an empty directory
        # behind for every SKIPPED test -- seven of them after a normal
        # Windows run, where the unit drivers are not built -- which
        # looked exactly like a run that had produced nothing.
        wd.mkdir(parents=True, exist_ok=True)
        res = run_one(t, exe, wd, args.threads)
        if res.skipped:
            try:
                wd.rmdir()          # only succeeds if still empty
            except OSError:
                pass
        produced[t.id] = res.rc if res.rc is not None else 1
        results_so_far[t.id] = res
        return t, res

    # `matches` needs the referenced run to exist, so keep it sequential
    # unless the user explicitly asks for concurrency.  Artefacts are
    # safe under --jobs because each test has its own directory (see
    # run_one); only the `matches` ordering is at risk.
    # A `needs` chain must not be reordered, and neither must `matches`.
    has_chain = any(t.needs for t in sel)
    ntot = len(sel)
    cw = len(str(ntot))

    # ------------------------------------------------------------------
    # v1.20.5: run and REPORT in one pass.
    #
    # v1.20.4 added a line per test and it never appeared during a run,
    # because the tests were executed by a list comprehension --
    #     pairs = [execute(t) for t in sel]
    # -- and only a second loop, afterwards, did the reporting.  Every
    # line was therefore printed at the end, all at once, which is
    # exactly the silence the change was meant to remove.  The reported
    # symptom was a run that printed nothing while more than half the
    # working directories had already appeared on disk.
    #
    # The two loops are now one: a test is run, judged and reported
    # before the next one starts.  That also makes `matches` sounder --
    # the referenced result is guaranteed to have been evaluated, not
    # merely to exist.
    #
    # --jobs > 1 keeps the batch form: with several tests in flight the
    # order of completion is not the order of the manifest, and
    # interleaved progress lines would say less than nothing.
    # ------------------------------------------------------------------
    if args.jobs > 1 and not has_chain:
        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            pairs = list(pool.map(execute, sel))
        stream = iter(pairs)
    else:
        pairs = []

        def _run_and_collect():
            for t in sel:
                pair = execute(t)
                pairs.append(pair)
                yield pair
        stream = _run_and_collect()

    for t, res in stream:
        runs_by_id[t.id] = res
        twall += res.wall
        # v1.20.4: one line per test, written as it finishes.
        #
        # The previous version overwrote a single line in place, which
        # only worked on a terminal and left the reader with no record
        # of what had already run.  A counter and a newline per test
        # work everywhere -- terminal, redirected file, CI log -- and
        # say both what is happening now and how much is left.
        # flush=True on every verdict: a redirected run block-buffers
        # stdout, so without it the file stays empty until the end and
        # the progress is invisible exactly where it is most wanted.
        idx += 1
        # v1.21.0: a test carrying `note =` is marked with a star and the
        # text is printed once, under the results table.  Some agreements
        # are expected to be poor for a reason -- an optimized DFT energy
        # compared against ORCA on defgrid3 sits 90-145 uHa high because
        # the grids differ, and that is not a defect.  Without a visible
        # explanation the reader either distrusts the suite or, worse,
        # learns to expect large deviations everywhere.
        star = "*" if t.note else " "
        head = "[%*d/%d] %-45s%s ... " % (cw, idx, ntot, t.id, star)
        if res.skipped:
            print(head + "SKIP   %s" % res.skipped, flush=True)
            nskip += 1
            results.append({"id": t.id, "status": "SKIP", "detail": res.skipped})
            continue

        failures, observed = [], []
        for a in t.asserts:
            if a.kind in ("value", "throughput", "stable", "matches", "geometry"):
                prov[a.src if a.src in PROVENANCE else "unspecified"] += 1
            ok, detail = evaluate(a, res, runs_by_id)
            if not ok:
                failures.append("%s:%d  %s  -->  %s"
                                % (Path(a.source).name, a.lineno, a.raw, detail))
            elif args.report and a.kind in ("value", "throughput",
                                            "stable", "matches"):
                # v1.19.17: the deviation is computed for every numerical
                # assertion and, until now, discarded unless the test
                # failed.  A comparison against an external reference is
                # worth watching even when it passes: a tolerance wide
                # enough to survive a grid difference is too wide to
                # notice drift, and drift is what one wants to see
                # coming.  --report surfaces the number without
                # weakening the guard.
                observed.append("     %s" % detail)

        # ------------------------------------------------------------
        # v1.20.2: a test may be EXPECTED to fail.
        #
        # chf2o_guess_sad is RIGHT to fail: %initial_guess sad reaches a
        # solution 3.3 mHa above hcore on the Windows build, and the
        # assertion says exactly that.  Deleting it would delete the only
        # executable record of the defect.  Leaving it red trains
        # everyone to skim past a red suite, which costs more than the
        # one test is worth.
        #
        # `expect = fail` resolves the dilemma.  The failure is reported
        # as XFAIL and does not break the run.  And if the defect is ever
        # fixed, the unexpected PASS is counted as a REAL failure -- so
        # nobody can repair the bug and quietly leave the marker behind.
        # ------------------------------------------------------------
        if failures and t.expect == "fail":
            # ------------------------------------------------------------
            # v1.20.3: XFAIL IS SILENT BY DEFAULT.  Use --show-xfail.
            #
            # The machinery stays; only the display is suppressed, and
            # the reason is worth writing down.  Printing "XFAIL" with
            # the full assertion detail read as a report of failure --
            # the user's comparison was to calling a geometry
            # optimization unsuccessful because it found a different
            # isomer than the one you were looking for.  Both statements
            # are true and neither is a complaint about the program.
            #
            # A line that looks like bad news every single run is a line
            # people learn to skip, and once they skip it they skip the
            # ones next to it too.  The count still appears in the
            # summary, so nothing is hidden -- it just no longer shouts.
            # ------------------------------------------------------------
            if args.run_xfail:
                print(head + "XFAIL  (%.1f s)  known defect" % res.wall, flush=True)
                for f in failures:
                    print("          " + f)
            nxfail += 1
            results.append({"id": t.id, "status": "XFAIL", "wall": res.wall,
                            "failures": failures})
        elif not failures and t.expect == "fail":
            # XPASS is reported loudly but does NOT break the run.
            #
            # A first version counted it as a failure, on the reasoning
            # that a fixed defect must not leave its marker behind.  That
            # is right for a defect that always fails and wrong for one
            # that does not: chf2o_guess_sad fails under Intel Fortran on
            # Windows and passes under gfortran, so on half the machines
            # a correct suite would have been permanently red for having
            # documented a real bug.
            #
            # "Did not fail here" and "is fixed" are different statements
            # and the runner cannot tell them apart.  So it says what it
            # observed, prominently and in the summary, and leaves the
            # judgement to the reader.
            print(head + "XPASS  (%.1f s)  expected to fail, did not" % res.wall, flush=True)
            nxpass += 1
            results.append({"id": t.id, "status": "XPASS", "wall": res.wall})
        elif failures:
            print(head + "FAIL   (%.1f s)" % res.wall, flush=True)
            for f in failures:
                print("          " + f)
            log = log_path(t)
            log.parent.mkdir(parents=True, exist_ok=True)
            log.write_text(res.output, encoding="utf-8")
            print("          log: %s" % log)
            nfail += 1
            results.append({"id": t.id, "status": "FAIL", "wall": res.wall,
                            "failures": failures})
        else:
            print(head + "PASS   (%.1f s)" % res.wall, flush=True)
            for line in observed:
                print(line)
            if args.keep_logs:
                lp = log_path(t)
                lp.parent.mkdir(parents=True, exist_ok=True)
                lp.write_text(res.output, encoding="utf-8")
            npass += 1
            results.append({"id": t.id, "status": "PASS", "wall": res.wall,
                            "observed": res.observed})

    total_num = sum(prov.values())
    print()
    print("=" * 70)
    print(" Results")
    print("=" * 70)
    extra = ""
    if nxfail: extra += "   XFAIL %d" % nxfail
    if nxpass: extra += "   XPASS %d" % nxpass
    # ------------------------------------------------------------------
    # v1.20.4: a closing section that repeats what needs acting on.
    #
    # The per-test lines above scroll away -- 239 of them on a full run.
    # Anything that is not a plain PASS is listed again here, so the end
    # of the output is self-sufficient and nobody has to scroll back to
    # find which three tests failed.  Plain passes are not repeated:
    # they are the case that needs no action, and repeating 236 of them
    # would bury the three that do.
    # ------------------------------------------------------------------
    seen_notes, notes = set(), []
    for t in sel:
        if t.note and t.note not in seen_notes:
            seen_notes.add(t.note)
            notes.append(t.note)

    notable = [r for r in results if r["status"] != "PASS"]
    if notable:
        print(" %-8s %-46s %s" % ("STATUS", "TEST", "TIME"))
        print(" " + "-" * 68)
        for r in notable:
            if r["status"] == "XFAIL" and not args.run_xfail:
                continue
            w = r.get("wall")
            print(" %-8s %-46s %s"
                  % (r["status"], r["id"],
                     ("%.1f s" % w) if w is not None else "--"))
        print(" " + "-" * 68)
    print(" PASS %d   FAIL %d   SKIP %d%s   in %.1f s (%.1f min)"
          % (npass, nfail, nskip, extra, twall, twall / 60.0))
    if nxfail:
        print(" %d known defect(s) failed as expected; --show-xfail for detail."
              % nxfail)
    if nxpass:
        print(" %d test(s) marked `expect = fail` did not fail here." % nxpass)
        print(" That may mean the defect is fixed, or only that this")
        print(" platform does not show it.  Check before dropping the mark.")
    if total_num:
        rec = prov["recorded"] + prov["unspecified"]
        print(" numerical assertions: %d   validated %d   recorded %d (%.0f%%)"
              % (total_num, total_num - rec, rec, 100.0 * rec / total_num))
        print("   A `recorded` value proves a result did not change.")
        print("   It can never prove the result was right.")
    print("=" * 70)

    if args.json:
        Path(args.json).write_text(json.dumps(
            {"pass": npass, "fail": nfail, "skip": nskip,
             "provenance": prov, "tests": results}, indent=2), encoding="utf-8")

    # ------------------------------------------------------------------
    # Working-directory retention, and SAYING SO.
    #
    # A green run used to delete every working directory and print
    # nothing about it, so a user who went looking for the .molden and
    # .chk files a test had produced found an empty tree and reasonably
    # concluded the tests had not run.  The policy is fine; its silence
    # was not.
    # ------------------------------------------------------------------
    removed = 0
    if nfail == 0 and not args.keep_logs:
        keep = {t.needs for t in sel if t.needs}
        for t, res in pairs:
            if t.id in keep or res.skipped:
                continue
            d = work / t.id
            if d.exists():
                shutil.rmtree(str(d), ignore_errors=True)
                removed += 1

    # Sweep any directory left empty (a skipped test whose rmdir lost a
    # race, or a run that wrote nothing at all).
    if work.exists():
        for d in sorted(work.iterdir()):
            if d.is_dir():
                try:
                    d.rmdir()
                except OSError:
                    pass

    # ------------------------------------------------------------------
    # v1.21.1: footnotes go LAST, and are wrapped.
    #
    # They sat between the verdict line and the assertion counts, which
    # split the summary in two, and they were printed as a single line
    # of whatever length the text happened to be -- unreadable on a wide
    # terminal, where it does not wrap at all.  A footnote belongs after
    # the thing it annotates, and text meant to be read needs a measured
    # line length rather than the accident of the window width.
    # ------------------------------------------------------------------
    def _print_notes():
        if not notes:
            return
        print()
        for i, n in enumerate(notes, 1):
            body = textwrap.wrap(n, width=72)
            print(" * %s" % body[0])
            for line in body[1:]:
                print("   %s" % line)
            if i != len(notes):
                print()

    if removed:
        print(" %d working director%s removed (every test passed)."
              % (removed, "y" if removed == 1 else "ies"))
        print(" Re-run with --keep-logs to keep them, and the .chk /")
        print(" .molden / .txt files the tests produce, under %s" % work)
    elif work.exists() and any(work.iterdir()):
        print(" Working directories kept under %s" % work)
    _print_notes()

    return 1 if nfail else 0


if __name__ == "__main__":
    sys.exit(main())
