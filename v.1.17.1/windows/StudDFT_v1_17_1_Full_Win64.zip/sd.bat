@echo off

rem --- Place this BAT-file to yout work directory (where your *.inp files are located) or, optionally, to the directory included into PATH variable
rem --- Edit variable STUDDFT below (and OpenMP setting if needed)
rem --- To tun StudDFT: 

rem          sd <yourfile>.inp


rem Uncomment the following lines to set PATH and STUDDFT variables manually
rem --- Path to StudDFT root (where \basis_data and \windows live)
rem set STUDDFT=D:\Projects\StudDFT\StudDFT-release
rem --- Add StudDFT executable directory to PATH
rem set PATH=%STUDDFT%;%PATH%


rem --- Correct these lines if needed (OpenMP cores and stack size)
set OMP_NUM_THREADS=4
set OMP_STACKSIZE=64M


rem --- Run; log goes next to the input file
StudDft %1 >%~n1.log
