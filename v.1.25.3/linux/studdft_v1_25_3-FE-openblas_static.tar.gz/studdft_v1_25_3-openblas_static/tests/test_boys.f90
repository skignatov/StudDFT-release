! ============================================================================
! StudDFT regression unit test:  Boys function table accuracy
! ============================================================================
!
! Verifies that both production Boys-function tables (the one in
! precomputed_tables.f90 and the one in hgp_eri.f90) agree with a
! high-precision reference at every grid node and every m index.
!
! The reference is computed in DOUBLE precision using the same
! cancellation-free downward-recursion scheme used by boys_cook,
! but expanded at very high m_top = 80 (15+ extra orders of safety
! margin).  In double precision this gives < 5 ulp at every (n, T)
! used by the production tables, so any production-table error of
! 1e-13 or larger is reliably detected.
!
! Pass criterion: max relative error < 1e-12 (production-quality);
! detect criterion: relative error > 1e-10 is reported as a fail.
!
! Build with:
!   gfortran -O2 -fopenmp -Isrc -o test_boys tests/test_boys.f90 \
!            src/constants.o src/precomputed_tables.o src/hgp_eri.o \
!            -llapack -lblas
!
! (i.e. link against the already-built object files of the patched code).
!
! Exit status:
!   0  -- both tables OK
!   1  -- precomputed_tables.f90 boys_grid is wrong
!   2  -- hgp_eri.f90 boys_table is wrong
!   3  -- both wrong
!
! This test is the regression guard for the v0.52.15 Boys-table fix.
! Run it after any change touching:
!   src/precomputed_tables.f90
!   src/hgp_eri.f90
! ============================================================================
program test_boys
  use constants,           only: dp, pi, sqrtpi, BOYS_NMAX, BOYS_NGRID, BOYS_TMAX
  use precomputed_tables,  only: init_precomputed_tables, boys_function, &
                                 boys_function_exact, boys_grid
  use hgp_eri_mod,         only: boys_function_hgp => boys_function, &
                                 boys_use_cook
  implicit none

  integer, parameter :: M_MAX_TEST = 22         ! actual production max (MMAX_AUX in hgp_eri)
  integer, parameter :: NTEST_OFFGRID = 5000    ! random off-grid probes
  real(dp), parameter :: TOL_FAIL = 1.0e-10_dp
  real(dp), parameter :: TOL_PASS = 1.0e-12_dp

  integer  :: ig, n, k_off, exit_code
  real(dp) :: T, dt, ref_val, rel
  real(dp) :: worst_pt, worst_pt_T
  integer  :: worst_pt_n, worst_pt_ig
  real(dp) :: worst_hgp, worst_hgp_T
  integer  :: worst_hgp_n
  real(dp) :: worst_pt_off, worst_hgp_off
  real(dp) :: T_off, harvest
  real(dp), allocatable :: ref_arr(:), Fm_hgp(:)
  integer :: seed_size
  integer, allocatable :: seed(:)

  exit_code = 0
  worst_pt   = 0.0_dp
  worst_hgp  = 0.0_dp
  worst_pt_off  = 0.0_dp
  worst_hgp_off = 0.0_dp
  worst_pt_n  = 0; worst_pt_T  = 0.0_dp; worst_pt_ig = 0
  worst_hgp_n = 0; worst_hgp_T = 0.0_dp

  write(*,'(A)') '============================================================'
  write(*,'(A)') ' StudDFT Boys-function table regression test'
  write(*,'(A)') '============================================================'

  ! Trigger initialization of both tables
  call init_precomputed_tables()

  ! Force the hgp_eri table path (not boys_cook) so we test the table:
  boys_use_cook = .false.

  ! Force a single dummy call into the hgp_eri Boys function to ensure
  ! its internal table is initialized:
  allocate(Fm_hgp(0:M_MAX_TEST))
  call boys_function_hgp(M_MAX_TEST, 1.0_dp, Fm_hgp)

  allocate(ref_arr(0:BOYS_NMAX))

  ! ----- Test 1: NODE values of precomputed_tables.f90 boys_grid -----
  dt = BOYS_TMAX / real(BOYS_NGRID, dp)
  do ig = 0, BOYS_NGRID
    T = real(ig, dp) * dt
    if (T < 1.0e-12_dp) cycle
    call boys_reference(T, BOYS_NMAX, ref_arr)
    do n = 0, M_MAX_TEST       ! only check the production-used range
      if (abs(ref_arr(n)) < 1.0e-300_dp) cycle
      rel = abs(boys_grid(n, ig) - ref_arr(n)) / abs(ref_arr(n))
      if (rel > worst_pt) then
        worst_pt    = rel
        worst_pt_n  = n
        worst_pt_T  = T
        worst_pt_ig = ig
      end if
    end do
  end do

  write(*,'(/,A)') '  TEST 1: precomputed_tables :: boys_grid (table NODE values)'
  write(*,'(A,ES12.3,A,I3,A,F8.3)') &
    '    worst |rel err| = ', worst_pt, '  at  n =', worst_pt_n, ', T =', worst_pt_T
  if (worst_pt > TOL_FAIL) then
    write(*,'(A)') '    STATUS: FAIL'
    exit_code = ior(exit_code, 1)
  else if (worst_pt > TOL_PASS) then
    write(*,'(A)') '    STATUS: WARN  (above TOL_PASS but below TOL_FAIL)'
  else
    write(*,'(A)') '    STATUS: PASS'
  end if

  ! ----- Test 2: Off-grid INTERPOLATION of precomputed_tables boys_function -----
  call random_seed(size=seed_size)
  allocate(seed(seed_size))
  seed = 1234567   ! deterministic seed for reproducibility
  call random_seed(put=seed)
  do k_off = 1, NTEST_OFFGRID
    call random_number(harvest)
    T_off = harvest * (BOYS_TMAX - 0.01_dp) + 0.005_dp
    call random_number(harvest)
    n = int(harvest * (M_MAX_TEST + 1))
    if (n > M_MAX_TEST) n = M_MAX_TEST
    call boys_reference_one(T_off, n, ref_val)
    if (abs(ref_val) < 1.0e-300_dp) cycle
    rel = abs(boys_function(n, T_off) - ref_val) / abs(ref_val)
    if (rel > worst_pt_off) worst_pt_off = rel
  end do
  write(*,'(/,A)') '  TEST 2: precomputed_tables :: boys_function (off-grid Taylor)'
  write(*,'(A,ES12.3,A,I0,A)') &
    '    worst |rel err| = ', worst_pt_off, '  over ', NTEST_OFFGRID, ' random probes'
  if (worst_pt_off > TOL_FAIL) then
    write(*,'(A)') '    STATUS: FAIL'
    exit_code = ior(exit_code, 1)
  else if (worst_pt_off > TOL_PASS) then
    write(*,'(A)') '    STATUS: WARN'
  else
    write(*,'(A)') '    STATUS: PASS'
  end if

  ! ----- Test 3: hgp_eri boys_function (table path) at random off-grid points -----
  call random_seed(put=seed)
  do k_off = 1, NTEST_OFFGRID
    call random_number(harvest)
    T_off = harvest * (29.95_dp - 0.05_dp) + 0.05_dp   ! BF_TMAX - epsilon
    call random_number(harvest)
    n = int(harvest * (M_MAX_TEST + 1))
    if (n > M_MAX_TEST) n = M_MAX_TEST
    call boys_function_hgp(n, T_off, Fm_hgp(0:n))
    call boys_reference_one(T_off, n, ref_val)
    if (abs(ref_val) < 1.0e-300_dp) cycle
    rel = abs(Fm_hgp(n) - ref_val) / abs(ref_val)
    if (rel > worst_hgp) then
      worst_hgp   = rel
      worst_hgp_n = n
      worst_hgp_T = T_off
    end if
  end do
  write(*,'(/,A)') '  TEST 3: hgp_eri_mod :: boys_function (table path)'
  write(*,'(A,ES12.3,A,I3,A,F8.3)') &
    '    worst |rel err| = ', worst_hgp, '  at  n =', worst_hgp_n, ', T =', worst_hgp_T
  if (worst_hgp > TOL_FAIL) then
    write(*,'(A)') '    STATUS: FAIL'
    exit_code = ior(exit_code, 2)
  else if (worst_hgp > TOL_PASS) then
    write(*,'(A)') '    STATUS: WARN'
  else
    write(*,'(A)') '    STATUS: PASS'
  end if

  ! ----- Test 4: hgp_eri boys_cook == hgp_eri table  (after fix) -----
  call random_seed(put=seed)
  worst_hgp_off = 0.0_dp
  do k_off = 1, NTEST_OFFGRID
    block
      real(dp) :: Fm_table(0:M_MAX_TEST), Fm_cook(0:M_MAX_TEST)
      call random_number(harvest)
      T_off = harvest * (29.95_dp - 0.05_dp) + 0.05_dp
      boys_use_cook = .false.
      call boys_function_hgp(M_MAX_TEST, T_off, Fm_table)
      boys_use_cook = .true.
      call boys_function_hgp(M_MAX_TEST, T_off, Fm_cook)
      do n = 0, M_MAX_TEST
        if (abs(Fm_cook(n)) < 1.0e-300_dp) cycle
        rel = abs(Fm_table(n) - Fm_cook(n)) / abs(Fm_cook(n))
        if (rel > worst_hgp_off) worst_hgp_off = rel
      end do
    end block
  end do
  boys_use_cook = .false.
  write(*,'(/,A)') '  TEST 4: hgp_eri_mod :: boys_cook == boys_table (post-fix invariant)'
  write(*,'(A,ES12.3)') '    worst |table - cook| / |cook| = ', worst_hgp_off
  if (worst_hgp_off > TOL_FAIL) then
    write(*,'(A)') '    STATUS: FAIL  (table and cook disagree -- bug returned)'
    exit_code = ior(exit_code, 2)
  else if (worst_hgp_off > TOL_PASS) then
    write(*,'(A)') '    STATUS: WARN'
  else
    write(*,'(A)') '    STATUS: PASS'
  end if

  write(*,'(/,A,I2)') '  Overall exit code: ', exit_code
  if (exit_code == 0) then
    write(*,'(A)') '  ALL BOYS TABLE CHECKS PASSED.'
  else
    write(*,'(A)') '  *** BOYS TABLE REGRESSION DETECTED ***'
  end if

  deallocate(ref_arr, Fm_hgp, seed)
  call exit(exit_code)

contains

  ! ========================================================================
  ! High-quality Boys function reference -- in DOUBLE precision, using the
  ! cancellation-free downward-recursion scheme expanded at m_top = 80.
  !
  ! For 0 < T <= 30 and 0 <= n <= 28, this scheme converges to within
  ! ~3 ulp of the true value (compared to mpmath at 60 decimal digits;
  ! see /home/claude/boys_final_check.py).
  ! ========================================================================
  subroutine boys_reference(T, n_max, Fm_out)
    real(dp), intent(in)  :: T
    integer,  intent(in)  :: n_max
    real(dp), intent(out) :: Fm_out(0:n_max)
    integer, parameter :: MTOP_REF = 80
    real(dp) :: Fwork(0:MTOP_REF)
    real(dp) :: expT, two_T, a, term, psum
    integer  :: m, k

    if (T < 1.0e-14_dp) then
      do m = 0, n_max
        Fm_out(m) = 1.0_dp / real(2*m + 1, dp)
      end do
      return
    end if
    expT  = exp(-T)
    two_T = 2.0_dp * T
    a = real(MTOP_REF, dp) + 0.5_dp
    term = 1.0_dp / a
    psum = term
    do k = 1, 400
      a = a + 1.0_dp
      term = term * T / a
      psum = psum + term
      if (abs(term) < 1.0e-19_dp * abs(psum)) exit
    end do
    Fwork(MTOP_REF) = 0.5_dp * psum * expT
    do m = MTOP_REF, 1, -1
      Fwork(m-1) = (two_T * Fwork(m) + expT) / real(2*m - 1, dp)
    end do
    Fm_out(0:n_max) = Fwork(0:n_max)
  end subroutine

  subroutine boys_reference_one(T, n, val)
    real(dp), intent(in)  :: T
    integer,  intent(in)  :: n
    real(dp), intent(out) :: val
    real(dp) :: Fm_local(0:n)
    call boys_reference(T, n, Fm_local)
    val = Fm_local(n)
  end subroutine

end program test_boys
