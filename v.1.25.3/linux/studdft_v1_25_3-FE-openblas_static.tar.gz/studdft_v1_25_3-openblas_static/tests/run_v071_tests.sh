#!/bin/bash
# =============================================================
# StudDFT v0.71.0 -- Relaxed PES scan ("scanopt") suite
# =============================================================
#
# Runs every test_v071_*.inp under tests/ and verifies:
#   * positive: the run completes, the per-point dihedral / bond
#     value matches what the user requested (constraint actually
#     holds), and the relaxed-scan summary table is produced
#   * negative: shared validation with %job scan rejects the
#     same ill-formed inputs
#   * physical consistency: relaxed energies are >= the value
#     of the unconstrained minimum, and at every common grid
#     point relaxed energy is <= rigid energy at that point
#
# Usage: ./run_v071_tests.sh [path_to_studdft]
# =============================================================

set -u
EXE=${1:-./studdft}
cd "$(dirname "$0")/.."
export STUDDFT="$PWD"

PASS=0
FAIL=0

# Helper: extract energies from a "Relaxed PES scan -- summary" or
# "Rigid PES scan -- summary" block.  Energies are column 3 of the
# table rows (lines that start with whitespace + integer point
# index).
extract_energies() {
    awk '
        /(Relaxed|Rigid) PES scan -- summary/ { in_block = 1; next }
        in_block && /^   ----/                { ndash++; if (ndash >= 1) inrows = 1; next }
        in_block && inrows && NF >= 3 && $1 ~ /^[0-9]+$/ { print $3 }
        in_block && /^$/ && inrows            { exit }
    ' "$1"
}

# ----- Positive tests -----
for inp in tests/test_v071_hooh_relaxed_dihedral.inp \
           tests/test_v071_h2o_relaxed_OH_scan.inp; do
    name=$(basename "$inp" .inp)
    if "$EXE" "$inp" > /tmp/${name}.out 2>&1; then
        if grep -q "Relaxed PES scan -- summary" /tmp/${name}.out; then
            printf "  PASS  %s\n" "$name"
            PASS=$((PASS+1))
        else
            printf "  FAIL  %s  (no relaxed summary)\n" "$name"
            FAIL=$((FAIL+1))
        fi
    else
        printf "  FAIL  %s  (exit code != 0)\n" "$name"
        FAIL=$((FAIL+1))
    fi
done

# ----- Negative test: scanopt without %gz -----
inp=tests/test_v071_scanopt_no_zmat.inp
name=$(basename "$inp" .inp)
"$EXE" "$inp" > /tmp/${name}.out 2>&1
rc=$?
if [ $rc -ne 0 ] && grep -q "ERROR" /tmp/${name}.out; then
    printf "  PASS  %s  (clean diagnostic, rc=%d)\n" "$name" "$rc"
    PASS=$((PASS+1))
else
    printf "  FAIL  %s  (expected non-zero exit + ERROR; rc=%d)\n" "$name" "$rc"
    FAIL=$((FAIL+1))
fi

# ----- Physical-consistency: relaxed <= rigid pointwise -----
# Using HOOH dihedral scan (same grid in v0.69 rigid and v0.71
# relaxed).  Both runs produce 7 points with the same D values;
# the relaxed energy at every point must be <= the rigid energy
# at the same point (relaxation can only LOWER the energy).
"$EXE" tests/test_v069_hooh_dihedral_scan.inp > /tmp/rigid_hooh.out 2>&1
"$EXE" tests/test_v071_hooh_relaxed_dihedral.inp > /tmp/relax_hooh.out 2>&1
RIGID_E=$(extract_energies /tmp/rigid_hooh.out)
RELAX_E=$(extract_energies /tmp/relax_hooh.out)
n_rigid=$(echo "$RIGID_E" | wc -l)
n_relax=$(echo "$RELAX_E" | wc -l)
if [ "$n_rigid" -ne "$n_relax" ] || [ "$n_rigid" -ne 7 ]; then
    printf "  FAIL  hooh rigid-vs-relaxed: bad row counts (%d / %d)\n" \
        "$n_rigid" "$n_relax"
    FAIL=$((FAIL+1))
else
    bad=0
    for i in 1 2 3 4 5 6 7; do
        Er=$(echo "$RIGID_E" | sed -n "${i}p")
        El=$(echo "$RELAX_E" | sed -n "${i}p")
        # El should be <= Er + small slack (1e-8 Ha) for numerical
        # noise.  Equivalently El - Er <= 1e-8.
        ok=$(awk -v a="$El" -v b="$Er" 'BEGIN{ if (a - b <= 1e-8) print "1"; else print "0" }')
        if [ "$ok" = "0" ]; then
            bad=1
            printf "    point %d: rigid=%s  relaxed=%s   *** RELAXED HIGHER ***\n" \
                "$i" "$Er" "$El"
        fi
    done
    if [ $bad -eq 0 ]; then
        printf "  PASS  hooh rigid-vs-relaxed: relaxed <= rigid at all 7 points\n"
        PASS=$((PASS+1))
    else
        printf "  FAIL  hooh rigid-vs-relaxed (some relaxed energies are higher)\n"
        FAIL=$((FAIL+1))
    fi
fi

# ----- Physical-consistency: relaxed minimum vs unconstrained opt -----
# The HOOH unconstrained optimization gives the global minimum;
# the relaxed scan minimum at D=120 (closest grid point to the
# physical optimum near D=111-114) should be very close to it
# (within a few mHa, mostly because the dihedral grid does not
# hit the physical minimum exactly).
"$EXE" tests/test_v067_hooh_opt.inp > /tmp/uopt_hooh.out 2>&1
E_UOPT=$(grep "Final energy:" /tmp/uopt_hooh.out | head -1 | awk '{print $3}')
# Min from relaxed-scan summary
E_RMIN=$(grep "Minimum energy:" /tmp/relax_hooh.out | head -1 | awk '{print $3}')
if [ -n "$E_UOPT" ] && [ -n "$E_RMIN" ]; then
    DIFF=$(awk -v a="$E_UOPT" -v b="$E_RMIN" \
        'BEGIN{ d=b-a; if (d<0) d=-d; printf "%.3e", d}')
    OK=$(awk -v d="$DIFF" 'BEGIN{print (d<5e-3)?"OK":"FAIL"}')
    if [ "$OK" = "OK" ]; then
        printf "  PASS  hooh relaxed min vs unconstrained opt: |dE| = %s Ha\n" "$DIFF"
        PASS=$((PASS+1))
    else
        printf "  FAIL  hooh relaxed min vs unconstrained opt: |dE| = %s Ha (>5e-3)\n" "$DIFF"
        FAIL=$((FAIL+1))
    fi
else
    printf "  FAIL  hooh relaxed min vs unconstrained opt (missing values)\n"
    FAIL=$((FAIL+1))
fi

echo
echo "  Summary:  $PASS passed, $FAIL failed."
echo
[ $FAIL -eq 0 ] && exit 0 || exit 1
