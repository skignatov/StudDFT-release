#!/bin/bash
# =============================================================
# StudDFT v0.75.1 -- linear-molecule TR-projection fix
#                    test suite
# =============================================================
#
# Runs every test_v075_*_linear_freq.inp + the h2o_freq_regression
# test under tests/ and verifies:
#
#   * test_v075_BeH2_linear_freq
#       BeH2 HF/cc-pVDZ opt+freq starting from a bent 109-degree
#       guess.  Pre-v0.75.1 this projected out 6 TR modes instead
#       of 5 (one Pi-bend component eaten by the spurious axial-
#       rotation vector) and reported only 3 vibrations.  Asserts:
#         - Optimization converged
#         - "Projected out  5 TR modes (linear molecule)" present
#         - "Vibrational modes:    4" present
#         - "TR modes:             5" present
#
#   * test_v075_co2_linear_freq
#       CO2 HF/STO-3G opt+freq from a 170-degree guess.  Second
#       independent test point on the linearity branch with a
#       heavier-atom mass distribution.  Asserts the same three
#       output lines as the BeH2 test.
#
#   * test_v075_h2o_freq_regression
#       H2O HF/STO-3G opt+freq.  Regression check: bent molecule
#       must take the non-linear branch.  Asserts:
#         - "Projected out  6 TR modes." present (with the trailing
#           period, i.e. WITHOUT the "(linear molecule)" qualifier)
#         - "Vibrational modes:    3" present
#         - "TR modes:             6" present
#
# Each test runs the binary and inspects its stdout via grep / awk
# helpers identical in style to run_v075_tests.sh.  Returns 0 only
# if every test passes.
# =============================================================

set -u
EXE=${1:-./studdft}
cd "$(dirname "$0")/.."
export STUDDFT="$PWD"

PASS=0
FAIL=0
FAIL_NAMES=()

# -----------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------
run_input() {
    local inp="$1"
    OUTBUF=$($EXE "$inp" 2>&1)
    return $?
}

# Convergence detection (same as run_v075_tests.sh).
opt_converged() {
    echo "$OUTBUF" | grep -q 'Optimization converged in'
}
opt_not_converged() {
    echo "$OUTBUF" | grep -q 'Optimization NOT converged'
}

# Linearity diagnostic: the "(linear molecule)" qualifier from
# project_tr_modes (v0.75.1).
saw_linear_diag() {
    echo "$OUTBUF" | grep -q 'Projected out  5 TR modes (linear molecule)'
}
# Non-linear branch diagnostic.  The trailing period is part of the
# match -- it discriminates "...6 TR modes." from a future variant
# that might print extra text on the same line.
saw_nonlinear_diag() {
    echo "$OUTBUF" | grep -q 'Projected out  6 TR modes\.'
}

# Tail-end count printed by print_frequencies.
vib_mode_count() {
    echo "$OUTBUF" | awk '/Vibrational modes:/ {v=$NF} END {print v+0}'
}
tr_mode_count() {
    echo "$OUTBUF" | awk '/TR modes:/ {v=$NF} END {print v+0}'
}

pass() { PASS=$((PASS+1)); printf "  PASS  %s\n" "$1"; }
fail() { FAIL=$((FAIL+1)); FAIL_NAMES+=("$1"); printf "  FAIL  %s  (%s)\n" "$1" "$2"; }

# Common assertions for a "linear" test case.
check_linear_case() {
    local tag="$1"
    if opt_not_converged; then
        fail "$tag" "optimizer did not converge"
        return
    fi
    if ! opt_converged; then
        fail "$tag" "convergence line not found"
        return
    fi
    if ! saw_linear_diag; then
        fail "$tag" "'Projected out  5 TR modes (linear molecule)' missing"
        return
    fi
    local NV NT
    NV=$(vib_mode_count)
    NT=$(tr_mode_count)
    if [ "$NV" -ne 4 ]; then
        fail "$tag" "Vibrational modes = $NV, expected 4"
        return
    fi
    if [ "$NT" -ne 5 ]; then
        fail "$tag" "TR modes = $NT, expected 5"
        return
    fi
    pass "$tag  linear branch:  5 TR + 4 vib"
}

# -----------------------------------------------------------------
# Test 1: BeH2 -- the headline failure from the bug report.
# -----------------------------------------------------------------
echo
echo "=== Test 1: BeH2 opt+freq (HF/cc-pVDZ, linear molecule) ==="
run_input "tests/test_v075_BeH2_linear_freq.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "BeH2_linear_freq" "rc=$rc"
else
    check_linear_case "BeH2_linear_freq"
fi

# -----------------------------------------------------------------
# Test 2: CO2 -- independent linearity-branch test point.
# -----------------------------------------------------------------
echo
echo "=== Test 2: CO2 opt+freq (HF/STO-3G, linear molecule) ==="
run_input "tests/test_v075_co2_linear_freq.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "co2_linear_freq" "rc=$rc"
else
    check_linear_case "co2_linear_freq"
fi

# -----------------------------------------------------------------
# Test 3: H2O regression -- non-linear branch must still fire.
# -----------------------------------------------------------------
echo
echo "=== Test 3: H2O opt+freq (HF/STO-3G, bent regression) ==="
run_input "tests/test_v075_h2o_freq_regression.inp"
rc=$?
if [ $rc -ne 0 ]; then
    fail "h2o_freq_regression" "rc=$rc"
elif ! opt_converged; then
    fail "h2o_freq_regression" "optimizer did not converge"
elif saw_linear_diag; then
    fail "h2o_freq_regression" "false-positive linearity classification"
elif ! saw_nonlinear_diag; then
    fail "h2o_freq_regression" "'Projected out  6 TR modes.' missing"
else
    NV=$(vib_mode_count)
    NT=$(tr_mode_count)
    if [ "$NV" -ne 3 ]; then
        fail "h2o_freq_regression" "Vibrational modes = $NV, expected 3"
    elif [ "$NT" -ne 6 ]; then
        fail "h2o_freq_regression" "TR modes = $NT, expected 6"
    else
        pass "h2o_freq_regression  non-linear branch:  6 TR + 3 vib"
    fi
fi

# -----------------------------------------------------------------
# Summary
# -----------------------------------------------------------------
echo
echo "============================================================="
echo "v0.75.1 test suite:  $PASS pass, $FAIL fail"
if [ $FAIL -gt 0 ]; then
    echo "Failed tests:"
    for n in "${FAIL_NAMES[@]}"; do echo "  - $n"; done
    exit 1
fi
exit 0
