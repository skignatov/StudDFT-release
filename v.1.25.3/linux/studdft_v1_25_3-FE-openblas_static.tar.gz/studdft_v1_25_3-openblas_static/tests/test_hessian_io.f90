! ============================================================================
! StudDFT v0.72.0-dev -- Standalone test for hessian_io
!
! Three checks:
!   (1) Round-trip: write a Hessian file, read it back, compare to source.
!       Should be bit-for-bit (max |dH| == 0).
!   (2) Geometry-mismatch detection: read after perturbing one atom by
!       1.0 bohr -- much greater than the 1e-5 tolerance.
!       Reader must signal ierr /= 0.
!   (3) Method-mismatch detection: read with a different %method label.
!       Reader must signal ierr /= 0.
!
! Build:
!   make test_hessian_io
! Run:
!   ./test_hessian_io
! Cleanup (manually, since the test creates files in $PWD):
!   rm -f test_hio.hess
! ============================================================================
program test_hessian_io
    use constants, only: dp
    use types, only: molecule_t, atom_init
    use xc_functional_types, only: SPIN_RESTRICTED
    use hessian_io, only: write_hess_file, read_hess_file
    implicit none

    type(molecule_t) :: mol
    integer, parameter :: natom = 3
    integer, parameter :: ncoord = 3*natom
    real(dp) :: hess_w(ncoord, ncoord), hess_r(ncoord, ncoord)
    real(dp) :: grad(3, natom)
    real(dp) :: freqs(ncoord)
    real(dp) :: modes(ncoord, ncoord)
    integer :: ii, jj, ierr
    real(dp) :: max_diff

    write(*,'(A)') 'test_hessian_io: round-trip and mismatch checks'
    write(*,'(A)') '------------------------------------------------'

    ! Build a fake H2O molecule
    mol%natom = natom
    allocate(mol%atoms(natom))
    do ii = 1, natom
        call atom_init(mol%atoms(ii))
    end do
    mol%atoms(1)%atomic_number = 8
    mol%atoms(1)%coords = [0.0_dp,  0.0_dp,    0.2226_dp]
    mol%atoms(2)%atomic_number = 1
    mol%atoms(2)%coords = [0.0_dp,  1.4275_dp, -0.8902_dp]
    mol%atoms(3)%atomic_number = 1
    mol%atoms(3)%coords = [0.0_dp, -1.4275_dp, -0.8902_dp]

    ! Synthetic data: distinct in every entry so any layout slip-up
    ! shows up immediately.
    do ii = 1, ncoord
        do jj = 1, ncoord
            hess_w(ii, jj) = real(ii, dp) + real(jj, dp) * 0.001_dp
        end do
    end do
    do ii = 1, natom
        grad(:, ii) = [real(3*ii-2, dp)*1.0e-7_dp, &
                       real(3*ii-1, dp)*1.0e-7_dp, &
                       real(3*ii,   dp)*1.0e-7_dp]
    end do
    do ii = 1, ncoord
        freqs(ii) = real(ii*100, dp) - 5.0_dp
    end do
    do ii = 1, ncoord
        do jj = 1, ncoord
            modes(ii, jj) = sin(real(ii*jj, dp) * 0.1_dp)
        end do
    end do

    ! ---- (1) Round-trip ----------------------------------------------
    call write_hess_file('test_hio', mol, 'HF', 'STO-3G', '', &
                          0, 1, SPIN_RESTRICTED, &
                          -76.123456789_dp, hess_w, freqs, modes, &
                          grad=grad)
    call read_hess_file('test_hio.hess', mol, 'HF', 'STO-3G', '', &
                         0, 1, SPIN_RESTRICTED, ncoord, hess_r, ierr)
    if (ierr /= 0) then
        write(*,'(A,I0)') 'FAIL (1): read returned ierr = ', ierr
        stop 2
    end if
    max_diff = maxval(abs(hess_w - hess_r))
    write(*,'(A,ES10.2)') '   max |dH| = ', max_diff
    if (max_diff > 1.0e-10_dp) then
        write(*,'(A)') 'FAIL (1): round-trip mismatch above 1e-10'
        stop 3
    end if
    write(*,'(A)') '   (1) Round-trip: PASS'

    ! ---- (2) Geometry mismatch ---------------------------------------
    mol%atoms(2)%coords(1) = mol%atoms(2)%coords(1) + 1.0_dp
    call read_hess_file('test_hio.hess', mol, 'HF', 'STO-3G', '', &
                         0, 1, SPIN_RESTRICTED, ncoord, hess_r, ierr)
    if (ierr == 0) then
        write(*,'(A)') 'FAIL (2): geometry mismatch should have triggered ierr /= 0'
        stop 4
    end if
    write(*,'(A,I0,A)') '   (2) Geometry mismatch: PASS (ierr = ', ierr, ')'
    mol%atoms(2)%coords(1) = mol%atoms(2)%coords(1) - 1.0_dp

    ! ---- (3) Method mismatch -----------------------------------------
    call read_hess_file('test_hio.hess', mol, 'B3LYP', 'STO-3G', '', &
                         0, 1, SPIN_RESTRICTED, ncoord, hess_r, ierr)
    if (ierr == 0) then
        write(*,'(A)') 'FAIL (3): method mismatch should have triggered ierr /= 0'
        stop 5
    end if
    write(*,'(A,I0,A)') '   (3) Method mismatch: PASS (ierr = ', ierr, ')'

    write(*,'(A)') '------------------------------------------------'
    write(*,'(A)') 'test_hessian_io: ALL PASS'

    deallocate(mol%atoms)
end program test_hessian_io
