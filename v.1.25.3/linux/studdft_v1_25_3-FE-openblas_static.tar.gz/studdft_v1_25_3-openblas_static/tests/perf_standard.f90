! ======================================================================
! perf_standard.f90 -- the internal compute standard as the EIGHTH
! unit driver (v1.25.0).  A standalone program in tests/, built with
! the other seven (Makefile target / a thin VS project), run by the
! Python runner next to the chemistry perf tests; the runner then
! asserts RATIOS of chemistry-stage times to the times printed here.
!
! WHY A SEPARATE PROGRAM (design review, v1.25.0): the production
! binary should not carry its own benchmark -- an in-program variant
! (%perf_standard) was prototyped and rejected; a standalone driver
! keeps the keyword surface, the input layout and the program itself
! untouched, and the runner already knows how to run driver programs
! and compare fields ACROSS runs (the `matches` precedent; the new
! `ratio ... den_test=` extends it to quotients).
!
! MOTIVATION (the v1.19 field regression).  A compiler option
! (Intel Heap Arrays = 0) silently moved every automatic array to the
! heap, including three-element scratch vectors in the ERI hot loops;
! wall time rose 2.5x while ITERATION COUNTS DID NOT MOVE.  Absolute
! times are useless across machines; what survives is a ratio of two
! times measured on the same machine at the same thread count --
! provided numerator and denominator stress the SAME KIND of code.
! Hence three workloads:
!
!   std_gemm  one DGEMM 600x600, 6 reps.  Threads exactly as the
!             linked BLAS threads -- which is also how StudDFT's
!             gemm-bound stages (MO transforms) thread, so the pair
!             scales together by construction.  Under the reference
!             netlib BLAS this workload is serial at any thread
!             count; that is a property of the library, shared by
!             both sides of any gemm-stage ratio.
!   std_eig   DSYEV 400x400, 2 reps.  The dense-diagonalization code
!             class (TDDFT / stability solvers); library-threaded,
!             same argument.
!   std_flow  this program's OWN kind of code: a tiny Fortran kernel
!             with AUTOMATIC ARRAYS sized by a dummy argument, 8e6
!             calls, explicitly OpenMP-parallel over the call loop
!             (schedule(dynamic,1024) -- the ERI-loop idiom) with a
!             reduction.  FIXED TOTAL WORK, so it scales down with
!             threads the way the ERI stage does, and a
!             heap-arrays-class pessimization multiplies it while
!             std_gemm stands still.
!
! The program prints the thread count it actually ran on; the runner
! launches it under the same OMP_NUM_THREADS as the chemistry tests,
! so ratios are formed at matched thread counts.
!
! Self-contained on purpose: no StudDFT modules, so the VS project
! for it is one source file plus the BLAS/LAPACK the solution already
! links.  Output format is part of the test contract -- the manifest
! greps these exact labels.
! ======================================================================
program perf_standard
    !$ use omp_lib
    implicit none
    integer, parameter :: dp = selected_real_kind(15, 307)

    integer, parameter :: GEMM_N     = 600
    integer, parameter :: GEMM_REP   = 6
    integer, parameter :: EIG_N      = 400
    integer, parameter :: EIG_REP    = 2
    integer, parameter :: FLOW_LEN   = 6
    integer, parameter :: FLOW_CALLS = 8000000

    real(dp), allocatable :: A(:,:), B(:,:), C(:,:), M(:,:), W(:)
    real(dp), allocatable :: work(:)
    real(dp) :: t0, t_gemm, t_eig, t_flow, acc
    integer  :: i, j, rep, info, lwork, seed, nthreads

    abstract interface
        subroutine flow_iface(n, x, acc)
            import :: dp
            integer,  intent(in)    :: n
            real(dp), intent(in)    :: x
            real(dp), intent(inout) :: acc
        end subroutine flow_iface
    end interface
    procedure(flow_iface), pointer :: flow_ptr => null()

    nthreads = 1
    !$ nthreads = omp_get_max_threads()

    write(*,'(A)') ' --- StudDFT performance standard '// &
        '(unit driver) ---'
    write(*,'(A,I0)') '   threads: ', nthreads

    ! ---- std_gemm (library-threaded) ---------------------------------
    allocate(A(GEMM_N,GEMM_N), B(GEMM_N,GEMM_N), C(GEMM_N,GEMM_N))
    seed = 20260801
    do j = 1, GEMM_N
        do i = 1, GEMM_N
            A(i,j) = lcg(seed)
            B(i,j) = lcg(seed)
        end do
    end do
    C = 0.0_dp
    t0 = wtime()
    do rep = 1, GEMM_REP
        call dgemm('N', 'N', GEMM_N, GEMM_N, GEMM_N, 1.0_dp, &
                   A, GEMM_N, B, GEMM_N, 0.1_dp, C, GEMM_N)
    end do
    t_gemm = wtime() - t0
    if (C(1,1) > huge(1.0_dp)) write(*,*) 'unreachable'
    deallocate(A, B, C)

    ! ---- std_eig (library-threaded) ----------------------------------
    allocate(M(EIG_N,EIG_N), W(EIG_N))
    lwork = 34 * EIG_N
    allocate(work(lwork))
    t0 = wtime()
    do rep = 1, EIG_REP
        seed = 977
        do j = 1, EIG_N
            do i = j, EIG_N
                M(i,j) = lcg(seed)
                M(j,i) = M(i,j)
            end do
            M(j,j) = M(j,j) + real(j, dp)
        end do
        call dsyev('V', 'L', EIG_N, M, EIG_N, W, work, lwork, info)
    end do
    t_eig = wtime() - t0
    if (W(1) > huge(1.0_dp)) write(*,*) 'unreachable'
    deallocate(M, W, work)

    ! ---- std_flow (explicit OpenMP, fixed total work) ----------------
    ! v1.25.2: the kernel is invoked through a PROCEDURE POINTER with a
    ! per-call VARIABLE array size (5..7).  The first field run showed
    ! why both are load-bearing: with a direct call and a constant
    ! size, an aggressive optimizer inlines the tiny kernel and
    ! scalarizes the automatic arrays into registers -- ifort /O2 ran
    ! the probe ~5x faster (relative to its own ERI code) than
    ! gfortran -O2, and gfortran -O3 -march=native reproduced the same
    ! collapse locally (0.41 s -> 0.039 s).  A probe that a compiler
    ! can optimize away measures the optimizer, not the array
    ! machinery.  Neither compiler inlines through a pointer whose
    ! target is assigned at run time, and a size the compiler cannot
    ! fold keeps the automatic arrays genuinely created per call.
    flow_ptr => flow_kernel
    acc = 0.0_dp
    t0 = wtime()
    !$omp parallel do schedule(dynamic,1024) reduction(+:acc)
    do i = 1, FLOW_CALLS
        call flow_ptr(FLOW_LEN - 1 + mod(i, 3), &
                      1.0e-6_dp * real(mod(i, 97), dp), acc)
    end do
    !$omp end parallel do
    t_flow = wtime() - t0
    if (acc > huge(1.0_dp)) write(*,*) 'unreachable'

    write(*,'(A,F10.3,A,I0,A,I0,A)') '   std_gemm:  ', t_gemm, &
        ' s   (dgemm ', GEMM_N, 'x', GEMM_N, ', 6 reps)'
    write(*,'(A,F10.3,A,I0,A,I0,A)') '   std_eig :  ', t_eig, &
        ' s   (dsyev ', EIG_N, 'x', EIG_N, ', 2 reps)'
    write(*,'(A,F10.3,A,I0,A)')      '   std_flow:  ', t_flow, &
        ' s   (automatic-array kernel, ', FLOW_CALLS, ' calls)'
    if (t_gemm > 0.0_dp) then
        write(*,'(A,F10.4)') '   flow/gemm: ', t_flow / t_gemm
    end if
    write(*,'(A)') ' -----------------------------------------------'// &
        '----------------'

contains

    ! Wall clock: omp_get_wtime under OpenMP, system_clock otherwise.
    real(dp) function wtime()
        integer(kind=8) :: cnt, rate
        !$ wtime = omp_get_wtime()
        !$ return
        call system_clock(cnt, rate)
        wtime = real(cnt, dp) / real(rate, dp)
    end function wtime

    ! The automatic-array probe: scratch sized by the DUMMY argument,
    ! so the compiler genuinely creates it per call (stack normally,
    ! heap under a heap-arrays-class option -- what this detects).
    ! Arithmetic shaped like a VRR ladder: short recurrences over
    ! small vectors.
    subroutine flow_kernel(n, x, acc)
        integer,  intent(in)    :: n
        real(dp), intent(in)    :: x
        real(dp), intent(inout) :: acc
        real(dp) :: pa(n), wb(0:n)
        integer :: i
        pa(1) = 1.0_dp + x
        do i = 2, n
            pa(i) = pa(i-1) * 0.99991_dp + 1.3e-4_dp
        end do
        wb(0) = pa(n)
        do i = 1, n
            wb(i) = wb(i-1) * 0.5_dp + pa(1 + mod(i, n))
        end do
        acc = acc + wb(n)
    end subroutine flow_kernel

    ! Deterministic fill in [-0.5, 0.5): plain LCG, identical on every
    ! platform (overflow avoided by modular arithmetic).
    real(dp) function lcg(seed)
        integer, intent(inout) :: seed
        seed = mod(seed * 1103515 + 12345, 2147483)
        if (seed < 0) seed = seed + 2147483
        lcg = real(seed, dp) / 2147483.0_dp - 0.5_dp
    end function lcg

end program perf_standard
