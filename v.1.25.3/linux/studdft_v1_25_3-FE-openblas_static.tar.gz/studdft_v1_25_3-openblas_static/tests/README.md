# StudDFT test system

Reference manual for `tests/runner.py`, `tests/coverage.py` and
`tests/triage.py`.

Contents:

1. [Quick start](#1-quick-start)
2. [What the suite is trying to be](#2-what-the-suite-is-trying-to-be)
3. [runner.py -- command line](#3-runnerpy----command-line)
4. [Tiers and tags](#4-tiers-and-tags)
5. [Manifest format](#5-manifest-format)
6. [Assertion reference](#6-assertion-reference)
7. [Reading a failure](#7-reading-a-failure)
8. [Where files go](#8-where-files-go)
9. [Adding a test](#9-adding-a-test)
10. [coverage.py](#10-coveragepy)
11. [triage.py](#11-triagepy)
12. [Windows notes](#12-windows-notes)
13. [Gotchas](#13-gotchas)

---

## 1. Quick start

### Linux / make

```bash
make                 # build StudDFT
make tests           # build the 7 standalone unit drivers
make check-smoke     # the sub-minute tier
make check           # everything
make coverage        # regenerate tests/COVERAGE.md
```

### Windows / Visual Studio

Build the StudDFT project, then from a normal command prompt:

```
cd /d d:\Projects\StudDFT\StudDFT
python tests\runner.py --exe x64\FullEdition\StudDFT.exe --tags smoke
```

To include the unit drivers, build them once from an **Intel oneAPI**
prompt:

```
tests\build_unit_tests.bat
```

Python 3.6+ is the only requirement. No third-party packages.

---

## 2. What the suite is trying to be

Not "a script that runs every `test*.inp` in a row". Three consecutive
real defects passed a suite that checked only numbers:

| release | defect | what a numbers-only suite saw |
|---|---|---|
| v1.17.0 | 8x ERI slowdown (`/heap-arrays0`) | every energy bit-identical |
| v1.17.1 | non-positive TDDFT states printed as orphaned amplitudes | numbers fine, the output lied |
| v1.17.2 | cross-spin kernel serial and half-wasted | numbers fine |

So assertions come in classes, and the runner reports which class each
one belongs to.

**Assertion strength ladder** -- the measure of coverage that matters:

| level | means | catches |
|---|---|---|
| **oracle** | value checked against literature, another program, or hand computation | a wrong answer |
| **cross-check** | two independent routes inside StudDFT must agree | a wrong answer, with no reference data |
| **invariant** | physics that must hold whatever the numbers are | a wrong answer, very cheaply |
| **tripwire** | value recorded from a previous run | a *change*, never an error |
| **smoke** | the run completed | a crash |

Every numerical assertion carries `src=`, and the summary prints the
ratio:

```
 numerical assertions: 27   validated 13   recorded 14 (52%)
   A `recorded` value proves a result did not change.
   It can never prove the result was right.
```

A suite that is mostly tripwires gives false confidence. The number is
printed so it cannot be forgotten.

---

## 3. runner.py -- command line

```
python tests/runner.py [options]
```

| option | default | meaning |
|---|---|---|
| `--exe PATH` | `./studdft` (`.exe` added on Windows) | the StudDFT executable |
| `--tags A,B` | all | run tests carrying **any** of these tags |
| `--id REGEX` | all | run tests whose id matches; repeatable |
| `--threads N` | `1` | `OMP_NUM_THREADS` for tests that do not set their own |
| `--jobs N` | `1` | how many tests run concurrently |
| `--work DIR` | `<root>/test_work` | scratch directory |
| `--keep-logs` | off | keep working directories of passing tests too |
| `--json FILE` | none | machine-readable summary |
| `--list` | off | list the selected tests and exit without running |
| `--manifest-dir DIR` | `tests/manifest` | where the `.mf` files live |

Exit status is 0 only if every selected test passed. That makes it
usable as a CI step or a Visual Studio post-build event unchanged.

### Threads

Three levels, most specific wins:

1. `threads = N` on a test in the manifest
2. `--threads N` on the command line
3. `threads = 0` on a test means **do not set the variable at all** --
   `OMP_NUM_THREADS` is inherited from your shell. Only the performance
   anchor uses this, deliberately: it must measure your real
   configuration.

**The default is 1 on purpose.** v1.17.2 measured that the triplet
TDDFT channel is not bit-reproducible under threading -- about 3e-7 Ha
of scatter, present even in a build whose cross-spin routine contained
no OpenMP at all. Tripwires pinned at 1e-8 would flicker. One thread
makes them deterministic.

### `--jobs`

`--jobs` parallelises *tests*; each still gets `--threads` OpenMP
threads, so `--threads 2 --jobs 4` can occupy eight cores. It is
disabled automatically when the selection contains `needs` chains or
`matches` assertions, both of which require ordering.

---

## 4. Tiers and tags

Tags are free-form; these are the ones in use.

**Tiers** (how long you are willing to wait):

| tag | scope |
|---|---|
| `smoke` | under a minute; run it on every build |
| `commit` | a few minutes; run it before pushing |
| *(untagged)* | everything, including the migrated batch; tens of minutes |

**Kinds:**

| tag | meaning |
|---|---|
| `anchor` | release anchors quoted in the notes |
| `crosscheck` | two-route agreement, no reference data needed |
| `negative` | must refuse; asserts the exit **and** the diagnostic |
| `stability` | reproducibility across repeated runs |
| `performance` | throughput floors |
| `unit` | standalone driver programs |
| `matrix` | fills a capability-matrix cell |
| `migrated` | auto-generated from an orphaned input; tripwires only |

**Subsystems:** `tddft`, `pcm`, `ri`, `dft`, `hf`, `mp2`, `hybrid`,
`rs`, `lda`, `gga`, `dispersion`, `gradient`, `hessian`, `opt`, `ts`,
`irc`, `scan`, `smearing`, `memory`, `integrals`, `basis`, `spherical`,
`uks`, `triplet`, `export`, `gmh`, `edge`.

```bash
python tests/runner.py --tags crosscheck,negative
python tests/runner.py --tags tddft
python tests/runner.py --id "refuse_" --id "^perf"
```

---

## 5. Manifest format

Plain text, `tests/manifest/*.mf`, read in filename order. `#` starts a
comment. Two block types.

### `[test]` -- runs an input file through StudDFT

```
[test]
id      = tddft_m06_hybrid_rpa_both
input   = tests/test_v1170_tddft_m06_hybrid_rpa_both.inp
tags    = smoke, tddft, dft, hybrid, rpa, triplet
timeout = 240
threads = 1
repeat  = 1
needs   = some_other_test_id
assert  = value "^ +1 " after="^ +Singlet excited states:" field=3 eq=11.6432 tol=1e-3 src=hand
assert  = absent "NON-POSITIVE excitation"
```

### `[program]` -- runs a standalone driver

```
[program]
id      = unit_boys_table
build   = test_boys
tags    = smoke, unit, integrals
timeout = 120
assert  = exit zero
```

### Fields

| field | applies to | meaning |
|---|---|---|
| `id` | both | unique name; used by `--id`, `needs`, `matches` and the log filename |
| `input` | `[test]` | path to the `.inp`, relative to the repository root |
| `build` | `[program]` | executable name, without `.exe` |
| `tags` | both | comma-separated |
| `timeout` | both | seconds; the test fails if exceeded |
| `threads` | both | `OMP_NUM_THREADS`; `0` = inherit from the shell |
| `repeat` | both | run N times; required by `stable` |
| `needs` | both | id of a test whose output files this one consumes |
| `note` | both | free text, ignored by the runner |
| `expect` | both | `fail` marks a known defect (see below) |
| `assert` | both | one check; repeatable |

### `expect = fail`

A test that is known to fail, and is kept anyway because deleting it
would delete the only executable record of the defect.

**Such a test is not run at all by default.** It does not appear in the
selected count, does not consume wall time, and puts nothing in the
summary. A known defect that has been decided against acting on should
cost neither time nor attention; the manifest entry, with its
explanation, is the record, and that is why the entry is kept rather
than deleted.

`--run-xfail` brings them back when someone wants to check whether a
defect is still there. Then a failure is reported as **XFAIL** and does
not break the run, and an unexpected pass as **XPASS** -- prominently,
but also without breaking the run, because "did not fail here" and "is
fixed" are different statements and the runner cannot tell them apart.
`chf2o_guess_sad` fails under Intel Fortran on Windows and passes under
gfortran. If the
test unexpectedly passes it is reported as **XPASS** -- prominently, and
in the summary -- but that does not break the run either, because
"did not fail here" and "is fixed" are different statements and the
runner cannot tell them apart. `chf2o_guess_sad` fails under Intel
Fortran on Windows and passes under gfortran; counting XPASS as a
failure would leave a correct suite permanently red on half the
machines for the crime of having documented a real bug.

### `needs`

Some jobs consume a file another job writes: `%job irc` needs the
`.hess` from a preceding `ts+freq`, a warm restart needs the `.chk` of
the run it restarts. Per-test working directories -- correct for
isolation -- break exactly those chains.

`needs = <id>` makes the consumer run **in its producer's directory**,
ordered after it, and **skipped rather than failed** when the producer
failed. A consumer failing for want of an input that was never written
is a misleading second failure, not a second defect.

---

## 6. Assertion reference

```
assert = <kind> "<regex>" [key=value ...]
```

The regex is matched against each line of the captured stdout. Anchor
it with `^ +` unless you mean otherwise: StudDFT echoes the input file
into the log, and test inputs have long comment headers, so an
unanchored pattern happily matches a comment. This has caused real bugs
in this suite twice.

### `value` -- a number must equal something

```
assert = value "^ +Total energy:" field=3 eq=-75.276760984074 tol=1e-11 src=recorded
assert = value "^ +Mode +1:" occurrence=last field=3 eq=2032.27 tol=1.0 src=recorded
assert = value "^ +1 " after="^ +Singlet excited states:" field=3 eq=11.6432 tol=1e-3 src=hand
```

| key | required | meaning |
|---|---|---|
| `field=N` | yes | which whitespace-separated token, 1-based |
| `eq=X` | yes | expected value |
| `tol=X` | yes | absolute tolerance |
| `src=` | yes | provenance: `hand`, `literature`, `external`, `internal`, `recorded` |
| `after="RX"` | no | start matching only after a line matching this |
| `occurrence=N` or `last` | no | which match; default the first |

**`occurrence=last` is not optional advice.** A multi-stage job prints
the same label many times -- a `ts+freq` run reports `Total energy:` at
every optimizer step and prints two whole `Mode 1:` blocks. Pinning the
first match against a value read off the end of the log produces an
assertion that can never pass, which is exactly how `fill_b3lyp_tsfreq`
was first written.

### `contains` / `absent` -- the output must say / must not say

```
assert = contains "meta-GGA"
assert = absent "NON-POSITIVE excitation"
assert = absent "Mode +[0-9]+: +-[0-9]"
```

`absent` is how invariants are expressed: the last line above says a
converged minimum has no imaginary frequency, which holds whatever the
numbers turn out to be.

### `exit` -- the process status

```
assert = exit zero
assert = exit nonzero
```

**Never use `exit nonzero` alone in a refusal test.** A run can crash
for an unrelated reason and look like a passing refusal. Always pair it
with the diagnostic:

```
assert = exit nonzero
assert = contains "MP2/UMP2/PUMP2 \+ PCM is not implemented"
```

This is not theoretical: it caught a Windows crash that had been
masquerading as a correct refusal.

### `matches` -- two runs must agree

```
assert = matches "^ +Total energy:" field=3 test=xc_rij_off tol=2e-3 src=internal
```

| key | required | meaning |
|---|---|---|
| `test=ID` | yes | the other test; must be listed **earlier** in the same selection |
| `field`, `after`, `tol`, `src` | | as for `value` |

The workhorse of the suite. Needs no reference data, runs in seconds,
catches a wrong answer rather than a changed one.

### `stable` -- reproducible across repeated runs

```
repeat = 3
assert = stable "^ +Total energy:" field=3 tol=1e-12 src=internal
```

Asserts that the spread over the repeats is within `tol`. Requires
`repeat >= 2`.

Use a bit tolerance where bit-reproducibility is claimed, and an
explicit loose one where it is known not to hold -- the triplet TDDFT
channel carries `tol=1e-4` eV against a measured 3e-6 eV scatter, so
the next person does not spend a day chasing a phantom race.

### `geometry` -- a molecule must have the right shape

```
assert = geometry after="Optimized Geometry \(Angstrom\)" \
         ref=0.977000,0.977000,1.515000 tol=1e-3 src=external
```

| key | required | meaning |
|---|---|---|
| `ref=` | yes | comma-separated reference distances, in Angstrom |
| `tol=` | yes | maximum allowed deviation of any one distance |
| `after=` | no | start reading the Cartesian block after this line |

Reads the Cartesian coordinates, computes every pairwise distance,
sorts them, and compares against the sorted reference. Sorting is what
makes the comparison meaningful: StudDFT prints coordinates in its own
orientation while the reference programs store a distance matrix, so a
rotation would change every coordinate and no bond length -- and the
two need not list the atoms in the same order either. What survives the
sort is the shape of the molecule, which is the thing being tested.

### `throughput` -- a performance floor

```
assert = throughput "^ +ERI throughput:" field=3 per_thread_field=6 min=25000 src=recorded
```

| key | required | meaning |
|---|---|---|
| `field=N` | yes | the rate |
| `min=X` | yes | the floor |
| `per_thread_field=N` | no | field holding the thread count; the rate is divided by it before comparison |

**Use `per_thread_field`.** A flat floor is tied to one machine's core
count: raise the thread count and a broken build sails over it, lower
it and a healthy build trips. The v1.18.0 flat floor of 20000 would
have missed the very regression it was written for -- the broken build
measured 47257 on six threads.

Measured endpoints, six-core Windows, CHF2OH / 6-31G(d,p):

| build | total | per thread |
|---|---|---|
| correct | 605118 quartets/s | 100853 |
| `/heap-arrays0` | 47257 quartets/s | 7876 |

---

## 7. Reading a failure

```
  FAIL  anchor_rij_h2o_pbe                           (0.7 s)
          00_core.mf:17  value "^ +Total energy:" field=3 eq=-76.0 tol=1e-11 src=recorded
            -->  -76.32720723 vs -76 (|d|=0.327, tol=1e-11)
          log: D:\...\test_work\anchor_rij_h2o_pbe\anchor_rij_h2o_pbe.log
```

Manifest file and line, the assertion verbatim, what actually happened,
and the full captured output. Logs of failing tests are always kept.

Common failure texts:

| message | meaning |
|---|---|
| `no line matching /RX/` | the pattern never matched -- usually a missing `^ +` anchor, or the wrong `after=` |
| `field N out of range` | the line matched but has fewer tokens |
| `field N is not numeric: 'The'` | matched a comment in the input echo; anchor the pattern |
| `no run for test 'X'` | a `matches` target was not in the selection, or came after |
| `producer 'X' not run` | a `needs` producer was not selected |
| `<name> not built` | a `[program]` driver has not been compiled |

---

## 8. Where files go

```
test_work/
  <test_id>/
    <test_id>.log                  captured stdout
    <input_name>.inp               the input, copied in
    <input_name>.chk               whatever the run produced
    <input_name>_mo.molden
    ...
```

Each test runs in **its own directory**, with the input **copied in**
and invoked by bare name. That last part matters: StudDFT derives every
artefact name from the input path, so passing an absolute path wrote
`.chk` and `.molden` next to the input in `tests/` no matter what the
working directory was. Copying the input in is what makes the isolation
real.

`STUDDFT` is **respected, not overwritten**. It names the directory
containing `basis_data`, and yours may not be the repository root. The
runner supplies the repository root only when the variable is unset,
and says so at startup:

```
   STUDDFT  : D:\Projects\StudDFT\StudDFT
   STUDDFT  : /path/to/repo   (not set; falling back to the repository root)
```

**A green run deletes the working directories** and tells you:

```
 34 working directories removed (every test passed).
 Re-run with --keep-logs to keep them, and the .chk /
 .molden / .txt files the tests produce, under .../test_work
```

So an empty `test_work` after a green run is the success case, not a
lost result. Use `--keep-logs` when you want the artefacts.

---

## 9. Adding a test

1. Write the input under `tests/`. Put the *reasoning* in the header
   comment: what this exercises, why it exists, what would make it
   fail. The header is the only place that survives.
2. Add a `[test]` block to the right manifest, or a new `.mf`.
3. Choose the strongest assertion you can afford, in this order:
   **oracle > cross-check > invariant > tripwire**. A cross-check
   usually costs one extra small input and beats any recorded number.
4. Set `src=` honestly. If you took the value from your own run, it is
   `recorded`, however confident you feel.
5. Tag it with a tier and a subsystem.
6. Run just it: `--id <your_id>`.
7. **Deliberately break it** -- change `eq=` and confirm it fails. An
   assertion that has never failed has never been tested. Two
   assertions in this suite could not have passed and nobody noticed,
   because the tier containing them was never run in full.

---

## 10. coverage.py

```bash
python3 tests/coverage.py                       # to stdout
python3 tests/coverage.py -o tests/COVERAGE.md  # or `make coverage`
```

Compares the keywords the parser accepts against those exercised by an
input that a manifest entry actually **runs**. Reports the branches
never exercised, the ones present only in an input nobody runs, the
orphaned inputs, and alias groups.

Two details it gets right that a grep does not:

- **Nesting.** `input_parser.f90` has dozens of inner
  `select case (trim(value_str))` constructs dispatching on *values*
  (`'AUTO'`, `'BOTH'`, `'CART'`). A flat grep reports 184 keywords
  where there are 174.
- **Branches, not spellings.** Aliases live on one `case` line --
  `case ('TDDFT_MULTIPLICITY', 'TDDFT_MULT')` -- so both enter the same
  code and exercising either exercises both. Counting spellings
  understates coverage.

Remember what this number is: **keyword coverage, not capability
verification.** A keyword can be exercised by a test that only checks
the run did not crash. The capability matrix in
`StudDFT_test_capability_audit.docx` is the honest measure.

---

## 11. triage.py

For classifying inputs that no manifest entry runs.

```bash
python3 tests/triage.py --limit 50                          # dry run
python3 tests/triage.py --emit tests/manifest/90_migrated.mf
```

| option | default | meaning |
|---|---|---|
| `--exe PATH` | `./studdft` | the executable |
| `--timeout N` | 45 | per input |
| `--limit N` | 0 = all | how many *unclassified* inputs to process now |
| `--emit FILE` | none | write draft manifest entries |
| `--state FILE` | `tests/.triage_state.tsv` | resume file |
| `--skip REGEX` | none | leave matching inputs alone |

Buckets: **COMPLETES** (exit 0 with an energy), **REFUSES** (non-zero
with a diagnostic -- the most valuable, negative tests are what the
suite is thinnest on), **TIMEOUT** and **BROKEN**, the last two needing
a human.

Resumable: every classification is appended to the state file as it
happens, because a few hundred runs is longer than one sitting and
background processes do not survive a session.

**What it produces is tripwires.** Draft entries carry `src=recorded`
and the `migrated` tag. That turns an orphan into something that will
notice a change, which is a real gain, but it is not validation, and it
pushes the recorded fraction up. Read drafts before committing them and
upgrade `src=` wherever a value can be checked against something.

---

## 12. Windows notes

**Python.** `python` rather than `python3`; `py` also works.

**The executable is not in the repository root.** Pass `--exe`:

```
python tests\runner.py --exe x64\FullEdition\StudDFT.exe --tags smoke
```

Or copy `StudDFT.exe` to the root and drop the flag.

**Unit drivers.** Not built by the solution. Build them once, naming
the same executable you test with:

```
tests\build_unit_tests.bat x64\FullEdition\StudDFT.exe
```

The argument is not optional in practice. A working repository
accumulates old build outputs, and the script derives the object,
module and output directories from the executable you give it rather
than searching the tree -- an earlier version searched, found a stale
`x64\Debug` and a stray copy under `grid5\`, linked the drivers
against the wrong objects and put them where the runner does not look.
It now **refuses to guess** when several candidates exist, and says
which. Overrides: `STUDDFT_EXE`, `STUDDFT_OBJDIR`, `STUDDFT_MODDIR`.

Without the drivers you get 7 SKIP, which is harmless.

The script runs from a **plain cmd**: `ifort` lives under
`Program Files` but is only on `PATH` inside an Intel environment, so
the script finds `setvars.bat` (oneAPI) or `ifortvars.bat` (Parallel
Studio / Composer XE) itself. Two overrides if the guesses are wrong:

```
set INTEL_SETVARS=C:\Program Files (x86)\Intel\oneAPI\setvars.bat
set FC=ifx
```

`FC=ifx` is worth knowing: oneAPI 2024 and later ship `ifx` and no
longer `ifort`. The script falls back to it automatically, but only
after failing to find `ifort` first.

The script also matches the **C runtime** of the objects it links,
reading the linker directive out of `main.obj`. A mismatch shows up as
`LNK4098: defaultlib "LIBCMTD" conflicts ...` and is not cosmetic: two
C runtimes in one image means two heaps, and memory allocated by one
and released by the other crashes. If the detection is ever wrong,
pass the pair explicitly:

```
tests\build_unit_tests.bat /libs:static /dbglibs /Qmkl:sequential
```

**Heap Arrays must be empty.** Fortran -> Optimization -> Heap Arrays.
Setting it to 0 moves the HRR workspaces off the thread stack and costs
roughly 8x in the ERI engine while changing no numbers at all. The
performance anchor is the check for this.

**Visual Studio integration.** Tools -> External Tools -> Add:

- Command: `python.exe`
- Arguments: `tests\runner.py --exe x64\FullEdition\StudDFT.exe --tags smoke`
- Initial directory: `$(SolutionDir)`
- Use Output window: yes

Or as a post-build event:

```
python "$(SolutionDir)tests\runner.py" --exe "$(TargetPath)" --tags smoke
```

The non-zero exit turns the build red. Use `--tags smoke` only; the
full suite in a post-build event makes work impossible.

---

## 13. Gotchas

**Anchor your regexes.** The input echo in the log contains the test's
own comment header. `after="excited states"` armed on a comment and
read the wrong field; `"ERI throughput:"` matched the sentence
describing the assertion. Use `^ +`.

**`occurrence=last` for multi-stage jobs.** See section 6.

**A `matches` target must come earlier** in the same selection.
`--id xc_rij_on` alone fails; the pair must be selected together.

**An empty `test_work` after a green run is normal.** Section 8.

**The `migrated` tier is tripwires.** Do not read its passing as
verification.

**One clean run is weak evidence for an intermittent fault.** The
Windows crash after the banner passed once before it was understood.
Confidence comes from the mechanism, not from a single green result.

**`test_d3_grad` hardcodes a relative `basis_data/` path** and ignores
`STUDDFT`, so `[program]` entries are exempted from per-test
directories and run at the repository root. Open item.
