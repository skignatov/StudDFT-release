#!/usr/bin/env python3
# =====================================================================
# StudDFT input-keyword coverage report (v1.18.0)
#
# Answers "have we tested everything?" with a number instead of an
# opinion.  Two sets are compared:
#
#   ACCEPTED  every label of the top-level `select case (trim(keyword))`
#             in src/input_parser.f90 -- i.e. every %keyword the program
#             will act on.
#   EXERCISED every %keyword appearing in an input file that at least
#             one manifest entry actually runs.
#
# Two subtleties that a naive grep gets wrong, both learned the hard way:
#
#  1. NESTING.  input_parser.f90 contains dozens of inner
#     `select case (trim(value_str))` constructs whose labels are
#     VALUES ('AUTO', 'BOTH', 'CART', 'COLD', ...), not keywords.  A
#     flat grep for "case ('X')" reports 184 keywords where there are
#     174, and pads the untested list with things that are not
#     keywords at all.  This script tracks select/end-select depth and
#     counts only depth 1 of the keyword construct.
#
#  2. ORPHANED INPUTS.  tests/ holds far more .inp files than any
#     runner executes.  An input nobody runs proves nothing, so a
#     keyword is only counted as exercised if it appears in a file
#     reachable from the manifest.  The gap between the two is
#     reported separately, because it is a maintenance liability in
#     its own right.
#
# COVERAGE IS COUNTED PER FEATURE, NOT PER SPELLING.  Every alias
# group in input_parser.f90 lives on ONE case line --
#     case ('TDDFT_MULTIPLICITY', 'TDDFT_MULT')
#     case ('SYMMETRY_TOL', 'SYM_TOL', 'SYMTOL')
# -- so both spellings enter the same branch and exercising either one
# exercises exactly the same code.  An earlier draft of this tool
# counted labels instead of branches and reported unused SPELLINGS as
# coverage gaps.  That was wrong: it understated coverage (174 labels
# against 117 branches) and it raised an alarm about a risk this
# parser does not have.  Deleting a label from a case line makes the
# keyword unrecognised, which the parser reports loudly; it is not a
# silent failure mode.
#
# The alias section below is therefore INFORMATIONAL.  It exists so
# that if aliases ever start accreting as separate case blocks with
# duplicated bodies -- which is when divergence becomes real -- the
# change is visible here.
#
# Usage:
#   python3 tests/coverage.py                  # print to stdout
#   python3 tests/coverage.py -o tests/COVERAGE.md
# =====================================================================

import argparse
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def accepted_keywords(parser_src):
    """Labels of the top-level keyword dispatch, with their line numbers."""
    lines = parser_src.read_text(encoding="utf-8", errors="replace").split("\n")

    start = None
    for i, l in enumerate(lines):
        if re.search(r"select case\s*\(\s*trim\s*\(\s*keyword\s*\)\s*\)", l):
            start = i
            break
    if start is None:
        sys.exit("could not locate `select case (trim(keyword))` in %s" % parser_src)

    kws = {}
    depth = 0
    for i in range(start, len(lines)):
        l = lines[i]
        if re.search(r"\bselect case\b", l):
            depth += 1
            continue
        if re.search(r"\bend select\b", l):
            depth -= 1
            if depth == 0:
                break
            continue
        if depth == 1:
            m = re.match(r"\s*case \((.*)\)\s*$", l)
            if m:
                labels = re.findall(r"'([A-Z0-9_]+)'", m.group(1))
                for k in labels:
                    # every label on one `case` line is an alias group
                    kws[k] = (i + 1, labels)
    return kws


def manifest_inputs(mdir):
    """Input files reachable from the manifest."""
    used = set()
    for mf in sorted(Path(mdir).glob("*.mf")):
        for line in mf.read_text(encoding="utf-8").split("\n"):
            line = line.split("#", 1)[0]
            m = re.match(r"\s*input\s*=\s*(\S+)", line)
            if m:
                used.add(m.group(1).strip())
    return used


def keywords_in(paths):
    used = {}
    for p in paths:
        f = ROOT / p
        if not f.exists():
            continue
        for line in f.read_text(encoding="utf-8", errors="replace").split("\n"):
            m = re.match(r"\s*%([A-Za-z0-9_]+)", line)
            if m:
                used.setdefault(m.group(1).upper(), set()).add(str(p))
    return used


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-o", "--output", default=None)
    ap.add_argument("--manifest-dir", default=str(HERE / "manifest"))
    args = ap.parse_args()

    kws = accepted_keywords(ROOT / "src" / "input_parser.f90")
    run_inputs = manifest_inputs(args.manifest_dir)
    all_inputs = [p.relative_to(ROOT) for p in sorted((ROOT / "tests").glob("*.inp"))]

    exercised = keywords_in(sorted(run_inputs))
    present = keywords_in(all_inputs)

    # Collapse alias groups: one entry per parser branch.
    branches = {}
    for k, (_, labels) in kws.items():
        branches.setdefault(tuple(sorted(labels)), list(labels))

    def hit(group, table):
        return any(k in table for k in group)

    covered = sorted(g for g in branches if hit(g, exercised))
    dormant = sorted(g for g in branches if not hit(g, exercised) and hit(g, present))
    missing = sorted(g for g in branches
                     if not hit(g, exercised) and not hit(g, present))

    orphans = sorted(str(p) for p in all_inputs if str(p) not in run_inputs)

    # alias groups where no spelling at all is exercised, and groups
    # where some spellings are and others are not
    groups = {}
    for k, (_, labels) in kws.items():
        groups[tuple(sorted(labels))] = labels
    partial = []
    for g in sorted(groups):
        if len(g) < 2:
            continue
        hit = [k for k in g if k in exercised]
        if hit and len(hit) < len(g):
            partial.append((g, hit))

    n = len(branches)
    out = []
    w = out.append
    w("# StudDFT input-keyword coverage\n")
    w("Generated by `tests/coverage.py`. Do not edit by hand.\n")
    w("| | count | share |")
    w("|---|---|---|")
    w("| Keyword branches in the parser (alias groups collapsed) | %d | 100%% |" % n)
    w("| Distinct spellings accepted | %d | -- |" % len(kws))
    w("| Exercised by a test the manifest runs | %d | %.0f%% |"
      % (len(covered), 100.0 * len(covered) / n))
    w("| Present only in an input nobody runs | %d | %.0f%% |"
      % (len(dormant), 100.0 * len(dormant) / n))
    w("| Absent from every input file | %d | %.0f%% |"
      % (len(missing), 100.0 * len(missing) / n))
    w("")
    w("Input files in `tests/`: %d, of which **%d are not referenced by "
      "any manifest entry**.\n" % (len(all_inputs), len(orphans)))

    w("## Never exercised, and not present in any input\n")
    w("Nothing in the tree even mentions these. Highest risk.\n")
    w(_columns(missing))

    w("\n## Present in an input, but that input is never run\n")
    w("A test nobody executes proves nothing. Either add a manifest")
    w("entry for the input, or delete it.\n")
    w(_columns(dormant))

    if partial:
        w("\n## Alias groups only partly exercised\n")
        w("Each spelling is a separate branch in the parser. The unused")
        w("spelling can stop working without any test noticing.\n")
        w("| alias group | exercised | NOT exercised |")
        w("|---|---|---|")
        for g, hit in partial:
            miss = [k for k in g if k not in hit]
            w("| %s | %s | **%s** |" % (
                ", ".join("`%%%s`" % k.lower() for k in g),
                ", ".join("`%%%s`" % k.lower() for k in hit),
                ", ".join("`%%%s`" % k.lower() for k in miss)))

    if orphans:
        w("\n## Orphaned input files\n")
        w("<details><summary>%d files</summary>\n" % len(orphans))
        for o in orphans:
            w("- `%s`" % o)
        w("\n</details>")

    text = "\n".join(out) + "\n"
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
        print("wrote %s" % args.output)
        print("coverage: %d/%d keywords (%.0f%%), %d orphaned inputs"
              % (len(covered), n, 100.0 * len(covered) / n, len(orphans)))
    else:
        sys.stdout.write(text)
    return 0


def _columns(items, per_row=5):
    """items are alias groups (tuples); show the first spelling of each."""
    if not items:
        return "_(none)_\n"
    names = [g[0] if isinstance(g, tuple) else g for g in items]
    rows = []
    for i in range(0, len(names), per_row):
        rows.append("  " + "  ".join("`%%%s`" % k.lower()
                                     for k in names[i:i + per_row]))
    return "\n".join(rows) + "\n"


if __name__ == "__main__":
    sys.exit(main())
