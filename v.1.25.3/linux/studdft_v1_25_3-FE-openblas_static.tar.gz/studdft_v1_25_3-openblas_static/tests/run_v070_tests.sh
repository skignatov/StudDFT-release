#!/bin/bash
# =============================================================
# StudDFT v0.70.0 -- Partial-constraint optimization suite
# =============================================================
#
# Runs every test_v070_*.inp under tests/ and verifies:
#   * Positive tests exit 0 and converge
#   * Negative tests exit non-zero with a clean ERROR diagnostic
#   * Cross-check: constrained-opt final energy matches a
#     single-point at the same final geometry
#
# Usage: ./run_v070_tests.sh [path_to_studdft]
# =============================================================

set -u
EXE=${1:-./studdft}
cd "$(dirname "$0")/.."
export STUDDFT="$PWD"

PASS=0
FAIL=0

check_converged() {
    local out="$1"
    grep -q "Optimization converged" "$out"
}

check_frozen_holds() {
    # Verify that the constrained coordinate appears in the final
    # printed coordinate table with the [fixed] tag.
    local out="$1"
    grep -q "\[fixed\]" "$out"
}

# ----- Positive: constrained optimizations must converge -----
for inp in tests/test_v070_hooh_opt_frozen_OO.inp \
           tests/test_v070_h2o_opt_frozen_HH.inp \
           tests/test_v070_hooh_opt_frozen_dihedral.inp; do
    name=$(basename "$inp" .inp)
    if "$EXE" "$inp" > /tmp/${name}.out 2>&1; then
        if check_converged /tmp/${name}.out && \
           check_frozen_holds /tmp/${name}.out; then
            printf "  PASS  %s\n" "$name"
            PASS=$((PASS+1))
        else
            printf "  FAIL  %s  (no convergence or no [fixed] tag)\n" "$name"
            FAIL=$((FAIL+1))
        fi
    else
        printf "  FAIL  %s  (exit code != 0)\n" "$name"
        FAIL=$((FAIL+1))
    fi
done

# ----- Reference single-point (must just succeed) -----
inp=tests/test_v070_hooh_ref_at_frozen_OO.inp
name=$(basename "$inp" .inp)
if "$EXE" "$inp" > /tmp/${name}.out 2>&1; then
    if grep -q "Total energy:" /tmp/${name}.out; then
        printf "  PASS  %s\n" "$name"
        PASS=$((PASS+1))
    else
        printf "  FAIL  %s  (no energy in output)\n" "$name"
        FAIL=$((FAIL+1))
    fi
else
    printf "  FAIL  %s  (exit code != 0)\n" "$name"
    FAIL=$((FAIL+1))
fi

# ----- Negative tests -----
for inp in tests/test_v070_constrain_with_energy.inp \
           tests/test_v070_constrain_bad_atom.inp \
           tests/test_v070_constrain_bad_kind.inp \
           tests/test_v070_constrain_duplicate.inp; do
    name=$(basename "$inp" .inp)
    "$EXE" "$inp" > /tmp/${name}.out 2>&1
    rc=$?
    if [ $rc -ne 0 ] && grep -q "ERROR" /tmp/${name}.out; then
        printf "  PASS  %s  (clean diagnostic, rc=%d)\n" "$name" "$rc"
        PASS=$((PASS+1))
    else
        printf "  FAIL  %s  (expected non-zero exit + ERROR; rc=%d)\n" \
            "$name" "$rc"
        FAIL=$((FAIL+1))
    fi
done

# ----- Cross-validation: constrained-opt vs single-point at final geom -----
E_OPT=$(grep "Final energy:" /tmp/test_v070_hooh_opt_frozen_OO.out | \
        head -1 | awk '{print $3}')
E_REF=$(grep "Total energy:" /tmp/test_v070_hooh_ref_at_frozen_OO.out | \
        head -1 | awk '{print $3}')
if [ -n "$E_OPT" ] && [ -n "$E_REF" ]; then
    DIFF=$(awk -v a="$E_OPT" -v b="$E_REF" \
        'BEGIN{ d=a-b; if(d<0)d=-d; printf "%.2e", d}')
    OK=$(awk -v d="$DIFF" 'BEGIN{print (d<1e-6)?"OK":"FAIL"}')
    if [ "$OK" = "OK" ]; then
        printf "  PASS  cross-check: opt=%s ref=%s |dE|=%s\n" \
            "$E_OPT" "$E_REF" "$DIFF"
        PASS=$((PASS+1))
    else
        printf "  FAIL  cross-check: opt=%s ref=%s |dE|=%s (>1e-6)\n" \
            "$E_OPT" "$E_REF" "$DIFF"
        FAIL=$((FAIL+1))
    fi
else
    printf "  FAIL  cross-check: missing energy values\n"
    FAIL=$((FAIL+1))
fi

echo
echo "  Summary:  $PASS passed, $FAIL failed."
echo
[ $FAIL -eq 0 ] && exit 0 || exit 1
